import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import util from 'util';
import { AspectRatio, VisualStyle, ContinuityProfile } from '../types.js';

const execPromise = util.promisify(exec);

export const DEFAULT_IMAGE_BASE_URL = 'https://kite-mushily-bling.ngrok-free.dev';

export function normalizeImageBaseUrl(rawUrl?: string): string {
  const input = (rawUrl || process.env.IMAGE_API_URL || DEFAULT_IMAGE_BASE_URL).trim();
  if (!input) return DEFAULT_IMAGE_BASE_URL;

  try {
    const parsed = new URL(input);
    let pathname = parsed.pathname.replace(/\/+$/, '');
    pathname = pathname
      .replace(/\/docs$/i, '')
      .replace(/\/image$/i, '')
      .replace(/\/bulk$/i, '')
      .replace(/\/generate$/i, '')
      .replace(/\/api\/jobs$/i, '')
      .replace(/\/api\/status$/i, '')
      .replace(/\/api$/i, '');
    return `${parsed.origin}${pathname}`;
  } catch {
    return input
      .replace(/\/+$/, '')
      .replace(/\/docs$/i, '')
      .replace(/\/image$/i, '')
      .replace(/\/bulk$/i, '')
      .replace(/\/generate$/i, '')
      .replace(/\/api\/jobs$/i, '')
      .replace(/\/api\/status$/i, '')
      .replace(/\/api$/i, '');
  }
}

export function normalizeFlowModel(rawModel?: string): string {
  const m = (rawModel || '').trim().toLowerCase();
  if (m === 'beluga' || m === 'narwhal') return m;
  return 'beluga';
}

function getCommonHeaders(includeJsonContentType = false): Record<string, string> {
  const headers: Record<string, string> = {
    'ngrok-skip-browser-warning': 'true',
    'User-Agent': 'CineScriptAI-VideoGenerator/1.0'
  };
  if (includeJsonContentType) {
    headers['Content-Type'] = 'application/json';
  }
  return headers;
}

function resolveMediaUrl(fileUrl: string, baseUrl: string): string {
  if (/^https?:\/\//i.test(fileUrl)) return fileUrl;
  const cleanBase = baseUrl.replace(/\/+$/, '');
  const cleanPath = fileUrl.startsWith('/') ? fileUrl : `/${fileUrl}`;
  return `${cleanBase}${cleanPath}`;
}

export interface FlowStatusResult {
  ok: boolean;
  httpStatus?: number;
  baseUrl: string;
  latencyMs: number;
  data?: any;
  error?: string;
}

/**
 * Verifies the Flow Image Server is reachable at <baseUrl>/docs
 */
export async function checkFlowApiStatus(customBaseUrl?: string): Promise<FlowStatusResult> {
  const baseUrl = normalizeImageBaseUrl(customBaseUrl);
  const startTime = Date.now();
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    const res = await fetch(`${baseUrl}/docs`, {
      method: 'GET',
      headers: {
        ...getCommonHeaders(false),
        Accept: 'text/html,application/json,*/*'
      },
      signal: controller.signal
    });
    clearTimeout(timeout);

    const latencyMs = Date.now() - startTime;
    const rawText = await res.text();

    if (res.status === 502) {
      return {
        ok: false,
        httpStatus: 502,
        baseUrl,
        latencyMs,
        error: 'HTTP 502: Tunnel or local Flow server is offline. Restart start-simple.cmd and try again.'
      };
    }

    if (!res.ok) {
      return {
        ok: false,
        httpStatus: res.status,
        baseUrl,
        latencyMs,
        error: `Endpoint returned HTTP ${res.status}: ${rawText.substring(0, 180)}`
      };
    }

    const hasSimpleEndpoints = rawText.includes('/image') || rawText.includes('/bulk') || rawText.includes('Swagger');
    return {
      ok: true,
      httpStatus: res.status,
      baseUrl,
      latencyMs,
      data: {
        docsReachable: true,
        endpoints: ['/image', '/bulk'],
        verifiedSwagger: hasSimpleEndpoints,
        defaultModel: 'beluga',
        defaultCaptcha: 'broker'
      }
    };
  } catch (err: any) {
    return {
      ok: false,
      baseUrl,
      latencyMs: Date.now() - startTime,
      error:
        err.name === 'AbortError'
          ? 'Connection timed out while checking <base>/docs.'
          : `Connection error: ${err.message}`
    };
  }
}

export interface FlowJobRunParams {
  prompt: string;
  aspectRatio?: string;
  imageModel?: string;
  captcha?: 'auto' | 'broker' | 'http' | 'off';
  customApiUrl?: string;
  maxTotalWaitMs?: number;
}

export interface FlowJobRunResult {
  buffer: Buffer;
  contentType: string;
  jobId: string;
  model: string;
  baseUrl: string;
  mediaUrl: string;
  jobData: any;
  latencyMs: number;
}

async function downloadFlowMedia(mediaUrl: string, baseUrl: string): Promise<{ buffer: Buffer; contentType: string; resolvedUrl: string }> {
  const resolvedUrl = resolveMediaUrl(mediaUrl, baseUrl);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 45000);
  let mediaRes: Response;
  try {
    mediaRes = await fetch(resolvedUrl, {
      method: 'GET',
      headers: {
        ...getCommonHeaders(false),
        Accept: 'image/*, */*'
      },
      signal: controller.signal
    });
  } finally {
    clearTimeout(timeout);
  }

  if (!mediaRes.ok) {
    const errBody = await mediaRes.text().catch(() => '');
    throw new Error(`Media download error (HTTP ${mediaRes.status}): ${errBody.substring(0, 160)}`);
  }

  const contentType = mediaRes.headers.get('content-type') || 'image/jpeg';
  const arrayBuffer = await mediaRes.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);

  if (buffer.length < 100 || contentType.includes('text/html')) {
    throw new Error(`Invalid media payload (${buffer.length} bytes, ${contentType})`);
  }

  return { buffer, contentType, resolvedUrl };
}

/**
 * Generates one image via POST <BASE>/image and downloads files[0].url
 */
export async function runFlowImageJob(params: FlowJobRunParams): Promise<FlowJobRunResult> {
  const baseUrl = normalizeImageBaseUrl(params.customApiUrl);
  const startTime = Date.now();
  const timeoutMs = params.maxTotalWaitMs || 180000;
  const aspect = params.aspectRatio || '16:9';
  const model = normalizeFlowModel(params.imageModel);
  const captcha = params.captcha || 'broker';

  const payload = {
    prompt: params.prompt,
    aspect,
    count: 1,
    model,
    captcha
  };

  console.log(`[imageService] POST ${baseUrl}/image (aspect=${aspect}, model=${model}, captcha=${captcha})`);

  let lastErr: Error | null = null;
  for (let attempt = 1; attempt <= 2; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res: Response;
    try {
      res = await fetch(`${baseUrl}/image`, {
        method: 'POST',
        headers: getCommonHeaders(true),
        body: JSON.stringify(payload),
        signal: controller.signal
      });
    } catch (netErr: any) {
      clearTimeout(timer);
      lastErr = new Error(netErr?.name === 'AbortError' ? 'Image request timed out' : netErr?.message || 'Network error');
      if (attempt < 2) {
        await new Promise(r => setTimeout(r, 2500));
        continue;
      }
      throw lastErr;
    }
    clearTimeout(timer);

    const rawText = await res.text();
    let parsed: any = null;
    try {
      parsed = JSON.parse(rawText);
    } catch {}

    if (res.status === 502) {
      lastErr = new Error('HTTP 502: Flow refused the job or returned no media.');
      if (attempt < 2) {
        console.warn('[imageService] HTTP 502 on POST /image, retrying once in 4s...');
        await new Promise(r => setTimeout(r, 4000));
        continue;
      }
      throw lastErr;
    }

    if (!res.ok) {
      throw new Error(`POST /image HTTP ${res.status}: ${(parsed?.error || parsed?.detail || rawText).substring(0, 200)}`);
    }

    if (!parsed || !Array.isArray(parsed.files) || parsed.files.length === 0 || !parsed.files[0]?.url) {
      throw new Error(`POST /image returned no files: ${rawText.substring(0, 180)}`);
    }

    const fileInfo = parsed.files[0];
    const downloaded = await downloadFlowMedia(fileInfo.url, baseUrl);
    const latencyMs = Date.now() - startTime;

    console.log(
      `[imageService] Downloaded ${downloaded.buffer.length} bytes (${downloaded.contentType}) from ${downloaded.resolvedUrl} in ${latencyMs}ms.`
    );

    return {
      buffer: downloaded.buffer,
      contentType: downloaded.contentType,
      jobId: String(parsed.job_id || fileInfo.media_id || `job_${Date.now()}`),
      model: String(parsed.model || model).toUpperCase(),
      baseUrl,
      mediaUrl: downloaded.resolvedUrl,
      jobData: parsed,
      latencyMs
    };
  }

  throw lastErr || new Error('POST /image failed');
}

export interface FlowBulkRunParams {
  prompts: string[];
  aspectRatio?: string;
  imageModel?: string;
  captcha?: 'auto' | 'broker' | 'http' | 'off';
  concurrency?: number;
  customApiUrl?: string;
  maxTotalWaitMs?: number;
  onProgress?: (info: { completed: number; total: number; succeeded: number; failed: number; status: string }) => void;
}

export interface FlowBulkItemResult {
  index: number;
  prompt: string;
  ok: boolean;
  buffer?: Buffer;
  contentType?: string;
  mediaUrl?: string;
  jobId?: string;
  error?: string;
}

async function runSingleFlowBulkChunk(params: FlowBulkRunParams, offsetIndex: number, globalTotal: number): Promise<{
  jobId: string;
  baseUrl: string;
  results: FlowBulkItemResult[];
}> {
  const baseUrl = normalizeImageBaseUrl(params.customApiUrl);
  const startTime = Date.now();
  const maxTotalWaitMs = params.maxTotalWaitMs || Math.max(480000, params.prompts.length * 18000);
  const aspect = params.aspectRatio || '16:9';
  const model = normalizeFlowModel(params.imageModel);
  const captcha = params.captcha || 'broker';
  const concurrency = Math.min(4, Math.max(1, params.concurrency || 2));

  console.log(`[imageService] Submitting bulk job (${params.prompts.length} prompts, model=${model}, concurrency=${concurrency}) to ${baseUrl}/bulk`);

  const submitCtrl = new AbortController();
  const submitTimer = setTimeout(() => submitCtrl.abort(), 30000);
  let submitRes: Response;
  try {
    submitRes = await fetch(`${baseUrl}/bulk`, {
      method: 'POST',
      headers: getCommonHeaders(true),
      body: JSON.stringify({
        prompts: params.prompts,
        aspect,
        count: 1,
        model,
        captcha,
        concurrency
      }),
      signal: submitCtrl.signal
    });
  } finally {
    clearTimeout(submitTimer);
  }

  const submitText = await submitRes.text();
  if (!submitRes.ok) {
    throw new Error(`POST /bulk submit error (HTTP ${submitRes.status}): ${submitText.substring(0, 200)}`);
  }

  let submitJson: any;
  try {
    submitJson = JSON.parse(submitText);
  } catch {
    throw new Error(`Invalid JSON from POST /bulk: ${submitText.substring(0, 140)}`);
  }

  const jobId = submitJson.job_id;
  if (!jobId) {
    throw new Error(`POST /bulk did not return job_id: ${submitText.substring(0, 140)}`);
  }

  let finalPoll: any = submitJson.done ? submitJson : null;

  while (!finalPoll && Date.now() - startTime < maxTotalWaitMs) {
    await new Promise(r => setTimeout(r, 3000));

    const pollCtrl = new AbortController();
    const pollTimer = setTimeout(() => pollCtrl.abort(), 25000);
    let pollRes: Response;
    try {
      pollRes = await fetch(`${baseUrl}/bulk`, {
        method: 'POST',
        headers: getCommonHeaders(true),
        body: JSON.stringify({ job_id: jobId }),
        signal: pollCtrl.signal
      });
    } finally {
      clearTimeout(pollTimer);
    }

    const pollText = await pollRes.text();
    if (!pollRes.ok) {
      throw new Error(`POST /bulk poll error (HTTP ${pollRes.status}): ${pollText.substring(0, 200)}`);
    }

    const pollData = JSON.parse(pollText);
    params.onProgress?.({
      completed: offsetIndex + Number(pollData.completed || 0),
      total: globalTotal,
      succeeded: Number(pollData.succeeded || 0),
      failed: Number(pollData.failed || 0),
      status: String(pollData.status || 'running')
    });

    if (pollData.done) {
      finalPoll = pollData;
      break;
    }
  }

  if (!finalPoll) {
    throw new Error(`Bulk job ${jobId} timed out after ${Math.round(maxTotalWaitMs / 1000)}s`);
  }

  const rawResults: any[] = Array.isArray(finalPoll.results) ? finalPoll.results : [];
  const items: FlowBulkItemResult[] = [];

  for (let i = 0; i < params.prompts.length; i++) {
    const prompt = params.prompts[i];
    const r = rawResults[i];
    if (!r || !r.ok || !Array.isArray(r.files) || !r.files[0]?.url) {
      items.push({
        index: offsetIndex + i,
        prompt,
        ok: false,
        error: r?.error || 'Bulk item returned no media'
      });
      continue;
    }

    try {
      const downloaded = await downloadFlowMedia(r.files[0].url, baseUrl);
      items.push({
        index: offsetIndex + i,
        prompt,
        ok: true,
        buffer: downloaded.buffer,
        contentType: downloaded.contentType,
        mediaUrl: downloaded.resolvedUrl,
        jobId: String(r.job_id || jobId)
      });
    } catch (dlErr: any) {
      items.push({
        index: offsetIndex + i,
        prompt,
        ok: false,
        error: dlErr?.message || 'Failed to download bulk image'
      });
    }
  }

  return { jobId: String(jobId), baseUrl, results: items };
}

/**
 * Batch image generation via POST <BASE>/bulk (submit -> poll with job_id every 3s -> download media).
 * Automatically chunks >80 prompts to respect Flow /bulk's 100-prompt maximum on 15-30 minute videos.
 */
export async function runFlowBulkImageJobs(params: FlowBulkRunParams): Promise<{
  jobId: string;
  baseUrl: string;
  results: FlowBulkItemResult[];
}> {
  const MAX_BATCH = 80;
  if (params.prompts.length <= MAX_BATCH) {
    return runSingleFlowBulkChunk(params, 0, params.prompts.length);
  }

  const allResults: FlowBulkItemResult[] = [];
  let lastJobId = '';
  const baseUrl = normalizeImageBaseUrl(params.customApiUrl);

  for (let offset = 0; offset < params.prompts.length; offset += MAX_BATCH) {
    const slice = params.prompts.slice(offset, offset + MAX_BATCH);
    const chunkRes = await runSingleFlowBulkChunk(
      { ...params, prompts: slice },
      offset,
      params.prompts.length
    );
    lastJobId = chunkRes.jobId;
    allResults.push(...chunkRes.results);
  }

  return { jobId: lastJobId, baseUrl, results: allResults };
}

function isPngBuffer(buf: Buffer): boolean {
  return buf.length >= 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
}

function detectRawExtension(buf: Buffer, contentType: string): string {
  if (isPngBuffer(buf) || contentType.includes('png')) return '.png';
  if (buf.length >= 12 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return '.webp';
  if (contentType.includes('webp')) return '.webp';
  if ((buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xd8) || contentType.includes('jpeg') || contentType.includes('jpg')) return '.jpg';
  return '.jpg';
}

export async function saveRawImageAsPng(rawBuf: Buffer, contentType: string, targetPath: string): Promise<void> {
  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (isPngBuffer(rawBuf)) {
    fs.writeFileSync(targetPath, rawBuf);
    return;
  }

  const ext = detectRawExtension(rawBuf, contentType);
  const rawTempPath = targetPath.replace(/\.png$/i, `_raw${ext}`);
  fs.writeFileSync(rawTempPath, rawBuf);
  try {
    await execPromise(`ffmpeg -y -i "${rawTempPath}" "${targetPath}"`);
  } finally {
    if (fs.existsSync(rawTempPath)) {
      try {
        fs.unlinkSync(rawTempPath);
      } catch {}
    }
  }
}

export interface ImageGenerationOptions {
  prompt: string;
  width?: number;
  height?: number;
  aspectRatio: AspectRatio;
  style: VisualStyle;
  sceneTitle: string;
  sceneSequence: number;
  continuityProfile?: ContinuityProfile;
  characterDescriptions?: string;
  customApiUrl?: string;
  imageModel?: string;
  targetDir: string;
  fileName?: string;
}

export function buildConsistentFlowPrompt(options: {
  prompt: string;
  aspectRatio: AspectRatio;
  style: VisualStyle;
  continuityProfile?: ContinuityProfile;
  characterDescriptions?: string;
}): string {
  const base = (options.prompt || '').replace(/\s+/g, ' ').trim();
  const cp = options.continuityProfile;
  if (!cp) return base;

  const lower = base.toLowerCase();
  const extras: string[] = [];

  const charAnchor = (options.characterDescriptions || cp.mainCharacters || '').trim();
  if (charAnchor) {
    const lead = charAnchor.split(/[;\n]/)[0].trim();
    const tokens = lead
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 4)
      .slice(0, 5);
    const matched = tokens.filter(t => lower.includes(t)).length;
    if (lead.length > 10 && matched < 2) {
      extras.push(`Consistent character design: ${lead}`);
    }
  }

  const hasCoreStyle =
    (options.style === 'stickman' && lower.includes('stick')) ||
    (options.style === 'cartoon' && (lower.includes('cartoon') || lower.includes('2d'))) ||
    (options.style === 'realistic' &&
      (lower.includes('photorealistic') || lower.includes('cinematic') || lower.includes('35mm')));

  if (cp.artDirection && !hasCoreStyle) {
    extras.push(`Style lock: ${cp.artDirection}`);
  }
  if (cp.colorPalette && !lower.includes('palette') && !lower.includes('color')) {
    extras.push(`Color palette: ${cp.colorPalette}`);
  }
  if (cp.lightingStyle && !lower.includes('lighting') && !lower.includes('lit')) {
    extras.push(`Lighting: ${cp.lightingStyle}`);
  }
  if (!lower.includes('no watermark') && !lower.includes('no text')) {
    extras.push(`single clean ${options.aspectRatio} frame, no text, no watermark, no split panels`);
  }

  return extras.length > 0 ? `${base}. ${extras.join('. ')}.` : base;
}

export async function generateSceneImage(
  options: ImageGenerationOptions
): Promise<{ imagePath: string; isFallback: boolean; note?: string; jobId?: string }> {
  const {
    aspectRatio,
    style,
    sceneTitle,
    sceneSequence,
    customApiUrl,
    imageModel,
    targetDir,
    fileName = 'image.png'
  } = options;

  const finalPrompt = buildConsistentFlowPrompt(options);

  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  const finalImagePath = path.join(targetDir, fileName);
  const isPortrait = aspectRatio === '9:16';
  const width = options.width || (isPortrait ? 720 : 1280);
  const height = options.height || (isPortrait ? 1280 : 720);

  let isFallback = false;
  let statusNote = '';
  let jobId: string | undefined;

  try {
    const jobRes = await runFlowImageJob({
      prompt: finalPrompt,
      aspectRatio,
      imageModel,
      captcha: 'broker',
      customApiUrl,
      maxTotalWaitMs: 180000
    });

    jobId = jobRes.jobId;
    await saveRawImageAsPng(jobRes.buffer, jobRes.contentType, finalImagePath);

    statusNote = `Generated via Flow /image (${jobRes.model}, ${Math.round(jobRes.buffer.length / 1024)} KB in ${(jobRes.latencyMs / 1000).toFixed(1)}s)`;
  } catch (err: any) {
    console.warn(`[imageService] Flow /image error for scene ${sceneSequence}: ${err.message}. Falling back to local stylized generator.`);
    isFallback = true;
    statusNote = `Flow API unavailable (${err.message.substring(0, 90)}) — Generated stylized scene visual`;
    await generateStylizedVisual(finalImagePath, {
      width,
      height,
      aspectRatio,
      style,
      sceneTitle,
      sceneSequence,
      prompt: finalPrompt
    });
  }

  if (!fs.existsSync(finalImagePath) || fs.statSync(finalImagePath).size === 0) {
    throw new Error(`Failed to create valid image at ${finalImagePath}`);
  }

  return {
    imagePath: finalImagePath,
    isFallback,
    note: statusNote,
    jobId
  };
}

export async function generateStylizedVisual(
  outputPath: string,
  ctx: {
    width: number;
    height: number;
    aspectRatio: AspectRatio;
    style: VisualStyle;
    sceneTitle: string;
    sceneSequence: number;
    prompt: string;
  }
) {
  const { width, height, style, sceneTitle, sceneSequence, prompt } = ctx;
  const tempSvgPath = outputPath.replace(/\.[^/.]+$/, '') + '.svg';

  let backgroundGradient = '';
  let illustrationElements = '';
  let badgeColor = '';
  let styleLabel = '';

  const cleanPrompt = prompt.replace(/[<>&"]/g, ' ').substring(0, 110);
  const cleanTitle = sceneTitle.replace(/[<>&"]/g, ' ').substring(0, 40);

  if (style === 'stickman') {
    styleLabel = 'STICKMAN ARTWORK';
    badgeColor = '#000000';
    backgroundGradient = `
      <defs>
        <radialGradient id="bg" cx="50%" cy="40%" r="65%">
          <stop offset="0%" stop-color="#f8fafc" />
          <stop offset="100%" stop-color="#e2e8f0" />
        </radialGradient>
        <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="8" stdDeviation="6" flood-opacity="0.1" />
        </filter>
      </defs>
      <rect width="100%" height="100%" fill="url(#bg)"/>
      <line x1="0" y1="${height * 0.78}" x2="${width}" y2="${height * 0.78}" stroke="#334155" stroke-width="4" stroke-dasharray="8 6"/>
    `;

    const cx = width / 2;
    const cy = height * 0.52;
    const armOffset = sceneSequence % 3 === 0 ? -35 : sceneSequence % 2 === 0 ? 30 : 0;
    illustrationElements = `
      <g filter="url(#shadow)">
        <circle cx="${cx}" cy="${cy - 70}" r="32" fill="#ffffff" stroke="#0f172a" stroke-width="6"/>
        <circle cx="${cx - 10}" cy="${cy - 74}" r="3.5" fill="#0f172a"/>
        <circle cx="${cx + 10}" cy="${cy - 74}" r="3.5" fill="#0f172a"/>
        <path d="M ${cx - 12} ${cy - 60} Q ${cx} ${cy - 52} ${cx + 12} ${cy - 60}" fill="none" stroke="#0f172a" stroke-width="3.5" stroke-linecap="round"/>
        <line x1="${cx}" y1="${cy - 38}" x2="${cx}" y2="${cy + 65}" stroke="#0f172a" stroke-width="6" stroke-linecap="round"/>
        <line x1="${cx}" y1="${cy - 10}" x2="${cx - 50}" y2="${cy + armOffset}" stroke="#0f172a" stroke-width="6" stroke-linecap="round"/>
        <line x1="${cx}" y1="${cy - 10}" x2="${cx + 50}" y2="${cy - armOffset}" stroke="#0f172a" stroke-width="6" stroke-linecap="round"/>
        <line x1="${cx}" y1="${cy + 65}" x2="${cx - 40}" y2="${cy + 145}" stroke="#0f172a" stroke-width="6" stroke-linecap="round"/>
        <line x1="${cx}" y1="${cy + 65}" x2="${cx + 40}" y2="${cy + 145}" stroke="#0f172a" stroke-width="6" stroke-linecap="round"/>
      </g>
    `;
  } else if (style === 'cartoon') {
    styleLabel = 'CARTOON ANIMATION';
    badgeColor = '#3b82f6';
    backgroundGradient = `
      <defs>
        <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#38bdf8" />
          <stop offset="60%" stop-color="#bae6fd" />
          <stop offset="100%" stop-color="#f0fdf4" />
        </linearGradient>
        <linearGradient id="hill" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#22c55e" />
          <stop offset="100%" stop-color="#16a34a" />
        </linearGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#sky)"/>
      <ellipse cx="${width * 0.2}" cy="${height * 0.22}" rx="60" ry="24" fill="#ffffff" opacity="0.9"/>
      <ellipse cx="${width * 0.75}" cy="${height * 0.18}" rx="80" ry="32" fill="#ffffff" opacity="0.9"/>
      <path d="M 0 ${height * 0.65} Q ${width * 0.35} ${height * 0.52} ${width * 0.7} ${height * 0.68} T ${width} ${height * 0.62} L ${width} ${height} L 0 ${height} Z" fill="url(#hill)" stroke="#15803d" stroke-width="4"/>
    `;

    const cx = width / 2;
    const cy = height * 0.58;
    illustrationElements = `
      <g>
        <circle cx="${cx}" cy="${cy - 50}" r="45" fill="#fde047" stroke="#ca8a04" stroke-width="5"/>
        <ellipse cx="${cx - 15}" cy="${cy - 55}" rx="8" ry="12" fill="#ffffff" stroke="#0f172a" stroke-width="3"/>
        <ellipse cx="${cx + 15}" cy="${cy - 55}" rx="8" ry="12" fill="#ffffff" stroke="#0f172a" stroke-width="3"/>
        <circle cx="${cx - 13}" cy="${cy - 55}" r="4" fill="#0f172a"/>
        <circle cx="${cx + 17}" cy="${cy - 55}" r="4" fill="#0f172a"/>
        <path d="M ${cx - 18} ${cy - 35} Q ${cx} ${cy - 20} ${cx + 18} ${cy - 35} Z" fill="#ef4444" stroke="#0f172a" stroke-width="3"/>
        <path d="M ${cx - 28} ${cy - 5} L ${cx + 28} ${cy - 5} L ${cx + 38} ${cy + 65} L ${cx - 38} ${cy + 65} Z" fill="#3b82f6" stroke="#1d4ed8" stroke-width="4"/>
      </g>
    `;
  } else {
    styleLabel = 'CINEMATIC REALISTIC';
    badgeColor = '#d97706';
    backgroundGradient = `
      <defs>
        <radialGradient id="cinematic" cx="50%" cy="40%" r="75%">
          <stop offset="0%" stop-color="#1e293b" />
          <stop offset="50%" stop-color="#0f172a" />
          <stop offset="100%" stop-color="#020617" />
        </radialGradient>
        <linearGradient id="rimLight" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.3" />
          <stop offset="100%" stop-color="#3b82f6" stop-opacity="0.2" />
        </linearGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#cinematic)"/>
      <rect width="100%" height="100%" fill="url(#rimLight)"/>
    `;

    illustrationElements = `
      <g>
        <circle cx="${width * 0.5}" cy="${height * 0.45}" r="${Math.min(width, height) * 0.22}" fill="none" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="6 4" opacity="0.4"/>
        <circle cx="${width * 0.5}" cy="${height * 0.45}" r="${Math.min(width, height) * 0.16}" fill="#0f172a" stroke="#64748b" stroke-width="2" opacity="0.8"/>
        <path d="M ${width * 0.5 - 40} ${height * 0.45 + 10} L ${width * 0.5} ${height * 0.45 - 35} L ${width * 0.5 + 40} ${height * 0.45 + 10} Z" fill="#38bdf8" opacity="0.3"/>
      </g>
    `;
  }

  const textColor = style === 'stickman' ? '#0f172a' : '#f8fafc';
  const subtitleColor = style === 'stickman' ? '#64748b' : '#94a3b8';

  const svgContent = `
    <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
      ${backgroundGradient}
      ${illustrationElements}
      <g transform="translate(36, 44)">
        <text x="0" y="20" fill="${textColor}" font-size="15" font-family="system-ui, sans-serif" font-weight="600">${cleanTitle}</text>
      </g>
      <g transform="translate(36, ${height - 70})">
        <rect x="-10" y="-18" width="${width - 52}" height="54" rx="8" fill="#000000" opacity="0.6"/>
        <text x="6" y="2" fill="#ffffff" font-size="11" font-family="system-ui, sans-serif" font-weight="700" letter-spacing="0.5">${styleLabel}</text>
        <text x="6" y="22" fill="${subtitleColor}" font-size="11" font-family="system-ui, sans-serif">${cleanPrompt}...</text>
      </g>
    </svg>
  `;

  fs.writeFileSync(tempSvgPath, svgContent.trim());

  try {
    await execPromise(`ffmpeg -y -i "${tempSvgPath}" "${outputPath}"`);
  } catch (err) {
    console.warn('[imageService] ffmpeg svg conversion failed, saving direct svg:', err);
    fs.copyFileSync(tempSvgPath, outputPath);
  } finally {
    if (fs.existsSync(tempSvgPath)) {
      try {
        fs.unlinkSync(tempSvgPath);
      } catch {}
    }
  }
}
