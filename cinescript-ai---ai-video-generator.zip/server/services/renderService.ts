import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { AnimationStyle, ExportResolution, MotionSpeed, MusicTrack, Scene, SubtitleStyle } from '../types.js';
import { projectManager } from './projectManager.js';
import { generateSceneImage } from './imageService.js';

export interface RenderOptions {
  resolution?: ExportResolution;
  fps?: number;
  crf?: number;
  showCaptions?: boolean;
  subtitleStyle?: SubtitleStyle;
  autoMotion?: boolean;
  motionSpeed?: MotionSpeed;
  narrationVolume?: number;
  lowRamMode?: boolean;
}

interface SpawnFfmpegOptions {
  expectedDurationSec?: number;
  onProgressFraction?: (fraction: number) => void;
}

/**
 * Spawns FFmpeg directly with no stdout/stderr maxBuffer limit so 15-30 minute
 * exports never crash with ERR_CHILD_PROCESS_STDIO_MAXBUFFER.
 */
function runFfmpeg(args: string[], opts: SpawnFfmpegOptions = {}): Promise<void> {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', ['-hide_banner', '-nostdin', ...args], {
      stdio: ['ignore', 'pipe', 'pipe']
    });

    const stderrTail: string[] = [];
    let remainder = '';

    const handleLine = (line: string) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      stderrTail.push(trimmed);
      if (stderrTail.length > 40) {
        stderrTail.shift();
      }

      if (opts.expectedDurationSec && opts.expectedDurationSec > 0 && opts.onProgressFraction) {
        const timeMatch = trimmed.match(/time=(\d+):(\d+):(\d+(?:\.\d+)?)/);
        if (timeMatch) {
          const secs =
            Number(timeMatch[1]) * 3600 +
            Number(timeMatch[2]) * 60 +
            Number(timeMatch[3]);
          if (Number.isFinite(secs)) {
            opts.onProgressFraction(Math.max(0, Math.min(1, secs / opts.expectedDurationSec)));
          }
        }
      }
    };

    proc.stderr.on('data', (chunk: Buffer) => {
      const text = remainder + chunk.toString('utf-8');
      const lines = text.split(/[\r\n]+/);
      remainder = lines.pop() || '';
      for (const l of lines) handleLine(l);
    });

    proc.on('error', (err) => {
      reject(new Error(`Failed to launch FFmpeg: ${err.message}`));
    });

    proc.on('close', (code) => {
      if (remainder) handleLine(remainder);
      if (code === 0) {
        resolve();
      } else {
        const details = stderrTail.slice(-12).join(' | ');
        reject(new Error(`FFmpeg exited with code ${code}: ${details || 'Unknown FFmpeg error'}`));
      }
    });
  });
}

function getSceneDurationSec(scene: Scene): number {
  if (scene.audioDurationSec > 0) return scene.audioDurationSec;
  if (scene.effectiveDurationSec > 0) return scene.effectiveDurationSec;
  if (scene.customDurationSec && scene.customDurationSec > 0) return scene.customDurationSec;
  return 4.0;
}

function resolveMotionConfigServer(
  scene: Scene,
  autoMotion: boolean,
  motionSpeed: MotionSpeed = 'slow'
): { motion: Exclude<AnimationStyle, 'auto'>; zoomDelta: number; panDelta: number } {
  if (!autoMotion) {
    return { motion: 'static', zoomDelta: 0, panDelta: 0 };
  }
  const rawStyle = scene.animationStyle || 'auto';
  const motion: Exclude<AnimationStyle, 'auto'> =
    rawStyle === 'auto'
      ? scene.sequence % 2 === 1
        ? 'slow-zoom-in'
        : 'slow-zoom-out'
      : rawStyle;

  if (motion === 'static') {
    return { motion: 'static', zoomDelta: 0, panDelta: 0 };
  }
  if (motion === 'slow-zoom-in' || motion === 'slow-zoom-out') {
    return { motion, zoomDelta: motionSpeed === 'ultra-slow' ? 0.045 : 0.065, panDelta: 0.018 };
  }
  if (motionSpeed === 'ultra-slow') {
    return { motion, zoomDelta: 0.045, panDelta: 0.015 };
  }
  if (motionSpeed === 'normal') {
    return { motion, zoomDelta: 0.13, panDelta: 0.036 };
  }
  return { motion, zoomDelta: 0.075, panDelta: 0.022 };
}

function formatAssTime(sec: number): string {
  const totalCs = Math.max(0, Math.round(sec * 100));
  const h = Math.floor(totalCs / 360000);
  const m = Math.floor((totalCs % 360000) / 6000);
  const s = Math.floor((totalCs % 6000) / 100);
  const cs = totalCs % 100;
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}

function buildSceneAssSubtitle(
  narration: string,
  durationSec: number,
  width: number,
  height: number,
  subtitleStyle: SubtitleStyle = 'classic-pill'
): string {
  const isPortrait = height > width;
  const marginV = Math.round(height * (isPortrait ? 0.065 : 0.055));
  const marginH = Math.round(width * 0.08);
  let cleanText = narration
    .replace(/\{/g, '(')
    .replace(/\}/g, ')')
    .replace(/\r?\n/g, ' ')
    .trim();

  // Style defaults (ASS colour order is &HAABBGGRR)
  let fontName = 'DejaVu Sans';
  let fontSize = Math.round(height * (isPortrait ? 0.025 : 0.032));
  let primaryColour = '&H00FFFFFF';
  let outlineColour = '&H00090D16';
  let backColour = '&H48160D09';
  let bold = -1;
  let spacing = 0;
  let borderStyle = 3; // 3 = opaque box, 1 = outline + drop shadow
  let outline = 14;
  let shadow = 0;

  if (subtitleStyle === 'youtube-bold') {
    cleanText = cleanText.toUpperCase();
    fontSize = Math.round(height * (isPortrait ? 0.029 : 0.037));
    primaryColour = '&H0015CCFA'; // #FACC15
    outlineColour = '&H00170602'; // #020617
    backColour = '&H80000000';
    borderStyle = 1;
    outline = Math.max(4, Math.round(fontSize * 0.14));
    shadow = 3;
    spacing = 1;
  } else if (subtitleStyle === 'cinematic-clean') {
    fontName = 'DejaVu Serif';
    fontSize = Math.round(height * (isPortrait ? 0.024 : 0.031));
    primaryColour = '&H00FCFAF8';
    outlineColour = '&H20170602';
    backColour = '&H90000000';
    bold = 0;
    borderStyle = 1;
    outline = Math.max(2, Math.round(fontSize * 0.08));
    shadow = 2;
    spacing = 1;
  } else if (subtitleStyle === 'neon-glow') {
    primaryColour = '&H00FEF2E0'; // #E0F2FE
    outlineColour = '&H00F8BD38'; // #38BDF8 sky accent
    backColour = '&H24261408'; // deep navy translucent bar
    borderStyle = 3;
    outline = 13;
    shadow = 2;
  } else if (subtitleStyle === 'paper-light') {
    primaryColour = '&H002A170F'; // #0F172A dark ink
    outlineColour = '&H12FFFFFF';
    backColour = '&H14FFFFFF'; // frosted white card
    borderStyle = 3;
    outline = 14;
    shadow = 0;
  } else if (subtitleStyle === 'minimal-shadow') {
    primaryColour = '&H00FFFFFF';
    outlineColour = '&H30000000';
    backColour = '&H90000000';
    bold = 0;
    borderStyle = 1;
    outline = Math.max(2, Math.round(fontSize * 0.09));
    shadow = 3;
  }

  return `[Script Info]
ScriptType: v4.00+
PlayResX: ${width}
PlayResY: ${height}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,${fontName},${fontSize},${primaryColour},&H000000FF,${outlineColour},${backColour},${bold},0,0,0,100,100,${spacing},0,${borderStyle},${outline},${shadow},2,${marginH},${marginH},${marginV},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,${formatAssTime(0)},${formatAssTime(durationSec)},Default,,0,0,0,,${cleanText}
`;
}

/**
 * Concatenates MP4 clips cleanly using concat demuxer. For long 15-30+ minute videos
 * with 40-500+ scenes, joins in hierarchical batches of 30 clips and deletes intermediate
 * clip files immediately so file descriptors and disk usage remain low.
 */
async function concatClipsHierarchically(
  clipPaths: string[],
  tempClipsDir: string,
  destPath: string,
  fallbackEncodeArgs: string[],
  onStatus?: (msg: string) => void
): Promise<void> {
  if (clipPaths.length === 1) {
    fs.copyFileSync(clipPaths[0], destPath);
    try { fs.unlinkSync(clipPaths[0]); } catch {}
    return;
  }

  const runConcatStep = async (listFiles: string[], outPath: string) => {
    const listPath = path.join(tempClipsDir, `concat_${Date.now()}_${Math.random().toString(36).slice(2, 6)}.txt`);
    const content = listFiles.map(p => `file '${p.replace(/'/g, "'\\''")}'`).join('\n');
    fs.writeFileSync(listPath, content);
    try {
      await runFfmpeg([
        '-y',
        '-f', 'concat',
        '-safe', '0',
        '-i', listPath,
        '-c', 'copy',
        '-fflags', '+genpts',
        '-movflags', '+faststart',
        outPath
      ]);
    } catch {
      await runFfmpeg([
        '-y',
        '-f', 'concat',
        '-safe', '0',
        '-i', listPath,
        ...fallbackEncodeArgs,
        '-movflags', '+faststart',
        outPath
      ]);
    } finally {
      try { fs.unlinkSync(listPath); } catch {}
    }
  };

  const BATCH_SIZE = 30;
  if (clipPaths.length <= BATCH_SIZE) {
    await runConcatStep(clipPaths, destPath);
    for (const p of clipPaths) {
      try { if (fs.existsSync(p)) fs.unlinkSync(p); } catch {}
    }
    return;
  }

  const batchPaths: string[] = [];
  const totalBatches = Math.ceil(clipPaths.length / BATCH_SIZE);

  for (let b = 0; b < totalBatches; b++) {
    const slice = clipPaths.slice(b * BATCH_SIZE, (b + 1) * BATCH_SIZE);
    const batchOut = path.join(tempClipsDir, `batch_${String(b).padStart(3, '0')}.mp4`);
    onStatus?.(`Joining video batch ${b + 1}/${totalBatches} (${slice.length} scenes)...`);
    await runConcatStep(slice, batchOut);
    batchPaths.push(batchOut);
    for (const p of slice) {
      try { if (fs.existsSync(p)) fs.unlinkSync(p); } catch {}
    }
  }

  onStatus?.(`Finalizing combined timeline (${totalBatches} batches)...`);
  await runConcatStep(batchPaths, destPath);
  for (const bp of batchPaths) {
    try { if (fs.existsSync(bp)) fs.unlinkSync(bp); } catch {}
  }
}

export async function renderProjectToMp4(
  projectId: string,
  options: RenderOptions = {}
): Promise<{ outputPath: string; outputUrl: string }> {
  const project = projectManager.getProject(projectId);
  if (!project) {
    throw new Error(`Project ${projectId} not found`);
  }

  if (project.scenes.length === 0) {
    throw new Error('Cannot render project: No scenes available');
  }

  // Ensure all scenes have valid image assets before rendering
  for (const scene of project.scenes) {
    if (!scene.imagePath || !fs.existsSync(scene.imagePath)) {
      console.log(`[renderService] Auto-generating missing image for scene ${scene.sequence}...`);
      projectManager.updateProject(projectId, {
        renderStatus: {
          isRendering: true,
          progress: 5,
          currentStep: `Preparing assets for Scene ${scene.sequence}...`
        }
      });
      const sceneDir = projectManager.getSceneDir(projectId, scene.id);
      const imgRes = await generateSceneImage({
        prompt: scene.imagePrompt,
        aspectRatio: project.settings.aspectRatio,
        style: project.settings.style,
        sceneTitle: scene.title,
        sceneSequence: scene.sequence,
        continuityProfile: project.continuityProfile,
        characterDescriptions: scene.characterDescriptions,
        customApiUrl: project.settings.imageApiUrl,
        imageModel: project.settings.imageModel,
        targetDir: sceneDir,
        fileName: 'image.png'
      });
      scene.imagePath = imgRes.imagePath;
      scene.imageUrl = `/api/media/${projectId}/${scene.id}/image.png?t=${Date.now()}`;
      scene.imageStatus = 'completed';
    }
  }

  const outputDir = projectManager.getOutputDir(projectId);
  const finalMp4Path = path.join(outputDir, 'final-video.mp4');
  const tempClipsDir = path.join(outputDir, 'clips');
  if (fs.existsSync(tempClipsDir)) {
    try { fs.rmSync(tempClipsDir, { recursive: true, force: true }); } catch {}
  }
  fs.mkdirSync(tempClipsDir, { recursive: true });

  const resolution: ExportResolution = options.resolution || '1080p';
  const lowRamMode = Boolean(options.lowRamMode);
  const isPortrait = project.settings.aspectRatio === '9:16';

  let width = 1920;
  let height = 1080;
  if (resolution === '2k') {
    width = isPortrait ? 1440 : 2560;
    height = isPortrait ? 2560 : 1440;
  } else if (resolution === '720p') {
    width = isPortrait ? 720 : 1280;
    height = isPortrait ? 1280 : 720;
  } else {
    width = isPortrait ? 1080 : 1920;
    height = isPortrait ? 1920 : 1080;
  }

  const fps = Math.max(12, Math.min(60, Number(options.fps || project.settings.fps || 30)));
  const crf =
    options.crf ??
    (lowRamMode
      ? resolution === '2k'
        ? 19
        : resolution === '1080p'
        ? 20
        : 22
      : resolution === '2k'
      ? 16
      : resolution === '1080p'
      ? 17
      : 20);
  const preset = lowRamMode ? 'veryfast' : 'fast';
  const threadCount = lowRamMode ? '2' : '0';
  const audioBitrate = lowRamMode
    ? resolution === '2k'
      ? '160k'
      : '128k'
    : resolution === '2k'
    ? '256k'
    : '192k';

  const showCaptions =
    options.showCaptions !== undefined
      ? options.showCaptions
      : project.settings.showCaptions !== undefined
      ? project.settings.showCaptions
      : true;
  const subtitleStyle: SubtitleStyle =
    options.subtitleStyle || project.settings.subtitleStyle || 'classic-pill';
  const autoMotion =
    options.autoMotion !== undefined
      ? options.autoMotion
      : project.settings.autoMotion !== undefined
      ? project.settings.autoMotion
      : true;
  const motionSpeed: MotionSpeed =
    options.motionSpeed || project.settings.motionSpeed || 'slow';

  // Build exact zero-drift cumulative frame timeline at the target export FPS
  let cumulativeSec = 0;
  let cumulativeFrames = 0;
  const minFramesPerScene = Math.max(12, Math.round(0.5 * fps));
  const timelinePlan = project.scenes.map((scene) => {
    const desiredSec = getSceneDurationSec(scene);
    cumulativeSec += desiredSec;
    const targetEndFrame = Math.round(cumulativeSec * fps);
    const frames = Math.max(minFramesPerScene, targetEndFrame - cumulativeFrames);
    const exactClipSec = frames / fps;
    cumulativeFrames += frames;
    return { scene, frames, exactClipSec };
  });
  const totalFrames = cumulativeFrames;
  const exactTotalSec = totalFrames / fps;
  const isLongVideo = exactTotalSec >= 300 || timelinePlan.length >= 40;

  projectManager.updateProject(projectId, {
    renderStatus: {
      isRendering: true,
      progress: 8,
      currentStep: `Initializing ${resolution.toUpperCase()} (${width}×${height} @ ${fps}fps, ${exactTotalSec.toFixed(1)}s)${isLongVideo ? ' · Long-Video Stream' : ''}...`
    }
  });

  const clipPaths: string[] = [];

  try {
    const totalScenes = timelinePlan.length;

    // Single-pass clip encoding (burns captions directly into each clip if showCaptions=true)
    for (let i = 0; i < totalScenes; i++) {
      const { scene, frames, exactClipSec } = timelinePlan[i];
      const stepPercent = 10 + Math.floor((i / totalScenes) * 74);
      const motionCfg = resolveMotionConfigServer(scene, autoMotion, motionSpeed);

      projectManager.updateProject(projectId, {
        renderStatus: {
          isRendering: true,
          progress: stepPercent,
          currentStep: `Encoding ${resolution.toUpperCase()} Scene ${scene.sequence}/${totalScenes} (${motionCfg.motion}): ${scene.title}`
        }
      });

      const clipPath = path.join(tempClipsDir, `clip_${String(i + 1).padStart(4, '0')}.mp4`);
      await renderSceneClip(scene, clipPath, {
        width,
        height,
        fps,
        frames,
        exactClipSec,
        crf,
        preset,
        threadCount,
        audioBitrate,
        motion: motionCfg.motion,
        zoomDelta: motionCfg.zoomDelta,
        showCaptions,
        subtitleStyle,
        lowRamMode: lowRamMode || isLongVideo
      });
      clipPaths.push(clipPath);
    }

    projectManager.updateProject(projectId, {
      renderStatus: {
        isRendering: true,
        progress: 86,
        currentStep: `Joining ${clipPaths.length} scene clips...`
      }
    });

    const joinedBasePath = path.join(tempClipsDir, 'joined_base.mp4');
    const fallbackArgs = [
      '-threads', threadCount,
      '-c:v', 'libx264',
      '-profile:v', 'high',
      '-level:v', '4.1',
      '-preset', preset,
      '-crf', String(crf),
      '-pix_fmt', 'yuv420p',
      '-r', String(fps),
      '-video_track_timescale', '90000',
      '-c:a', 'aac',
      '-b:a', audioBitrate,
      '-ar', '44100',
      '-ac', '2'
    ];

    await concatClipsHierarchically(
      clipPaths,
      tempClipsDir,
      joinedBasePath,
      fallbackArgs,
      (msg) => {
        projectManager.updateProject(projectId, {
          renderStatus: {
            isRendering: true,
            progress: 89,
            currentStep: msg
          }
        });
      }
    );

    const musicTrack: MusicTrack | null | undefined = project.musicTrack;
    const hasValidMusic = Boolean(musicTrack?.filePath && fs.existsSync(musicTrack.filePath));
    const narrVol = Math.max(
      0,
      Math.min(1.5, options.narrationVolume ?? musicTrack?.narrationVolume ?? project.settings.narrationVolume ?? 1.0)
    );

    // Mix background music track + narration, or adjust narration gain cleanly (copying video stream directly)
    if (hasValidMusic && musicTrack && musicTrack.filePath) {
      projectManager.updateProject(projectId, {
        renderStatus: {
          isRendering: true,
          progress: 92,
          currentStep: `Mixing background music (${musicTrack.name}) across ${exactTotalSec.toFixed(1)}s timeline...`
        }
      });

      const musicVol = Math.max(0, Math.min(1, musicTrack.volume ?? 0.22));
      const fadeIn = Math.max(0, Math.min(exactTotalSec / 2, musicTrack.fadeInSec ?? 1.5));
      const fadeOut = Math.max(0, Math.min(exactTotalSec / 2, musicTrack.fadeOutSec ?? 2.0));
      const fadeOutStart = Math.max(0, exactTotalSec - fadeOut);
      const trackDur = Math.max(0.5, musicTrack.durationSec || 10);
      const rawOffset = Math.max(0, musicTrack.startOffsetSec ?? 0);
      const offsetSec = musicTrack.loop ? rawOffset % trackDur : Math.min(rawOffset, Math.max(0, trackDur - 0.1));

      const musicInputArgs = musicTrack.loop
        ? ['-stream_loop', '-1', '-i', musicTrack.filePath]
        : ['-ss', offsetSec.toFixed(3), '-i', musicTrack.filePath];

      const fadeFilters = [
        fadeIn > 0 ? `afade=t=in:st=0:d=${fadeIn.toFixed(3)}` : '',
        fadeOut > 0 ? `afade=t=out:st=${fadeOutStart.toFixed(3)}:d=${fadeOut.toFixed(3)}` : ''
      ]
        .filter(Boolean)
        .join(',');

      const trimExpr = musicTrack.loop && offsetSec > 0.05
        ? `atrim=${offsetSec.toFixed(3)}:${(offsetSec + exactTotalSec).toFixed(3)},asetpts=PTS-STARTPTS`
        : `atrim=0:${exactTotalSec.toFixed(6)},asetpts=PTS-STARTPTS`;

      const musicChain = `[1:a]${trimExpr},apad,atrim=0:${exactTotalSec.toFixed(6)},asetpts=PTS-STARTPTS,volume=${musicVol.toFixed(3)}${fadeFilters ? `,${fadeFilters}` : ''}[bgm]`;
      const narrBase = `[0:a]atrim=0:${exactTotalSec.toFixed(6)},asetpts=PTS-STARTPTS,volume=${narrVol.toFixed(3)}`;

      const filterComplex = musicTrack.ducking
        ? `${narrBase},asplit=2[narr][narr_sc];${musicChain};[bgm][narr_sc]sidechaincompress=threshold=0.025:ratio=4:attack=35:release=260[bgm_ducked];[narr][bgm_ducked]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]`
        : `${narrBase}[narr];${musicChain};[narr][bgm]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]`;

      let lastPct = 92;
      await runFfmpeg(
        [
          '-y',
          '-threads', threadCount,
          '-i', joinedBasePath,
          ...musicInputArgs,
          '-filter_complex', filterComplex,
          '-map', '0:v',
          '-map', '[aout]',
          '-c:v', 'copy',
          '-c:a', 'aac',
          '-b:a', audioBitrate,
          '-ar', '44100',
          '-ac', '2',
          '-t', exactTotalSec.toFixed(6),
          '-movflags', '+faststart',
          finalMp4Path
        ],
        {
          expectedDurationSec: exactTotalSec,
          onProgressFraction: (frac) => {
            const pct = Math.min(99, 92 + Math.floor(frac * 7));
            if (pct > lastPct) {
              lastPct = pct;
              projectManager.updateProject(projectId, {
                renderStatus: {
                  isRendering: true,
                  progress: pct,
                  currentStep: `Finalizing audio mix (${Math.round(frac * 100)}%)...`
                }
              });
            }
          }
        }
      );
    } else if (Math.abs(narrVol - 1.0) > 0.01) {
      await runFfmpeg([
        '-y',
        '-threads', threadCount,
        '-i', joinedBasePath,
        '-c:v', 'copy',
        '-af', `volume=${narrVol.toFixed(3)},atrim=0:${exactTotalSec.toFixed(6)},asetpts=PTS-STARTPTS`,
        '-c:a', 'aac',
        '-b:a', audioBitrate,
        '-ar', '44100',
        '-ac', '2',
        '-t', exactTotalSec.toFixed(6),
        '-movflags', '+faststart',
        finalMp4Path
      ]);
    } else {
      fs.renameSync(joinedBasePath, finalMp4Path);
    }

    if (!fs.existsSync(finalMp4Path) || fs.statSync(finalMp4Path).size === 0) {
      throw new Error('Final MP4 file was not generated or has zero bytes');
    }

    const outputUrl = `/api/project/${projectId}/download`;

    projectManager.updateProject(projectId, {
      renderStatus: {
        isRendering: false,
        progress: 100,
        currentStep: `${resolution.toUpperCase()} MP4 compilation complete (${exactTotalSec.toFixed(1)}s)!`,
        outputFile: finalMp4Path,
        outputUrl,
        completedAt: Date.now()
      }
    });

    return { outputPath: finalMp4Path, outputUrl };
  } catch (err: any) {
    console.error(`[renderService] Render error for project ${projectId}:`, err);
    projectManager.updateProject(projectId, {
      renderStatus: {
        isRendering: false,
        progress: 0,
        currentStep: 'Rendering failed',
        error: err.message || 'Rendering failed'
      }
    });
    throw err;
  } finally {
    try {
      if (fs.existsSync(tempClipsDir)) {
        fs.rmSync(tempClipsDir, { recursive: true, force: true });
      }
    } catch {}
  }
}

async function renderSceneClip(
  scene: Scene,
  outputPath: string,
  config: {
    width: number;
    height: number;
    fps: number;
    frames: number;
    exactClipSec: number;
    crf: number;
    preset: string;
    threadCount: string;
    audioBitrate: string;
    motion: Exclude<AnimationStyle, 'auto'>;
    zoomDelta: number;
    showCaptions: boolean;
    subtitleStyle: SubtitleStyle;
    lowRamMode: boolean;
  }
): Promise<void> {
  const {
    width,
    height,
    fps,
    frames,
    exactClipSec,
    crf,
    preset,
    threadCount,
    audioBitrate,
    motion,
    zoomDelta,
    showCaptions,
    subtitleStyle,
    lowRamMode
  } = config;

  const hasAudio = Boolean(
    scene.audioPath &&
    fs.existsSync(scene.audioPath) &&
    fs.statSync(scene.audioPath).size > 100
  );

  let audioInputPath = scene.audioPath || '';
  let tempAudioCreated = false;
  const silentPath = outputPath.replace(/\.mp4$/, '_silent.aac');
  const assPath = outputPath.replace(/\.mp4$/, '.ass');
  let hasAss = false;

  if (!hasAudio) {
    await runFfmpeg([
      '-y',
      '-f', 'lavfi',
      '-i', 'anullsrc=r=44100:cl=stereo',
      '-t', exactClipSec.toFixed(6),
      '-c:a', 'aac',
      '-b:a', audioBitrate,
      silentPath
    ]);
    audioInputPath = silentPath;
    tempAudioCreated = true;
  }

  if (showCaptions && scene.narration?.trim()) {
    fs.writeFileSync(assPath, buildSceneAssSubtitle(scene.narration, exactClipSec, width, height, subtitleStyle));
    hasAss = true;
  }

  const escapedAss = assPath.replace(/\\/g, '/').replace(/:/g, '\\:');

  const buildFilter = (includeSubs: boolean): string => {
    const subSuffix = includeSubs && hasAss ? `,subtitles='${escapedAss}'` : '';
    const scaleAlgo = lowRamMode ? 'bilinear' : 'lanczos';

    if (motion === 'static') {
      return `scale=${width}:${height}:flags=${scaleAlgo}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=0x030712,setsar=1${subSuffix},fps=${fps},format=yuv420p`;
    }

    // 1.16x-1.28x supersample keeps slow-motion zoompan silky smooth while rendering 2-3x faster on long videos
    const mult = lowRamMode ? 1.16 : width >= 2560 || height >= 2560 ? 1.24 : 1.32;
    const preW = Math.round((width * mult) / 2) * 2;
    const preH = Math.round((height * mult) / 2) * 2;
    const denom = Math.max(1, frames - 1);
    const delta = Math.max(0.02, zoomDelta || 0.075).toFixed(4);
    const panZoom = (1 + Math.max(0.04, (zoomDelta || 0.075) * 0.7)).toFixed(4);
    const easeExpr = `(0.5-0.5*cos(3.14159265*on/${denom}))`;

    let zoomExpr = `1+${delta}*${easeExpr}`;
    let xExpr = 'iw/2-(iw/zoom/2)';
    let yExpr = 'ih/2-(ih/zoom/2)';

    if (motion === 'zoom-out' || motion === 'slow-zoom-out') {
      const startZoom = (1 + Number(delta)).toFixed(4);
      zoomExpr = `${startZoom}-${delta}*${easeExpr}`;
    } else if (motion === 'pan-left') {
      zoomExpr = panZoom;
      xExpr = `(iw-iw/zoom)*(1-${easeExpr})`;
    } else if (motion === 'pan-right') {
      zoomExpr = panZoom;
      xExpr = `(iw-iw/zoom)*${easeExpr}`;
    }

    return `scale=${preW}:${preH}:flags=${scaleAlgo}:force_original_aspect_ratio=decrease,pad=${preW}:${preH}:(ow-iw)/2:(oh-ih)/2:color=0x030712,setsar=1,zoompan=z='${zoomExpr}':x='${xExpr}':y='${yExpr}':d=${frames}:s=${width}x${height}:fps=${fps}${subSuffix},format=yuv420p`;
  };

  const buildArgs = (filterStr: string): string[] => {
    const inputArgs =
      motion === 'static'
        ? ['-loop', '1', '-framerate', String(fps), '-t', exactClipSec.toFixed(6), '-i', scene.imagePath!]
        : ['-i', scene.imagePath!];

    return [
      '-y',
      '-threads', threadCount,
      ...inputArgs,
      '-i', audioInputPath,
      '-vf', filterStr,
      // Explicitly align audio stream to exact clip frame duration so -shortest can never chop video
      '-af', `aresample=async=1:first_pts=0,apad,atrim=0:${exactClipSec.toFixed(6)},asetpts=PTS-STARTPTS`,
      '-c:v', 'libx264',
      '-profile:v', 'high',
      '-level:v', '4.1',
      '-preset', preset,
      ...(motion === 'static' ? ['-tune', 'stillimage'] : []),
      '-crf', String(crf),
      '-r', String(fps),
      '-g', String(Math.max(fps, fps * 2)),
      '-video_track_timescale', '90000',
      '-frames:v', String(frames),
      '-c:a', 'aac',
      '-b:a', audioBitrate,
      '-ar', '44100',
      '-ac', '2',
      '-t', exactClipSec.toFixed(6),
      outputPath
    ];
  };

  try {
    try {
      await runFfmpeg(buildArgs(buildFilter(true)));
    } catch (firstErr) {
      if (hasAss) {
        console.warn('[renderService] Single-pass subtitle filter failed for scene, retrying without subtitles:', firstErr);
        await runFfmpeg(buildArgs(buildFilter(false)));
      } else {
        throw firstErr;
      }
    }
  } finally {
    if (tempAudioCreated && fs.existsSync(silentPath)) {
      try { fs.unlinkSync(silentPath); } catch {}
    }
    if (hasAss && fs.existsSync(assPath)) {
      try { fs.unlinkSync(assPath); } catch {}
    }
  }
}
