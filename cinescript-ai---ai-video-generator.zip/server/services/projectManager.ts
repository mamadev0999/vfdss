import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Project, ProjectSettings, Scene, GenerationMode } from '../types.js';
import { calculateTimeline } from './timelineService.js';

const BASE_TEMP_DIR = path.resolve(process.cwd(), 'project-temp');

if (!fs.existsSync(BASE_TEMP_DIR)) {
  fs.mkdirSync(BASE_TEMP_DIR, { recursive: true });
}

class ProjectManager {
  private projects = new Map<string, Project>();

  createProject(script: string, settings: Partial<ProjectSettings>): Project {
    const id = `proj_${crypto.randomBytes(6).toString('hex')}`;
    const projectDir = path.join(BASE_TEMP_DIR, id);
    fs.mkdirSync(projectDir, { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'scenes'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'output'), { recursive: true });

    const defaultSettings: ProjectSettings = {
      style: settings.style || 'stickman',
      aspectRatio: settings.aspectRatio || '16:9',
      voiceId: settings.voiceId || 'troy',
      generationMode: settings.generationMode || 'both',
      fps: 30,
      autoMotion: settings.autoMotion !== undefined ? settings.autoMotion : true,
      motionSpeed: settings.motionSpeed || 'slow',
      narrationVolume: settings.narrationVolume !== undefined ? settings.narrationVolume : 1.0,
      showCaptions: settings.showCaptions !== undefined ? settings.showCaptions : true,
      subtitleStyle: settings.subtitleStyle || 'classic-pill',
      geminiApiKey: settings.geminiApiKey,
      geminiModel: settings.geminiModel || 'gemini-3.1-flash-lite',
      splitGranularity: settings.splitGranularity || 'very-small',
      groqApiKey: settings.groqApiKey,
      imageApiUrl: settings.imageApiUrl,
      imageModel: settings.imageModel,
      ttsApiKey: settings.ttsApiKey
    };

    const project: Project = {
      id,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      script,
      settings: defaultSettings,
      scenes: [],
      isAnalyzing: false,
      isGenerating: false,
      generationProgress: {
        totalScenes: 0,
        completedScenes: 0,
        currentSceneIndex: 0,
        currentAction: 'Idle',
        percentage: 0
      }
    };

    this.projects.set(id, project);
    this.saveProjectMetadata(project);
    return project;
  }

  getProject(id: string): Project | undefined {
    let project = this.projects.get(id);
    if (!project) {
      // Try restoring from disk
      const metaPath = path.join(BASE_TEMP_DIR, id, 'metadata.json');
      if (fs.existsSync(metaPath)) {
        try {
          const raw = fs.readFileSync(metaPath, 'utf-8');
          project = JSON.parse(raw);
          if (project) {
            this.projects.set(id, project);
          }
        } catch (e) {
          console.warn(`[projectManager] Failed to read disk metadata for ${id}:`, e);
        }
      }
    }
    return project;
  }

  updateProject(id: string, updates: Partial<Project>): Project {
    const project = this.getProject(id);
    if (!project) {
      throw new Error(`Project ${id} not found`);
    }

    Object.assign(project, updates, { updatedAt: Date.now() });

    if (updates.scenes) {
      const { scenes } = calculateTimeline(project.scenes, project.settings.fps);
      project.scenes = scenes;
    }

    this.saveProjectMetadata(project);
    return project;
  }

  getProjectDir(projectId: string): string {
    return path.join(BASE_TEMP_DIR, projectId);
  }

  getSceneDir(projectId: string, sceneId: string): string {
    const sceneDir = path.join(BASE_TEMP_DIR, projectId, 'scenes', sceneId);
    if (!fs.existsSync(sceneDir)) {
      fs.mkdirSync(sceneDir, { recursive: true });
    }
    return sceneDir;
  }

  getOutputDir(projectId: string): string {
    const outputDir = path.join(BASE_TEMP_DIR, projectId, 'output');
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    return outputDir;
  }

  getMusicDir(projectId: string): string {
    const musicDir = path.join(BASE_TEMP_DIR, projectId, 'music');
    if (!fs.existsSync(musicDir)) {
      fs.mkdirSync(musicDir, { recursive: true });
    }
    return musicDir;
  }

  private saveProjectMetadata(project: Project) {
    try {
      const metaPath = path.join(BASE_TEMP_DIR, project.id, 'metadata.json');
      fs.writeFileSync(metaPath, JSON.stringify(project, null, 2));
    } catch (e) {
      console.warn(`[projectManager] Error writing project metadata:`, e);
    }
  }

  // Periodic safe cleanup of abandoned projects older than 4 hours
  cleanupAbandonedProjects() {
    const FOUR_HOURS = 4 * 60 * 60 * 1000;
    const now = Date.now();

    for (const [id, project] of this.projects.entries()) {
      const isBusy = Boolean(project.renderStatus?.isRendering || project.isGenerating || project.isAnalyzing);
      if (!isBusy && now - project.updatedAt > FOUR_HOURS) {
        console.log(`[projectManager] Cleaning up abandoned project ${id}`);
        this.projects.delete(id);
        const pDir = path.join(BASE_TEMP_DIR, id);
        if (fs.existsSync(pDir)) {
          try {
            fs.rmSync(pDir, { recursive: true, force: true });
          } catch {}
        }
      }
    }
  }
}

export const projectManager = new ProjectManager();

// Run periodic cleanup every 30 minutes
setInterval(() => {
  projectManager.cleanupAbandonedProjects();
}, 30 * 60 * 1000);
