import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { exec } from 'child_process';
import util from 'util';
import { MusicPreset, MusicTrack } from '../types.js';
import { measureAudioDuration } from './audioService.js';

const execPromise = util.promisify(exec);

const PRESET_CACHE_DIR = path.join('/tmp', 'cinescript_music_presets');
if (!fs.existsSync(PRESET_CACHE_DIR)) {
  fs.mkdirSync(PRESET_CACHE_DIR, { recursive: true });
}

interface InternalMusicPreset extends MusicPreset {
  filterExpr: string;
  postAf: string;
}

const INTERNAL_PRESETS: InternalMusicPreset[] = [
  {
    id: 'ambient-space',
    name: 'Deep Cosmic Pad',
    mood: 'Atmospheric · Storytelling',
    bpm: 72,
    durationSec: 24,
    audioUrl: '/api/music/presets/ambient-space/audio',
    // Warm Am9 -> Fmaj7 -> C -> G slow atmospheric pad in stereo
    filterExpr:
      "aevalsrc='0.14*sin(2*PI*110*t)+0.11*sin(2*PI*220*t)*(0.6+0.4*sin(2*PI*0.125*t))+0.09*sin(2*PI*261.63*t)+0.08*sin(2*PI*329.63*t)*(0.55+0.45*cos(2*PI*0.083*t))+0.06*sin(2*PI*493.88*t)*(0.5+0.5*sin(2*PI*0.166*t))|0.14*sin(2*PI*110.4*t)+0.11*sin(2*PI*220.6*t)*(0.6+0.4*cos(2*PI*0.125*t))+0.09*sin(2*PI*261.9*t)+0.08*sin(2*PI*330.2*t)*(0.55+0.45*sin(2*PI*0.083*t))+0.06*sin(2*PI*494.4*t)*(0.5+0.5*cos(2*PI*0.166*t))':s=44100:d=24",
    postAf: 'lowpass=f=1350,aecho=0.8:0.88:60|90:0.35|0.25,afade=t=in:st=0:d=1.2,afade=t=out:st=22.5:d=1.5'
  },
  {
    id: 'cinematic-piano',
    name: 'Warm Cinematic Horizon',
    mood: 'Emotional · Documentary',
    bpm: 84,
    durationSec: 20,
    audioUrl: '/api/music/presets/cinematic-piano/audio',
    // Gentle warm plucked chime / Rhodes chord feel with decay pulses
    filterExpr:
      "aevalsrc='0.18*sin(2*PI*130.81*t)*exp(-1.2*mod(t,2.5))+0.14*sin(2*PI*261.63*t)*exp(-1.5*mod(t,1.25))+0.11*sin(2*PI*329.63*t)*exp(-1.8*mod(t+0.625,1.25))+0.10*sin(2*PI*392.00*t)*exp(-1.6*mod(t+0.3125,2.5))+0.07*sin(2*PI*523.25*t)*exp(-2.2*mod(t,2.5))|0.18*sin(2*PI*131.0*t)*exp(-1.2*mod(t,2.5))+0.14*sin(2*PI*262.1*t)*exp(-1.5*mod(t,1.25))+0.11*sin(2*PI*330.1*t)*exp(-1.8*mod(t+0.625,1.25))+0.10*sin(2*PI*392.4*t)*exp(-1.6*mod(t+0.3125,2.5))+0.07*sin(2*PI*523.8*t)*exp(-2.2*mod(t,2.5))':s=44100:d=20",
    postAf: 'lowpass=f=1800,aecho=0.8:0.85:70|140:0.4|0.28,afade=t=in:st=0:d=0.6,afade=t=out:st=18.8:d=1.2'
  },
  {
    id: 'lofi-chill',
    name: 'Lo-Fi Study Groove',
    mood: 'Calm · Explainer',
    bpm: 80,
    durationSec: 16,
    audioUrl: '/api/music/presets/lofi-chill/audio',
    // Soft Rhodes seventh chords + subtle warm bass pulse
    filterExpr:
      "aevalsrc='0.16*sin(2*PI*98*t)*(0.6+0.4*sin(2*PI*0.5*t))+0.12*sin(2*PI*246.94*t)*exp(-0.9*mod(t,2))+0.10*sin(2*PI*293.66*t)*exp(-0.9*mod(t,2))+0.09*sin(2*PI*369.99*t)*exp(-1.1*mod(t+1,2))|0.16*sin(2*PI*98.2*t)*(0.6+0.4*cos(2*PI*0.5*t))+0.12*sin(2*PI*247.3*t)*exp(-0.9*mod(t,2))+0.10*sin(2*PI*294.1*t)*exp(-0.9*mod(t,2))+0.09*sin(2*PI*370.4*t)*exp(-1.1*mod(t+1,2))':s=44100:d=16",
    postAf: 'lowpass=f=1100,aecho=0.75:0.8:45:0.25,afade=t=in:st=0:d=0.5,afade=t=out:st=15.0:d=1.0'
  },
  {
    id: 'upbeat-tech',
    name: 'Modern Creator Pulse',
    mood: 'Upbeat · Tech & Shorts',
    bpm: 110,
    durationSec: 16,
    audioUrl: '/api/music/presets/upbeat-tech/audio',
    // Clean rhythmic pulse + major pentatonic shimmer
    filterExpr:
      "aevalsrc='0.15*sin(2*PI*146.83*t)*exp(-3.5*mod(t,0.5))+0.11*sin(2*PI*293.66*t)*exp(-2.5*mod(t,1.0))+0.09*sin(2*PI*440*t)*exp(-3.0*mod(t+0.25,0.5))+0.07*sin(2*PI*587.33*t)*exp(-2.8*mod(t+0.5,1.0))|0.15*sin(2*PI*147.1*t)*exp(-3.5*mod(t,0.5))+0.11*sin(2*PI*294.0*t)*exp(-2.5*mod(t,1.0))+0.09*sin(2*PI*440.6*t)*exp(-3.0*mod(t+0.25,0.5))+0.07*sin(2*PI*587.9*t)*exp(-2.8*mod(t+0.5,1.0))':s=44100:d=16",
    postAf: 'lowpass=f=2200,aecho=0.75:0.82:55|110:0.3|0.2,afade=t=in:st=0:d=0.4,afade=t=out:st=15.2:d=0.8'
  }
];

export function listMusicPresets(): MusicPreset[] {
  return INTERNAL_PRESETS.map(({ id, name, mood, bpm, durationSec, audioUrl }) => ({
    id,
    name,
    mood,
    bpm,
    durationSec,
    audioUrl
  }));
}

export async function ensurePresetAudioFile(presetId: string): Promise<{ filePath: string; preset: InternalMusicPreset }> {
  const preset = INTERNAL_PRESETS.find(p => p.id === presetId);
  if (!preset) {
    throw new Error(`Unknown music preset: ${presetId}`);
  }

  const filePath = path.join(PRESET_CACHE_DIR, `${preset.id}.mp3`);
  if (fs.existsSync(filePath) && fs.statSync(filePath).size > 2000) {
    return { filePath, preset };
  }

  const cmd = `ffmpeg -y -f lavfi -i "${preset.filterExpr}" -af "${preset.postAf}" -ar 44100 -ac 2 -c:a libmp3lame -b:a 192k "${filePath}"`;
  await execPromise(cmd);

  if (!fs.existsSync(filePath) || fs.statSync(filePath).size < 1000) {
    throw new Error(`Failed to synthesize preset track ${preset.name}`);
  }

  return { filePath, preset };
}

export async function assignPresetMusicToProject(
  projectId: string,
  musicDir: string,
  presetId: string,
  overrides?: Partial<MusicTrack>
): Promise<MusicTrack> {
  if (!fs.existsSync(musicDir)) {
    fs.mkdirSync(musicDir, { recursive: true });
  }

  const { filePath: cachedPath, preset } = await ensurePresetAudioFile(presetId);
  const destPath = path.join(musicDir, 'background-music.mp3');
  fs.copyFileSync(cachedPath, destPath);

  const durationSec = (await measureAudioDuration(destPath)) || preset.durationSec;

  return {
    id: `bgm_${crypto.randomBytes(4).toString('hex')}`,
    name: preset.name,
    source: 'preset',
    presetId: preset.id,
    filePath: destPath,
    audioUrl: `/api/project/${projectId}/music/file?t=${Date.now()}`,
    durationSec: Number(durationSec.toFixed(2)),
    volume: overrides?.volume ?? 0.22,
    narrationVolume: overrides?.narrationVolume ?? 1.0,
    fadeInSec: overrides?.fadeInSec ?? 1.5,
    fadeOutSec: overrides?.fadeOutSec ?? 2.0,
    loop: overrides?.loop ?? true,
    ducking: overrides?.ducking ?? true,
    startOffsetSec: overrides?.startOffsetSec ?? 0
  };
}

export async function saveUploadedMusicToProject(
  projectId: string,
  musicDir: string,
  params: {
    fileName: string;
    base64Data: string;
    overrides?: Partial<MusicTrack>;
  }
): Promise<MusicTrack> {
  if (!fs.existsSync(musicDir)) {
    fs.mkdirSync(musicDir, { recursive: true });
  }

  const cleanBase64 = params.base64Data.includes(',')
    ? params.base64Data.split(',')[1]
    : params.base64Data;
  const rawBuffer = Buffer.from(cleanBase64, 'base64');

  if (rawBuffer.byteLength < 256) {
    throw new Error('Uploaded audio file is empty or too small.');
  }

  const ext = path.extname(params.fileName || '.mp3').toLowerCase() || '.mp3';
  const rawUploadPath = path.join(musicDir, `upload_raw${ext}`);
  const normalizedMp3Path = path.join(musicDir, 'background-music.mp3');

  fs.writeFileSync(rawUploadPath, rawBuffer);

  try {
    // Normalize any user upload (.wav, .m4a, .aac, .ogg, .mp3) into crisp 44.1 kHz stereo MP3
    await execPromise(
      `ffmpeg -y -i "${rawUploadPath}" -vn -ar 44100 -ac 2 -c:a libmp3lame -b:a 192k "${normalizedMp3Path}"`
    );
  } finally {
    try {
      if (fs.existsSync(rawUploadPath)) fs.unlinkSync(rawUploadPath);
    } catch {}
  }

  if (!fs.existsSync(normalizedMp3Path) || fs.statSync(normalizedMp3Path).size < 256) {
    throw new Error('Unable to decode uploaded audio file. Please upload a valid MP3, WAV, M4A, or OGG file.');
  }

  const durationSec = (await measureAudioDuration(normalizedMp3Path)) || 10;
  const cleanName = path.basename(params.fileName || 'Custom Music Track', ext);

  return {
    id: `bgm_${crypto.randomBytes(4).toString('hex')}`,
    name: cleanName,
    source: 'upload',
    filePath: normalizedMp3Path,
    audioUrl: `/api/project/${projectId}/music/file?t=${Date.now()}`,
    durationSec: Number(durationSec.toFixed(2)),
    volume: params.overrides?.volume ?? 0.22,
    narrationVolume: params.overrides?.narrationVolume ?? 1.0,
    fadeInSec: params.overrides?.fadeInSec ?? 1.5,
    fadeOutSec: params.overrides?.fadeOutSec ?? 2.0,
    loop: params.overrides?.loop ?? true,
    ducking: params.overrides?.ducking ?? true,
    startOffsetSec: params.overrides?.startOffsetSec ?? 0
  };
}
