import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import util from 'util';
import { VoiceOption } from '../types.js';

const execPromise = util.promisify(exec);

export const GROQ_ORPHEUS_VOICES = new Set(['troy', 'daniel', 'austin', 'hannah', 'diana', 'autumn']);

const EDGE_FEMALE_CHAIN = ['en-US-AriaNeural', 'en-US-AvaNeural', 'en-GB-SoniaNeural', 'en-US-EmmaNeural', 'en-US-JennyNeural'];
const EDGE_MALE_CHAIN = ['en-US-ChristopherNeural', 'en-US-AndrewNeural', 'en-US-GuyNeural', 'en-GB-RyanNeural'];

const ORPHEUS_TO_EDGE_FALLBACK: Record<string, string[]> = {
  troy: ['en-US-ChristopherNeural', 'en-US-AndrewNeural', 'en-US-GuyNeural', 'en-GB-RyanNeural'],
  daniel: ['en-GB-RyanNeural', 'en-US-ChristopherNeural', 'en-US-AndrewNeural', 'en-US-GuyNeural'],
  austin: ['en-US-GuyNeural', 'en-US-AndrewNeural', 'en-US-ChristopherNeural', 'en-GB-RyanNeural'],
  hannah: ['en-US-AriaNeural', 'en-US-AvaNeural', 'en-GB-SoniaNeural', 'en-US-JennyNeural'],
  diana: ['en-US-AriaNeural', 'en-US-EmmaNeural', 'en-GB-SoniaNeural', 'en-US-AvaNeural'],
  autumn: ['en-GB-SoniaNeural', 'en-US-AriaNeural', 'en-US-AvaNeural', 'en-US-EmmaNeural'],
  'en-US-ChristopherNeural': EDGE_MALE_CHAIN,
  'en-US-JennyNeural': EDGE_FEMALE_CHAIN
};

export const SUPPORTED_VOICES: VoiceOption[] = [
  {
    id: 'troy',
    name: 'Troy',
    displayName: 'Troy — Groq Orpheus (Male - Storyteller)',
    language: 'English (US)',
    gender: 'Male',
    provider: 'groq',
    description: 'Warm, dynamic, ultra-natural Groq Orpheus neural narration voice. Ideal for engaging stories and explainers.',
    sampleText: 'The universe is full of mysteries waiting to be unveiled.'
  },
  {
    id: 'daniel',
    name: 'Daniel',
    displayName: 'Daniel — Groq Orpheus (Male - Deep Cinematic)',
    language: 'English',
    gender: 'Male',
    provider: 'groq',
    description: 'Deep, authoritative, and expressive Groq Orpheus voice suited for documentaries and dramatic narration.',
    sampleText: 'Every great journey begins with a single spark of curiosity.'
  },
  {
    id: 'austin',
    name: 'Austin',
    displayName: 'Austin — Groq Orpheus (Male - Crisp & Energetic)',
    language: 'English (US)',
    gender: 'Male',
    provider: 'groq',
    description: 'Clean, upbeat, and articulate Groq Orpheus voice ideal for fast-paced short videos.',
    sampleText: 'Here is how modern technology transforms our daily routines.'
  },
  {
    id: 'hannah',
    name: 'Hannah',
    displayName: 'Hannah — Groq Orpheus (Female - Warm & Expressive)',
    language: 'English (US)',
    gender: 'Female',
    provider: 'groq',
    description: 'Friendly, expressive Groq Orpheus female voice with natural human rhythm and inflection.',
    sampleText: 'Welcome to this complete guide on bringing stories to life.'
  },
  {
    id: 'diana',
    name: 'Diana',
    displayName: 'Diana — Groq Orpheus (Female - Clear & Confident)',
    language: 'English (US)',
    gender: 'Female',
    provider: 'groq',
    description: 'Polished, studio-quality Groq Orpheus female voice for educational and narrative scripts.',
    sampleText: 'Deep within the ancient forest, quiet secrets lie in wait.'
  },
  {
    id: 'autumn',
    name: 'Autumn',
    displayName: 'Autumn — Groq Orpheus (Female - Natural Narrator)',
    language: 'English (US)',
    gender: 'Female',
    provider: 'groq',
    description: 'Smooth, balanced default Groq Orpheus voice with crisp pronunciation.',
    sampleText: 'A remarkable discovery has reshaped our view of the cosmos.'
  },
  {
    id: 'en-US-ChristopherNeural',
    name: 'Christopher (Edge Backup)',
    displayName: 'Christopher — Edge Neural Backup (Male)',
    language: 'English (US)',
    gender: 'Male',
    provider: 'edge',
    description: 'Built-in Microsoft Edge neural voice (used automatically as backup if Groq Orpheus is unavailable).',
    sampleText: 'The universe is full of mysteries waiting to be unveiled.'
  },
  {
    id: 'en-US-JennyNeural',
    name: 'Jenny (Edge Backup)',
    displayName: 'Jenny — Edge Neural Backup (Female)',
    language: 'English (US)',
    gender: 'Female',
    provider: 'edge',
    description: 'Built-in Microsoft Edge neural female voice.',
    sampleText: 'Welcome to this complete guide on creating videos with AI.'
  }
];

export async function measureAudioDuration(filePath: string): Promise<number> {
  try {
    const { stdout } = await execPromise(
      `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${filePath}"`
    );
    const duration = parseFloat(stdout.trim());
    if (!isNaN(duration) && duration > 0) {
      return Number(duration.toFixed(3));
    }
  } catch (err) {
    console.warn(`[audioService] ffprobe failed for ${filePath}:`, err);
  }

  try {
    const stats = fs.statSync(filePath);
    const estimated = stats.size / 24000;
    return Math.max(1.2, Number(estimated.toFixed(2)));
  } catch {
    return 3.0;
  }
}

/**
 * Sanitizes text before sending to msedge-tts (which embeds text inside raw SSML XML).
 * Prevents XML/SSML stream crashes caused by '&', '<', '>', control bytes, or symbol-only strings.
 */
export function sanitizeTextForEdgeTts(rawText: string): string {
  let cleaned = (rawText || '')
    // Remove ASCII control characters except standard whitespace
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, ' ')
    // Convert '&' to spoken 'and' so XML never breaks and narration sounds natural
    .replace(/&/g, ' and ')
    // Strip angle brackets that would corrupt SSML tags
    .replace(/[<>]/g, ' ')
    // Normalize fancy quotes/dashes
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/\s+/g, ' ')
    .trim();

  // If text has zero letters/digits (e.g., "..." or "---"), replace with speakable fallback
  if (!/[a-zA-Z0-9\u00C0-\u024F\u0400-\u04FF\u0900-\u097F\u4E00-\u9FFF]/.test(cleaned)) {
    cleaned = 'Next scene.';
  }

  return cleaned;
}

/**
 * Splits narration cleanly under Groq Orpheus's 200-character limit per request
 * without breaking words or losing punctuation.
 */
export function splitTextForOrpheus(text: string, maxLen = 185): string[] {
  const normalized = (text || '').replace(/\s+/g, ' ').trim();
  if (!normalized) return ['Next scene.'];
  if (normalized.length <= maxLen) return [normalized];

  const chunks: string[] = [];
  const sentences = normalized.split(/(?<=[.!?])\s+/).filter(Boolean);

  let current = '';
  const pushOrSplitPart = (part: string) => {
    if (part.length <= maxLen) {
      if (!current) {
        current = part;
      } else if (current.length + 1 + part.length <= maxLen) {
        current = `${current} ${part}`;
      } else {
        chunks.push(current);
        current = part;
      }
      return;
    }

    if (current) {
      chunks.push(current);
      current = '';
    }
    const words = part.split(/\s+/);
    let buf = '';
    for (const w of words) {
      if (w.length > maxLen) {
        if (buf) {
          chunks.push(buf);
          buf = '';
        }
        for (let i = 0; i < w.length; i += maxLen) {
          chunks.push(w.slice(i, i + maxLen));
        }
      } else if (!buf) {
        buf = w;
      } else if (buf.length + 1 + w.length <= maxLen) {
        buf = `${buf} ${w}`;
      } else {
        chunks.push(buf);
        buf = w;
      }
    }
    if (buf) {
      current = buf;
    }
  };

  for (const s of sentences) {
    pushOrSplitPart(s);
  }
  if (current) {
    chunks.push(current);
  }

  return chunks;
}

async function callGroqSpeechChunk(textChunk: string, voice: string, apiKey: string): Promise<Buffer> {
  const maxRetries = 2;
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);

    try {
      const res = await fetch('https://api.groq.com/openai/v1/audio/speech', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'canopylabs/orpheus-v1-english',
          voice,
          input: textChunk,
          response_format: 'wav'
        }),
        signal: controller.signal
      });
      clearTimeout(timeout);

      if (res.ok) {
        const arrayBuf = await res.arrayBuffer();
        const buf = Buffer.from(arrayBuf);
        if (buf.length < 100) {
          throw new Error('Groq TTS returned empty audio buffer.');
        }
        return buf;
      }

      const errText = await res.text();
      let errMsg = errText;
      try {
        const json = JSON.parse(errText);
        errMsg = json.error?.message || errText;
      } catch {}

      // Do not retry auth or validation/terms errors
      if (res.status === 401 || res.status === 403 || res.status === 400) {
        throw new Error(`Groq TTS error (HTTP ${res.status}): ${errMsg}`);
      }

      lastError = new Error(`Groq TTS error (HTTP ${res.status}): ${errMsg}`);
      if (attempt < maxRetries) {
        const waitMs = 1000 * (attempt + 1);
        await new Promise(r => setTimeout(r, waitMs));
      }
    } catch (err: any) {
      clearTimeout(timeout);
      lastError = err;
      if (err.message?.includes('HTTP 401') || err.message?.includes('HTTP 403') || err.message?.includes('HTTP 400')) {
        throw err;
      }
      if (attempt < maxRetries) {
        await new Promise(r => setTimeout(r, 800 * (attempt + 1)));
      }
    }
  }

  throw lastError || new Error('Groq TTS synthesis failed');
}

async function generateWithGroqOrpheus(
  text: string,
  voice: string,
  apiKey: string,
  targetDir: string,
  fileName: string
): Promise<{ audioPath: string; durationSec: number }> {
  const finalPath = path.join(targetDir, fileName);
  const chunks = splitTextForOrpheus(text, 185);
  const tempWavFiles: string[] = [];

  try {
    for (let i = 0; i < chunks.length; i++) {
      const wavBuf = await callGroqSpeechChunk(chunks[i], voice, apiKey);
      const chunkWavPath = path.join(targetDir, `.groq_${Date.now()}_${i}.wav`);
      fs.writeFileSync(chunkWavPath, wavBuf);
      tempWavFiles.push(chunkWavPath);
    }

    if (tempWavFiles.length === 1) {
      await execPromise(
        `ffmpeg -y -i "${tempWavFiles[0]}" -vn -c:a libmp3lame -b:a 192k -ar 44100 -ac 2 "${finalPath}"`
      );
    } else {
      const inputs = tempWavFiles.map(f => `-i "${f}"`).join(' ');
      const filterInputs = tempWavFiles.map((_, idx) => `[${idx}:a]`).join('');
      await execPromise(
        `ffmpeg -y ${inputs} -filter_complex "${filterInputs}concat=n=${tempWavFiles.length}:v=0:a=1[out]" -map "[out]" -c:a libmp3lame -b:a 192k -ar 44100 -ac 2 "${finalPath}"`
      );
    }
  } finally {
    for (const tmp of tempWavFiles) {
      if (fs.existsSync(tmp)) {
        try { fs.unlinkSync(tmp); } catch {}
      }
    }
  }

  if (!fs.existsSync(finalPath) || fs.statSync(finalPath).size === 0) {
    throw new Error(`Failed to create Groq TTS audio file at ${finalPath}`);
  }

  const durationSec = await measureAudioDuration(finalPath);
  return { audioPath: finalPath, durationSec };
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: NodeJS.Timeout;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer));
}

async function generateWithEdgeFallback(
  text: string,
  voiceId: string,
  targetDir: string,
  fileName: string
): Promise<{ audioPath: string; durationSec: number }> {
  const safeText = sanitizeTextForEdgeTts(text);
  const voiceChain =
    ORPHEUS_TO_EDGE_FALLBACK[voiceId] ||
    (voiceId.endsWith('Neural') ? [voiceId, ...EDGE_MALE_CHAIN] : EDGE_MALE_CHAIN);
  const finalPath = path.join(targetDir, fileName);

  const maxAttempts = Math.max(4, voiceChain.length);
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const edgeVoice = voiceChain[(attempt - 1) % voiceChain.length];
    const isolatedTmpDir = fs.mkdtempSync(path.join(targetDir, '.edge_tmp_'));
    const tts = new MsEdgeTTS();

    try {
      await withTimeout(
        (async () => {
          await tts.setMetadata(edgeVoice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
          const result = await tts.toFile(isolatedTmpDir, safeText);
          const generatedPath = result.audioFilePath;

          if (!generatedPath || !fs.existsSync(generatedPath) || fs.statSync(generatedPath).size < 100) {
            throw new Error('Edge TTS produced empty audio output.');
          }

          // Normalize Edge 24kHz mono MP3 to uniform 44.1kHz stereo 192k MP3 for clean FFmpeg/Remotion sync
          try {
            await execPromise(
              `ffmpeg -y -i "${generatedPath}" -vn -c:a libmp3lame -b:a 192k -ar 44100 -ac 2 "${finalPath}"`
            );
          } catch (ffmpegErr) {
            console.warn('[audioService] FFmpeg MP3 normalize fallback, copying raw Edge MP3:', ffmpegErr);
            fs.copyFileSync(generatedPath, finalPath);
          }
        })(),
        15000,
        `Edge TTS (${edgeVoice})`
      );

      if (!fs.existsSync(finalPath) || fs.statSync(finalPath).size === 0) {
        throw new Error(`Failed to write normalized audio file at ${finalPath}`);
      }

      const durationSec = await measureAudioDuration(finalPath);
      return { audioPath: finalPath, durationSec };
    } catch (err: any) {
      lastError = err;
      console.warn(`[audioService] Edge TTS attempt ${attempt}/${maxAttempts} failed (${edgeVoice}):`, err?.message || err);
      if (attempt < maxAttempts) {
        await new Promise(r => setTimeout(r, 500 * attempt));
      }
    } finally {
      try { tts.close(); } catch {}
      try {
        fs.rmSync(isolatedTmpDir, { recursive: true, force: true });
      } catch {}
    }
  }

  throw lastError || new Error('Edge Neural TTS synthesis failed');
}

export async function generateSpeechAudio(
  text: string,
  voiceId: string,
  targetDir: string,
  fileName = 'voice.mp3',
  groqApiKey?: string
): Promise<{ audioPath: string; durationSec: number; provider: 'groq' | 'edge'; fallbackNote?: string }> {
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  const effectiveGroqKey = (groqApiKey || process.env.GROQ_API_KEY || '').trim();
  const isOrpheusVoice = GROQ_ORPHEUS_VOICES.has(voiceId);

  if (effectiveGroqKey && (isOrpheusVoice || !voiceId.endsWith('Neural'))) {
    const orpheusVoice = isOrpheusVoice ? voiceId : 'troy';
    try {
      console.log(`[audioService] Synthesizing via Groq Orpheus TTS (voice=${orpheusVoice})...`);
      const res = await generateWithGroqOrpheus(text, orpheusVoice, effectiveGroqKey, targetDir, fileName);
      return { ...res, provider: 'groq' };
    } catch (groqErr: any) {
      const reason = groqErr?.message || 'Groq Orpheus unavailable';
      console.warn(`[audioService] Groq Orpheus failed (${reason}). Falling back cleanly to Edge Neural backup...`);
      const res = await generateWithEdgeFallback(text, voiceId, targetDir, fileName);
      return { ...res, provider: 'edge', fallbackNote: reason };
    }
  }

  console.log(`[audioService] Synthesizing via Edge Neural voice (${voiceId})...`);
  const res = await generateWithEdgeFallback(text, voiceId, targetDir, fileName);
  return { ...res, provider: 'edge' };
}

export async function testGroqTts(params: {
  apiKey?: string;
  voiceId?: string;
}): Promise<{
  ok: boolean;
  voice: string;
  keySource: 'custom' | 'server-env' | 'none';
  latencyMs: number;
  durationSec?: number;
  audioPreviewUrl?: string;
  requiresTermsAcceptance?: boolean;
  termsUrl?: string;
  error?: string;
}> {
  const customKey = (params.apiKey || '').trim();
  const envKey = (process.env.GROQ_API_KEY || '').trim();
  const effectiveKey = customKey || envKey;
  const keySource: 'custom' | 'server-env' | 'none' = customKey ? 'custom' : envKey ? 'server-env' : 'none';
  const voice = GROQ_ORPHEUS_VOICES.has(params.voiceId || '') ? params.voiceId! : 'troy';

  if (!effectiveKey) {
    return {
      ok: false,
      voice,
      keySource,
      latencyMs: 0,
      error: 'No Groq API Key provided. Paste your gsk_... key above to enable Groq Orpheus voice generation.'
    };
  }

  const startTime = Date.now();
  const tmpDir = path.join('/tmp', 'groq_tts_test');
  if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
  }

  try {
    const { audioPath, durationSec } = await generateWithGroqOrpheus(
      'Groq voice generation is active and crystal clear.',
      voice,
      effectiveKey,
      tmpDir,
      `test_${voice}_${Date.now()}.mp3`
    );
    const latencyMs = Date.now() - startTime;
    const mp3Bytes = fs.readFileSync(audioPath);
    const audioPreviewUrl = `data:audio/mpeg;base64,${mp3Bytes.toString('base64')}`;
    try { fs.unlinkSync(audioPath); } catch {}
    return {
      ok: true,
      voice,
      keySource,
      latencyMs,
      durationSec,
      audioPreviewUrl
    };
  } catch (err: any) {
    const msg = err.message || 'Groq TTS test failed';
    const requiresTerms = /requires terms acceptance/i.test(msg);
    const termsMatch = msg.match(/https:\/\/console\.groq\.com[^\s"']+/);
    return {
      ok: false,
      voice,
      keySource,
      latencyMs: Date.now() - startTime,
      requiresTermsAcceptance: requiresTerms,
      termsUrl: termsMatch ? termsMatch[0] : (requiresTerms ? 'https://console.groq.com/playground?model=canopylabs%2Forpheus-v1-english' : undefined),
      error: msg
    };
  }
}

export async function generateVoicePreview(voiceId: string, groqApiKey?: string): Promise<Buffer> {
  const voice = SUPPORTED_VOICES.find(v => v.id === voiceId) || SUPPORTED_VOICES[0];
  const effectiveGroqKey = (groqApiKey || process.env.GROQ_API_KEY || '').trim();

  const tmpDir = path.join('/tmp', 'voice_previews');
  if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
  }

  const edgeCachePath = path.join(tmpDir, `${voice.id}_edge_v2.mp3`);
  if (!effectiveGroqKey && fs.existsSync(edgeCachePath) && fs.statSync(edgeCachePath).size > 200) {
    return fs.readFileSync(edgeCachePath);
  }

  const outFile = effectiveGroqKey ? `${voice.id}_live_${Date.now()}.mp3` : `${voice.id}_edge_v2.mp3`;
  const result = await generateSpeechAudio(voice.sampleText, voice.id, tmpDir, outFile, effectiveGroqKey);
  const buffer = fs.readFileSync(result.audioPath);

  if (effectiveGroqKey && fs.existsSync(result.audioPath)) {
    try { fs.unlinkSync(result.audioPath); } catch {}
  }

  return buffer;
}
