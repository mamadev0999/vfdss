import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import { VisualStyle, AspectRatio, Scene, ContinuityProfile, SplitGranularity } from '../types.js';

const DEFAULT_GEMINI_API_KEY = 'AQ.Ab8RN6JeWoBYSogU5lPhdaZ12yO2mvh6dWIUbGWEemkmGHjJMQ';

export const GEMINI_MODELS = [
  { id: 'gemini-3.1-flash-lite', label: 'Gemini 3.1 Flash Lite (Recommended - Auto-Fallback Enabled)' },
  { id: 'gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash Lite (Ultra-Fast High Availability)' },
  { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash (Balanced & Fast)' },
  { id: 'gemini-4-hydrogen', label: 'Gemini 4 Hydrogen (Deep Reasoning)' },
  { id: 'gemini-flash-lite-latest', label: 'Gemini Flash Lite Latest' },
  { id: 'gemini-3.7-flash', label: 'Gemini 3.7 Flash' },
  { id: 'gemini-3.5-flash', label: 'Gemini 3.5 Flash' },
  { id: 'gemini-4-argon', label: 'Gemini 4 Argon (Custom Paid Key)' },
  { id: 'gemini-4-carbon', label: 'Gemini 4 Carbon (Custom Paid Key)' },
  { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash (Custom Key)' },
  { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro (Custom Key)' }
];

const FALLBACK_MODEL_CHAIN = [
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-flash-lite-latest',
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-4-hydrogen'
];

export function resolveGeminiApiKey(customKey?: string): string {
  return (customKey || process.env.GEMINI_API_KEY || DEFAULT_GEMINI_API_KEY).trim();
}

function createGeminiClient(apiKey: string): GoogleGenAI {
  return new GoogleGenAI({
    apiKey,
    apiVersion: 'v1beta',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

function getModelConfigExtras(model: string): Record<string, any> {
  if (model.startsWith('gemini-4') || model.startsWith('gemini-3')) {
    return {
      thinkingConfig: {
        thinkingLevel: ThinkingLevel.LOW
      }
    };
  }
  return {};
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: NodeJS.Timeout;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer));
}

function isAuthOrInvalidKeyError(err: any): boolean {
  const raw = (err?.message || String(err)).toUpperCase();
  return (
    raw.includes('API_KEY_INVALID') ||
    raw.includes('API KEY NOT VALID') ||
    raw.includes('PERMISSION_DENIED') ||
    raw.includes('403') ||
    raw.includes('401')
  );
}

function isTransientOrModelUnavailableError(err: any): boolean {
  const raw = (err?.message || String(err)).toUpperCase();
  return (
    raw.includes('503') ||
    raw.includes('UNAVAILABLE') ||
    raw.includes('HIGH DEMAND') ||
    raw.includes('429') ||
    raw.includes('RESOURCE_EXHAUSTED') ||
    raw.includes('NOT_FOUND') ||
    raw.includes('404') ||
    raw.includes('TIMED OUT') ||
    raw.includes('500') ||
    raw.includes('502') ||
    raw.includes('504') ||
    raw.includes('ECONNRESET') ||
    raw.includes('FETCH FAILED')
  );
}

function buildModelAttemptOrder(requestedModel?: string, maxCandidates = 5): string[] {
  const primary = (requestedModel || 'gemini-3.1-flash-lite').trim();
  const ordered = [primary, ...FALLBACK_MODEL_CHAIN];
  return Array.from(new Set(ordered.filter(Boolean))).slice(0, maxCandidates);
}

export async function testGeminiConnection(params: {
  apiKey?: string;
  model?: string;
}): Promise<{
  ok: boolean;
  model: string;
  requestedModel: string;
  usedFallback?: boolean;
  reply?: string;
  latencyMs: number;
  warning?: string;
  error?: string;
}> {
  const apiKey = resolveGeminiApiKey(params.apiKey);
  const requestedModel = (params.model || 'gemini-3.1-flash-lite').trim();

  if (!apiKey) {
    return {
      ok: false,
      model: requestedModel,
      requestedModel,
      latencyMs: 0,
      error: 'No Gemini API Key configured.'
    };
  }

  const startTime = Date.now();
  const ai = createGeminiClient(apiKey);
  const candidates = buildModelAttemptOrder(requestedModel, 5);
  let primaryError: string | undefined;

  for (let i = 0; i < candidates.length; i++) {
    if (Date.now() - startTime > 24000) break;
    const candidate = candidates[i];
    try {
      const response = await withTimeout(
        ai.models.generateContent({
          model: candidate,
          contents: 'Reply with exact phrase: "Gemini Connected!"',
          config: {
            ...getModelConfigExtras(candidate)
          }
        }),
        10000,
        `Gemini test (${candidate})`
      );

      const latencyMs = Date.now() - startTime;
      const reply = (response.text || '').trim() || 'Gemini Connected!';
      const usedFallback = candidate !== requestedModel;

      return {
        ok: true,
        model: candidate,
        requestedModel,
        usedFallback,
        reply,
        latencyMs,
        warning: usedFallback
          ? `${requestedModel} is temporarily busy (503 high demand); auto-fallback verified on ${candidate}.`
          : undefined
      };
    } catch (err: any) {
      if (isAuthOrInvalidKeyError(err)) {
        return {
          ok: false,
          model: candidate,
          requestedModel,
          latencyMs: Date.now() - startTime,
          error: formatGeminiError(err, candidate)
        };
      }

      if (i === 0) {
        primaryError = formatGeminiError(err, candidate);
      }

      if (i === 0 && !isTransientOrModelUnavailableError(err)) {
        return {
          ok: false,
          model: candidate,
          requestedModel,
          latencyMs: Date.now() - startTime,
          error: formatGeminiError(err, candidate)
        };
      }
    }
  }

  return {
    ok: false,
    model: requestedModel,
    requestedModel,
    latencyMs: Date.now() - startTime,
    error: primaryError || 'All Gemini models are temporarily overloaded (503). Built-in smart analyzer remains ready for script splitting.'
  };
}

function formatGeminiError(err: any, model: string): string {
  const raw = err?.message || String(err);
  if (raw.includes('PERMISSION_DENIED') || raw.includes('403') || raw.includes('API_KEY_INVALID') || raw.includes('400')) {
    return `Gemini API key/request error (${model}): ${raw.substring(0, 180)}`;
  }
  if (raw.includes('NOT_FOUND') || raw.includes('404')) {
    return `Gemini model "${model}" was not found or is unavailable on this key.`;
  }
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('429')) {
    return `Gemini quota exceeded for "${model}" (429).`;
  }
  if (raw.includes('503') || raw.includes('UNAVAILABLE') || raw.toUpperCase().includes('HIGH DEMAND')) {
    return `Gemini "${model}" is temporarily busy (503 high demand).`;
  }
  return `Gemini error (${model}): ${raw.substring(0, 200)}`;
}

export interface AnalyzeScriptParams {
  script: string;
  style: VisualStyle;
  aspectRatio: AspectRatio;
  geminiApiKey?: string;
  geminiModel?: string;
  splitGranularity?: SplitGranularity;
}

export interface AnalysisResult {
  continuityProfile: ContinuityProfile;
  scenes: Scene[];
  modelUsed: string;
  fallbackNote?: string;
}

export async function analyzeScriptWithGemini(params: AnalyzeScriptParams): Promise<AnalysisResult> {
  const {
    script,
    style,
    aspectRatio,
    splitGranularity = 'very-small'
  } = params;

  const apiKey = resolveGeminiApiKey(params.geminiApiKey);
  const requestedModel = (params.geminiModel || 'gemini-3.1-flash-lite').trim();

  if (!apiKey) {
    throw new Error('Gemini API key is missing. Please add it in Settings.');
  }

  const styleGuidelines = getStyleGuidelines(style, aspectRatio);
  const granularityInstruction = getGranularityInstruction(splitGranularity);

  const systemInstruction = `You are a master film director, character designer, and continuity supervisor for AI text-to-image video production.
Your mission has TWO strict priorities:
1) Split the user's script into sequential scenes 100% VERBATIM (zero altered, added, or missing words).
2) Design ultra-consistent, script-accurate, self-contained image prompts so EVERY generated scene looks like part of ONE cohesive film starring the EXACT SAME character(s) in ONE continuous world.

CRITICAL SCRIPT SPLITTING RULES — DO NOT VIOLATE:
1. NEVER change, rewrite, paraphrase, correct, summarize, add, or remove ANY word of the user's script.
2. Every scene's "narration" MUST be an EXACT verbatim slice of the input script in exact sequential order.
3. Joining every scene's "narration" in order MUST reconstruct 100% of the user's original script word-for-word.
4. ${granularityInstruction}

CRITICAL CHARACTER & SCENE-TO-SCENE CONSISTENCY RULES:
5. First design a concrete MASTER CONTINUITY BIBLE (continuityProfile):
   - "mainCharacters": Define EVERY recurring character (or creature/protagonist) with immutable visual tokens: name/role, exact age/build/proportions, exact face/head/hair/skin/eye style, and EXACT fixed clothing/colors/accessories/signature props (e.g., for stickman: fixed crisp black ink stroke weight, round head, two dot eyes, signature red scarf or pencil prop; for cartoon/realistic: exact hair length/color, jacket/shirt/pants colors & textures, shoes, glasses/hat).
   - "environmentLock": Exact recurring setting architecture, textures, props, time of day, sky/weather, and spatial layout. Carry props across scenes seamlessly!
   - "artDirection": Exact unified rendering medium, camera/lens or illustration line-weight, shader/texture style that MUST remain identical in every single scene.
   - "colorPalette": 4 to 6 exact consistent color anchors used across the entire project.
   - "lightingStyle": Consistent key light direction, temperature, shadows, and atmosphere.
   - "consistencyRules": One crisp visual lock sentence combining the character appearance + outfit + medium + palette + lighting.

6. SELF-CONTAINED PROMPT RULE (CRITICAL FOR TEXT-TO-IMAGE MODELS):
   Text-to-image engines generate EACH scene independently with ZERO memory of earlier scenes!
   - NEVER use vague pronouns ("he", "she", "they", "it", "the protagonist") alone in "imagePrompt" or "characterDescriptions"! ALWAYS write out the full locked visual appearance & outfit of every visible character in EVERY single scene's "imagePrompt".
   - If the scene's split narration slice is short (e.g., "into existence." or "beside a glowing asteroid."), use the FULL script context before and after that slice so the scene visually depicts the exact literal action happening right at that beat while keeping the SAME character, props, and environment from the previous scene!
   - LITERAL SCRIPT ACCURACY: Depict every exact object, quantity, color, prop, creature, and setting mentioned in the script accurately—never invent contradictory props or randomly change outfits or backgrounds between connected beats.
   - UNIFIED COMPOSITION: Structure every "imagePrompt" cleanly as:
     [Camera shot & framing] + [Exact locked character appearance, outfit & expression performing the exact script action] + [Accurate scene-specific objects & consistent environment continuing from previous scene] + [Locked art direction, color palette & lighting] + "single unified clean frame, no text, no captions, no speech bubbles, no watermark, no split-screen collage".

Visual Style Guidelines (${style.toUpperCase()}):
${styleGuidelines}`;

  const wordCount = script.trim().split(/\s+/).filter(Boolean).length;
  const perCallTimeoutMs = Math.min(45000, Math.max(18000, 14000 + wordCount * 14));
  const overallBudgetMs = Math.min(80000, Math.max(36000, perCallTimeoutMs * 2));

  const ai = createGeminiClient(apiKey);
  const candidates = buildModelAttemptOrder(requestedModel, 5);
  const overallStart = Date.now();

  let parsed: any = null;
  let modelUsed = requestedModel;
  let primaryError: string | null = null;

  for (let i = 0; i < candidates.length; i++) {
    if (Date.now() - overallStart > overallBudgetMs) break;
    const candidate = candidates[i];
    // Retry top 2 fast candidates once after a short jitter if they return a quick 503 spike
    const maxRetriesForCandidate = i <= 1 ? 1 : 0;

    for (let attempt = 0; attempt <= maxRetriesForCandidate; attempt++) {
      if (Date.now() - overallStart > overallBudgetMs) break;
      const attemptStart = Date.now();
      try {
        console.log(`[geminiService] Analyzing script (${wordCount} words) with model=${candidate} (attempt ${attempt + 1}), splitGranularity=${splitGranularity}...`);

        const response = await withTimeout(
          ai.models.generateContent({
            model: candidate,
            contents: `Create the Master Continuity Bible first, then split this script 100% verbatim and write script-accurate, character-consistent self-contained imagePrompts for every single scene:\n\n${script}`,
            config: {
              systemInstruction,
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  continuityProfile: {
                    type: Type.OBJECT,
                    properties: {
                      style: { type: Type.STRING },
                      mainCharacters: {
                        type: Type.STRING,
                        description: 'Immutable character visual sheet: exact hair, face, proportions, fixed outfit colors, and recurring props for every character.'
                      },
                      environmentLock: {
                        type: Type.STRING,
                        description: 'Consistent world/setting details, props, weather, and time of day shared across scenes.'
                      },
                      artDirection: { type: Type.STRING },
                      colorPalette: { type: Type.STRING },
                      lightingStyle: { type: Type.STRING },
                      consistencyRules: {
                        type: Type.STRING,
                        description: 'Concise visual anchor phrase summarizing character look + medium + color + lighting lock.'
                      }
                    },
                    required: ['style', 'mainCharacters', 'environmentLock', 'artDirection', 'colorPalette', 'lightingStyle', 'consistencyRules']
                  },
                  scenes: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        sequence: { type: Type.INTEGER },
                        title: { type: Type.STRING },
                        summary: { type: Type.STRING },
                        narration: { type: Type.STRING, description: 'Exact verbatim words from the original script, unchanged.' },
                        visualDescription: { type: Type.STRING },
                        imagePrompt: {
                          type: Type.STRING,
                          description: 'Self-contained, script-accurate image prompt repeating locked character appearance/outfit, consistent environment, exact script action, camera framing, art direction, palette, and lighting.'
                        },
                        negativePrompt: { type: Type.STRING },
                        characterDescriptions: { type: Type.STRING },
                        environment: { type: Type.STRING },
                        cameraAngle: { type: Type.STRING },
                        lighting: { type: Type.STRING },
                        continuityNotes: {
                          type: Type.STRING,
                          description: 'How this scene connects visually to the previous and next scene (recurring character outfit, carried props, lighting/setting continuity).'
                        }
                      },
                      required: ['sequence', 'title', 'narration', 'visualDescription', 'imagePrompt', 'characterDescriptions', 'environment', 'cameraAngle', 'lighting', 'continuityNotes']
                    }
                  }
                },
                required: ['continuityProfile', 'scenes']
              },
              ...getModelConfigExtras(candidate)
            }
          }),
          perCallTimeoutMs,
          `Gemini analyze (${candidate})`
        );

        const responseText = response.text;
        if (!responseText) {
          throw new Error(`Gemini (${candidate}) returned an empty response.`);
        }

        const json = JSON.parse(responseText);
        if (!Array.isArray(json.scenes) || json.scenes.length === 0) {
          throw new Error(`Gemini (${candidate}) did not return any scenes.`);
        }

        parsed = json;
        modelUsed = candidate;
        break;
      } catch (err: any) {
        const formattedErr = formatGeminiError(err, candidate);
        if (i === 0 && !primaryError) {
          primaryError = formattedErr;
        }
        console.warn(`[geminiService] Attempt failed for ${candidate}: ${formattedErr}`);

        // Do not mask invalid API key errors
        if (isAuthOrInvalidKeyError(err)) {
          throw new Error(formattedErr);
        }

        const elapsedMs = Date.now() - attemptStart;
        // Only retry if the failure was fast (like 503 high demand), not a 16s timeout
        if (attempt < maxRetriesForCandidate && elapsedMs < 8000 && isTransientOrModelUnavailableError(err)) {
          await new Promise(r => setTimeout(r, 500));
          continue;
        }
        break;
      }
    }

    if (parsed) break;
  }

  let fallbackNote: string | undefined;
  if (!parsed) {
    console.warn(`[geminiService] All Gemini models temporarily busy (${primaryError}). Running deterministic verbatim continuity fallback.`);
    parsed = smartLocalVerbatimFallbackAnalyze(script, style, aspectRatio, splitGranularity);
    modelUsed = 'smart-local-continuity';
    fallbackNote = `${primaryError || 'Gemini models temporarily busy (503)'} — automatically used smart local verbatim splitter with character continuity.`;
  } else if (modelUsed !== requestedModel) {
    fallbackNote = `${requestedModel} was temporarily busy (503 high demand) — automatically completed via ${modelUsed}.`;
  }

  // Enforce 100% verbatim preservation of original script
  const verbatimScenes = reconcileVerbatimScript(script, parsed.scenes);

  const formatted = formatScenesOutput(
    {
      continuityProfile: parsed.continuityProfile,
      scenes: verbatimScenes
    },
    style,
    aspectRatio
  );

  console.log(`[geminiService] Split script into ${formatted.scenes.length} continuity-locked verbatim scenes via ${modelUsed}.`);
  return {
    ...formatted,
    modelUsed,
    fallbackNote
  };
}

/**
 * Deterministic 100% verbatim script splitter & continuity bible builder used ONLY if
 * every Gemini model is simultaneously returning 503 high demand or unreachable.
 */
function smartLocalVerbatimFallbackAnalyze(
  script: string,
  style: VisualStyle,
  aspectRatio: AspectRatio,
  splitGranularity: SplitGranularity
): { continuityProfile: ContinuityProfile; scenes: any[] } {
  const words = script.trim().split(/\s+/).filter(Boolean);
  const chunks: string[] = [];

  if (splitGranularity === 'very-small') {
    let buf: string[] = [];
    for (let i = 0; i < words.length; i++) {
      const w = words[i];
      buf.push(w);
      const endsWithPunct = /[,.;:!?]$/.test(w);
      const hitMax = buf.length >= 8;
      const hitMinPunct = endsWithPunct && buf.length >= 3;
      if (hitMax || hitMinPunct) {
        chunks.push(buf.join(' '));
        buf = [];
      }
    }
    if (buf.length > 0) {
      if (chunks.length > 0 && buf.length <= 2) {
        chunks[chunks.length - 1] = `${chunks[chunks.length - 1]} ${buf.join(' ')}`;
      } else {
        chunks.push(buf.join(' '));
      }
    }
  } else if (splitGranularity === 'small') {
    const sentences = script.trim().split(/(?<=[.!?])\s+/).filter(Boolean);
    for (const s of sentences) chunks.push(s.trim());
  } else {
    const sentences = script.trim().split(/(?<=[.!?])\s+/).filter(Boolean);
    for (let i = 0; i < sentences.length; i += 2) {
      chunks.push(sentences.slice(i, i + 2).join(' ').trim());
    }
  }

  if (chunks.length === 0 && script.trim()) {
    chunks.push(script.trim());
  }

  const lowerScript = script.toLowerCase();

  // Extract potential named characters (e.g., "Chef Oliver", "Maya") that aren't sentence-start stopwords
  const stopNames = new Set(['The', 'Deep', 'With', 'When', 'Then', 'Once', 'Inside', 'Beside', 'Passing', 'Suddenly', 'Here', 'Every', 'While', 'After', 'Before', 'Under', 'Through', 'Into']);
  const nameMatches = Array.from(new Set(
    (script.match(/\b[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?\b/g) || [])
      .filter(n => !stopNames.has(n.split(' ')[0]))
  )).slice(0, 2);

  const namedSubject = nameMatches.length > 0 ? nameMatches.join(' & ') : '';

  const baseChar =
    style === 'stickman'
      ? `${namedSubject ? `${namedSubject} as a ` : ''}minimalist stickman character with crisp circular head, two dot eyes, uniform bold black ink stick limbs, and expressive posture`
      : style === 'cartoon'
      ? `${namedSubject ? `${namedSubject}: ` : ''}consistent expressive 2D cartoon protagonist with signature stylized hair, clean facial features, and fixed colorful outfit`
      : `${namedSubject ? `${namedSubject}: ` : ''}consistent photorealistic protagonist with identical facial features, hairstyle, age, and fixed wardrobe across every shot`;

  const settingHint = /space|asteroid|planet|nebula|star/i.test(lowerScript)
    ? 'Deep cosmic space setting with glowing stars and planetary horizon'
    : /kitchen|bake|pan|egg|chef/i.test(lowerScript)
    ? 'Warm rustic kitchen interior with stove, cookware, and wooden countertops'
    : /city|street|building|rooftop|neon/i.test(lowerScript)
    ? 'Detailed urban environment with consistent architectural skyline and street lighting'
    : /forest|tree|wood|dock|sea|ocean|rain/i.test(lowerScript)
    ? 'Atmospheric outdoor environment with consistent terrain, weather, and sky lighting'
    : 'Consistent recurring story environment preserving architecture, props, and ambient weather';

  const artDirection =
    style === 'stickman'
      ? 'Minimalist 2D black-ink stickman illustration on clean background'
      : style === 'cartoon'
      ? 'Vibrant 2D cel-shaded cartoon animation illustration with crisp outlines'
      : 'Photorealistic 35mm cinematic film still with shallow depth of field';

  const colorPalette =
    style === 'stickman'
      ? 'Crisp ink black, clean off-white, subtle accent glow highlights'
      : 'Cohesive warm-and-cool balanced theatrical color palette';

  const lightingStyle = 'Consistent natural directional key light and soft ambient fill';

  const continuityProfile: ContinuityProfile = {
    style,
    mainCharacters: baseChar,
    environmentLock: settingHint,
    artDirection,
    colorPalette,
    lightingStyle,
    consistencyRules: `${baseChar}; ${settingHint}; ${artDirection}`
  };

  const shots = ['Medium wide shot', 'Medium shot', 'Close-up detail shot', 'Over-the-shoulder shot', 'Wide establishing shot'];

  const scenes = chunks.map((textChunk, idx) => {
    const seq = idx + 1;
    const shot = shots[idx % shots.length];
    const prevContext = idx > 0 ? chunks[idx - 1] : '';
    const nextContext = idx < chunks.length - 1 ? chunks[idx + 1] : '';
    const actionContext = [prevContext, textChunk, nextContext].filter(Boolean).join(' ');
    return {
      sequence: seq,
      title: `Scene ${seq}`,
      summary: textChunk,
      narration: textChunk,
      visualDescription: `${shot} depicting: ${textChunk}`,
      imagePrompt: `${shot}. ${baseChar}, performing the moment "${textChunk}" (context: ${actionContext}) inside ${settingHint}. ${artDirection}, ${colorPalette}, ${lightingStyle}, single unified ${aspectRatio} frame, no text, no watermark, no split panels`,
      characterDescriptions: baseChar,
      environment: settingHint,
      cameraAngle: shot.toLowerCase(),
      lighting: lightingStyle,
      continuityNotes: `Maintains fixed character design, clothing, and ${settingHint} continuity with Scene ${Math.max(1, seq - 1)}.`
    };
  });

  return { continuityProfile, scenes };
}

export async function syncContinuityPromptsWithGemini(params: {
  script: string;
  continuityProfile: ContinuityProfile;
  scenes: Scene[];
  style: VisualStyle;
  aspectRatio: AspectRatio;
  geminiApiKey?: string;
  geminiModel?: string;
}): Promise<Scene[]> {
  const {
    script,
    continuityProfile,
    scenes,
    style,
    aspectRatio
  } = params;

  const apiKey = resolveGeminiApiKey(params.geminiApiKey);
  const requestedModel = (params.geminiModel || 'gemini-3.1-flash-lite').trim();

  if (!apiKey) {
    return enforcePromptConsistency(continuityProfile, scenes, style, aspectRatio);
  }

  const ai = createGeminiClient(apiKey);
  const styleGuidelines = getStyleGuidelines(style, aspectRatio);
  const candidates = buildModelAttemptOrder(requestedModel, 3);
  const repromptStart = Date.now();

  const sceneManifest = scenes.map(s => ({
    id: s.id,
    sequence: s.sequence,
    title: s.title,
    narration: s.narration,
    cameraAngle: s.cameraAngle || 'medium shot'
  }));

  const systemInstruction = `You are a visual continuity director refining image generation prompts for an existing storyboard.
DO NOT change scene IDs, order, or narration text.
Rewrite ONLY the visual prompt fields ("imagePrompt", "visualDescription", "characterDescriptions", "environment", "lighting", "continuityNotes", "negativePrompt") so ALL scenes share 100% strict visual consistency according to this Master Continuity Bible:
- Visual Style: ${style} (${aspectRatio})
- Main Characters (LOCKED APPEARANCE): ${continuityProfile.mainCharacters}
- World / Environment Lock: ${continuityProfile.environmentLock || 'Consistent recurring world'}
- Art Direction: ${continuityProfile.artDirection}
- Color Palette: ${continuityProfile.colorPalette}
- Lighting Style: ${continuityProfile.lightingStyle}
- Consistency Rules: ${continuityProfile.consistencyRules || ''}

Style Guidelines:
${styleGuidelines}

Rules for EVERY scene's imagePrompt:
1. Must be 100% self-contained: explicitly describe the locked character(s) and their fixed outfit/props from "Main Characters" in every scene where they appear (never rely on bare pronouns like he/she/they).
2. Must accurately and literally depict the exact action, props, and details described in that scene's narration slice within the full script narrative context.
3. Must keep setting, palette, lighting, and artistic medium seamlessly consistent from scene to scene.
4. End cleanly with single unified frame guidance (no text overlays, no split panels, no watermarks).`;

  for (const candidate of candidates) {
    if (Date.now() - repromptStart > 25000) break;
    try {
      const response = await withTimeout(
        ai.models.generateContent({
          model: candidate,
          contents: `Full Script:\n${script}\n\nScenes to unify:\n${JSON.stringify(sceneManifest, null, 2)}`,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                scenes: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      visualDescription: { type: Type.STRING },
                      imagePrompt: { type: Type.STRING },
                      negativePrompt: { type: Type.STRING },
                      characterDescriptions: { type: Type.STRING },
                      environment: { type: Type.STRING },
                      cameraAngle: { type: Type.STRING },
                      lighting: { type: Type.STRING },
                      continuityNotes: { type: Type.STRING }
                    },
                    required: ['id', 'imagePrompt', 'visualDescription']
                  }
                }
              },
              required: ['scenes']
            },
            ...getModelConfigExtras(candidate)
          }
        }),
        14000,
        `Gemini reprompt (${candidate})`
      );

      const parsed = JSON.parse(response.text || '{}');
      const byId = new Map<string, any>();
      for (const item of parsed.scenes || []) {
        if (item?.id) byId.set(item.id, item);
      }

      const merged = scenes.map(s => {
        const upd = byId.get(s.id);
        if (!upd) return s;
        return {
          ...s,
          visualDescription: upd.visualDescription || s.visualDescription,
          imagePrompt: upd.imagePrompt || s.imagePrompt,
          negativePrompt: upd.negativePrompt || s.negativePrompt,
          characterDescriptions: upd.characterDescriptions || s.characterDescriptions,
          environment: upd.environment || s.environment,
          cameraAngle: upd.cameraAngle || s.cameraAngle,
          lighting: upd.lighting || s.lighting,
          continuityNotes: upd.continuityNotes || s.continuityNotes
        };
      });

      return enforcePromptConsistency(continuityProfile, merged, style, aspectRatio);
    } catch (err: any) {
      if (isAuthOrInvalidKeyError(err)) {
        throw new Error(formatGeminiError(err, candidate));
      }
      console.warn(`[geminiService] syncContinuityPrompts attempt failed on ${candidate}: ${formatGeminiError(err, candidate)}`);
    }
  }

  return enforcePromptConsistency(continuityProfile, scenes, style, aspectRatio);
}

function getGranularityInstruction(splitGranularity: SplitGranularity): string {
  if (splitGranularity === 'very-small') {
    return 'Split the script into VERY SMALL parts: micro-scenes of 4 to 10 words each (every short phrase, comma clause, or single visual action becomes its own scene). Create as many small scenes as needed so every moment gets its own visual.';
  }
  if (splitGranularity === 'small') {
    return 'Split the script into SMALL parts: 1 single sentence (or short clause if a sentence is long) per scene.';
  }
  return 'Split the script into standard narrative beats (1 to 3 sentences per scene where the visual context changes).';
}

/**
 * Ensures zero words from the original script are dropped, added, or altered.
 */
function reconcileVerbatimScript(originalScript: string, aiScenes: any[]): any[] {
  const originalWords = originalScript.trim().split(/\s+/).filter(Boolean);
  if (originalWords.length === 0) return aiScenes;

  const combinedAiWords = aiScenes
    .map(s => (s.narration || '').trim())
    .join(' ')
    .split(/\s+/)
    .filter(Boolean);

  const isExactMatch =
    originalWords.length === combinedAiWords.length &&
    originalWords.every((w, idx) => w === combinedAiWords[idx]);

  if (isExactMatch) {
    return aiScenes;
  }

  console.log(
    `[geminiService] Reconciling script verbatim (${originalWords.length} original words vs ${combinedAiWords.length} returned words) to ensure zero script alteration.`
  );

  const weights = aiScenes.map(s => {
    const wc = ((s.narration || '').trim().split(/\s+/).filter(Boolean)).length;
    return Math.max(1, wc);
  });
  const totalWeight = weights.reduce((a, b) => a + b, 0);

  let cursor = 0;
  const result: any[] = [];

  for (let i = 0; i < aiScenes.length; i++) {
    if (cursor >= originalWords.length) break;

    let count: number;
    if (i === aiScenes.length - 1) {
      count = originalWords.length - cursor;
    } else {
      const remainingWords = originalWords.length - cursor;
      const remainingScenes = aiScenes.length - i;
      const ideal = Math.max(1, Math.round((weights[i] / totalWeight) * originalWords.length));
      count = Math.min(ideal, Math.max(1, remainingWords - (remainingScenes - 1)));
    }

    const sliceWords = originalWords.slice(cursor, cursor + count);
    cursor += count;

    result.push({
      ...aiScenes[i],
      narration: sliceWords.join(' ')
    });
  }

  if (cursor < originalWords.length && result.length > 0) {
    const leftover = originalWords.slice(cursor).join(' ');
    result[result.length - 1].narration = `${result[result.length - 1].narration} ${leftover}`.trim();
  }

  return result;
}

function getStyleGuidelines(style: VisualStyle, aspectRatio: AspectRatio): string {
  if (style === 'stickman') {
    return `- Aesthetic: Minimalist 2D stickman illustration with crisp uniform bold black ink outlines on a clean textured off-white/light paper background (or matching dark void when the script is in space).
- Character Lock: Identical stickman protagonist across every frame — clean circular head, two crisp dot eyes, simple expressive curved mouth, straight uniform-thickness black stick limbs, optional small recurring prop/accessory matching the script.
- Props & Environment: Cohesive hand-drawn clean ink linework with subtle consistent accent colors.
- Composition: Single unified ${aspectRatio} frame, zero text, zero comic panels, zero watermarks.`;
  } else if (style === 'cartoon') {
    return `- Aesthetic: High-craft 2D stylized cartoon animation frame, clean uniform ink outlines, expressive cel-shading, cohesive theatrical color script.
- Character Lock: Every character keeps the exact same hair shape/color, facial proportions, skin tone, outfit colors, and signature accessories in every single shot.
- Lighting & Depth: Rich painted backgrounds matching adjacent scenes in architecture, props, and atmospheric light.
- Composition: Single unified ${aspectRatio} frame, zero text, zero speech bubbles, zero watermarks.`;
  } else {
    return `- Aesthetic: Photorealistic cinematic 35mm film still, ultra-detailed natural textures, shallow depth of field, cohesive color grading across the entire sequence.
- Character Lock: Identical human face, age, ethnicity, hairstyle, facial hair/makeup, and exact wardrobe (shirt, jacket, trousers, accessories) across every scene.
- Lighting & Environment: Consistent practical & ambient light direction, matched time of day, weather, and architectural props from scene to scene.
- Composition: Single unified ${aspectRatio} film frame, zero text, zero collage panels, zero watermarks.`;
  }
}

/**
 * Deterministic post-processor ensuring EVERY scene prompt carries unified art direction,
 * color palette, lighting lock, character consistency anchor, and clean single-frame rules.
 */
export function enforcePromptConsistency(
  continuityProfile: ContinuityProfile,
  scenes: Scene[],
  style: VisualStyle,
  aspectRatio: AspectRatio
): Scene[] {
  const styleLabel =
    style === 'stickman'
      ? 'minimalist crisp black-ink stickman illustration'
      : style === 'cartoon'
      ? 'cohesive 2D cel-shaded cartoon animation illustration'
      : 'photorealistic 35mm cinematic film still';

  const artAnchor = (continuityProfile.artDirection || styleLabel).trim();
  const paletteAnchor = (continuityProfile.colorPalette || '').trim();
  const lightingAnchor = (continuityProfile.lightingStyle || '').trim();
  const charAnchor = (continuityProfile.mainCharacters || '').trim();

  return scenes.map((scene) => {
    let prompt = (scene.imagePrompt || scene.visualDescription || '')
      .replace(/\s*\.\s*(?:Character consistency lock:|Style:|Color palette:|Lighting:)[\s\S]*$/i, '')
      .replace(/\s+/g, ' ')
      .trim();
    const lower = prompt.toLowerCase();

    const additions: string[] = [];

    if (charAnchor) {
      const firstCharChunk = charAnchor.split(/[;\n]/)[0].trim();
      const charName = firstCharChunk.split(':')[0].trim().toLowerCase();
      const visualWords = firstCharChunk
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ')
        .split(/\s+/)
        .filter(w => w.length > 4)
        .slice(0, 5);
      const matchedCount = visualWords.filter(w => lower.includes(w)).length;
      const mentionsCharacter = charName && lower.includes(charName);
      if (firstCharChunk.length > 10 && (!mentionsCharacter ? matchedCount < 2 : matchedCount < 2)) {
        additions.push(`Character consistency lock: ${firstCharChunk}`);
      }
    }

    const hasCoreStyle =
      (style === 'stickman' && lower.includes('stick')) ||
      (style === 'cartoon' && (lower.includes('cartoon') || lower.includes('2d'))) ||
      (style === 'realistic' && (lower.includes('photorealistic') || lower.includes('cinematic') || lower.includes('35mm')));

    if (artAnchor && !hasCoreStyle) {
      additions.push(`Style: ${artAnchor}`);
    }

    if (paletteAnchor && !lower.includes('palette') && !lower.includes('color')) {
      additions.push(`Color palette: ${paletteAnchor}`);
    }
    if (lightingAnchor && !lower.includes('lighting') && !lower.includes('lit')) {
      additions.push(`Lighting: ${lightingAnchor}`);
    }

    if (!lower.includes('no watermark') && !lower.includes('no text')) {
      additions.push(`single unified ${aspectRatio} frame, no text, no speech bubbles, no watermark, no split panels`);
    }

    const finalPrompt = additions.length > 0 ? `${prompt}. ${additions.join('. ')}.` : prompt;

    return {
      ...scene,
      imagePrompt: finalPrompt.replace(/\.\./g, '.').trim(),
      negativePrompt:
        scene.negativePrompt ||
        'inconsistent character face, changing clothes, different hair color, split screen, comic panels, text overlay, speech bubble, watermark, blurry, deformed'
    };
  });
}

function formatScenesOutput(
  parsed: any,
  style: VisualStyle,
  aspectRatio: AspectRatio
): Omit<AnalysisResult, 'modelUsed' | 'fallbackNote'> {
  const rawProfile = parsed.continuityProfile || {};
  const continuityProfile: ContinuityProfile = {
    style,
    mainCharacters:
      rawProfile.mainCharacters ||
      'Consistent primary protagonist with fixed proportions, facial features, hair, and outfit across all scenes',
    environmentLock:
      rawProfile.environmentLock || 'Consistent recurring world architecture, props, weather, and time of day',
    artDirection:
      rawProfile.artDirection ||
      (style === 'stickman'
        ? 'Minimalist clean black-ink stickman line art with consistent stroke weight'
        : style === 'cartoon'
        ? 'Unified 2D cel-shaded cartoon illustration with bold clean outlines'
        : 'Photorealistic 35mm cinematic film still, natural depth of field'),
    colorPalette:
      rawProfile.colorPalette ||
      (style === 'stickman' ? 'Crisp ink black, warm off-white, subtle accent highlights' : 'Cohesive warm-and-cool cinematic palette'),
    lightingStyle: rawProfile.lightingStyle || 'Consistent natural key and ambient lighting across scenes',
    consistencyRules:
      rawProfile.consistencyRules ||
      `${style} visual continuity lock across characters, outfits, palette, lighting, and setting`
  };

  const baseScenes: Scene[] = parsed.scenes.map((s: any, idx: number) => {
    const sequence = idx + 1;
    const narration = (s.narration || '').trim();
    const wordCount = narration.split(/\s+/).filter(Boolean).length;
    const estimatedSec = Math.max(1.8, Number((wordCount / 2.4).toFixed(2)));

    return {
      id: `scene-${String(sequence).padStart(3, '0')}`,
      sequence,
      title: s.title || `Part ${sequence}`,
      summary: s.summary || narration.substring(0, 70),
      narration,
      visualDescription: s.visualDescription || '',
      imagePrompt: s.imagePrompt || s.visualDescription || `Scene ${sequence} in ${style} style`,
      negativePrompt:
        s.negativePrompt ||
        'inconsistent character, changing clothes, split screen, comic panels, text overlay, watermark, blurry, low quality',
      characterDescriptions: s.characterDescriptions || continuityProfile.mainCharacters,
      environment: s.environment || continuityProfile.environmentLock || '',
      cameraAngle: s.cameraAngle || 'medium shot',
      lighting: s.lighting || continuityProfile.lightingStyle,
      continuityNotes: s.continuityNotes || `Maintains exact character look & setting continuity with Scene ${Math.max(1, sequence - 1)}`,
      suggestedTransition: 'cut',
      animationStyle: sequence % 2 === 1 ? 'zoom-in' : 'zoom-out',
      audioDurationSec: 0,
      customDurationSec: estimatedSec,
      effectiveDurationSec: estimatedSec,
      startFrame: 0,
      durationInFrames: Math.round(estimatedSec * 30),
      imageStatus: 'pending',
      voiceStatus: 'pending'
    };
  });

  const scenes = enforcePromptConsistency(continuityProfile, baseScenes, style, aspectRatio);
  return { continuityProfile, scenes };
}
