import { Scene } from '../types.js';

export interface TimelineCalculationResult {
  scenes: Scene[];
  totalDurationSec: number;
  totalDurationFrames: number;
  fps: number;
}

/**
 * Calculates cumulative scene boundaries and frame allocations
 * without rounding drift.
 */
export function calculateTimeline(scenes: Scene[], fps = 30): TimelineCalculationResult {
  if (!scenes || scenes.length === 0) {
    return {
      scenes: [],
      totalDurationSec: 0,
      totalDurationFrames: 0,
      fps
    };
  }

  let cumulativeTimeSec = 0;
  let cumulativeFrames = 0;

  const updatedScenes: Scene[] = scenes.map((scene) => {
    // If scene has real audio duration > 0, use it. Otherwise use customDurationSec or default 4.0s
    const effectiveSec = scene.audioDurationSec > 0
      ? scene.audioDurationSec
      : (scene.customDurationSec && scene.customDurationSec > 0 ? scene.customDurationSec : 4.0);

    const startSec = cumulativeTimeSec;
    const endSec = startSec + effectiveSec;

    // Use cumulative frame rounding to guarantee 0 cumulative drift:
    // startFrame = previous cumulativeFrames
    // targetEndFrame = Math.round(endSec * fps)
    // durationInFrames = targetEndFrame - startFrame (minimum 15 frames = 0.5s)
    const startFrame = cumulativeFrames;
    const targetEndFrame = Math.round(endSec * fps);
    const durationInFrames = Math.max(15, targetEndFrame - startFrame);

    cumulativeTimeSec = endSec;
    cumulativeFrames = startFrame + durationInFrames;

    return {
      ...scene,
      effectiveDurationSec: Number(effectiveSec.toFixed(3)),
      startFrame,
      durationInFrames
    };
  });

  return {
    scenes: updatedScenes,
    totalDurationSec: Number(cumulativeTimeSec.toFixed(3)),
    totalDurationFrames: cumulativeFrames,
    fps
  };
}
