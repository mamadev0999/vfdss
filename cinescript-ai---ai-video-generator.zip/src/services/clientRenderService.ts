import { Muxer, StreamTarget } from 'mp4-muxer';
import { AnimationStyle, ExportResolution, MotionSpeed, MusicTrack, Project, Scene, SubtitleStyle } from '../types';
import { getSubtitleStylePreset, resolveMotionConfig, SubtitleStylePreset } from '../utils/studioStyles';

export interface ClientRenderProgress {
  progress: number; // 0..100
  stage: string;
  currentFrame: number;
  totalFrames: number;
  renderFps: number;
  elapsedSec: number;
  hardwareMode: string;
}

export interface ClientRenderResult {
  blob: Blob | null;
  objectUrl: string | null;
  sizeBytes: number;
  width: number;
  height: number;
  fps: number;
  durationSec: number;
  elapsedSec: number;
  codec: string;
  hardwareMode: string;
  savedDirectlyToDisk?: boolean;
  fileName?: string;
}

export interface ExportTimelineScene {
  scene: Scene;
  index: number;
  effectiveSec: number;
  startFrame: number;
  sceneFrames: number;
  frameStartSec: number;
  frameDurationSec: number;
}

export interface ExportTimelinePlan {
  scenes: ExportTimelineScene[];
  totalFrames: number;
  totalDurationSec: number;
  fps: number;
}

export function getSceneEffectiveDurationSec(scene: Scene): number {
  if (scene.audioDurationSec > 0) return scene.audioDurationSec;
  if (scene.effectiveDurationSec > 0) return scene.effectiveDurationSec;
  if (scene.customDurationSec && scene.customDurationSec > 0) return scene.customDurationSec;
  return 4.0;
}

/**
 * Recomputes exact cumulative frame boundaries specifically for the chosen export FPS
 * (24, 30, or 60) so exporting at 60fps or 24fps always matches preview duration 1:1.
 */
export function computeExportTimeline(scenes: Scene[], rawFps: number): ExportTimelinePlan {
  const fps = Math.max(12, Math.min(60, Math.round(rawFps || 30)));
  if (!scenes || scenes.length === 0) {
    return { scenes: [], totalFrames: 0, totalDurationSec: 0, fps };
  }

  let cumulativeTimeSec = 0;
  let cumulativeFrames = 0;
  const minFramesPerScene = Math.max(12, Math.round(0.5 * fps));

  const planned: ExportTimelineScene[] = scenes.map((scene, index) => {
    const effectiveSec = getSceneEffectiveDurationSec(scene);
    cumulativeTimeSec += effectiveSec;
    const startFrame = cumulativeFrames;
    const targetEndFrame = Math.round(cumulativeTimeSec * fps);
    const sceneFrames = Math.max(minFramesPerScene, targetEndFrame - startFrame);
    cumulativeFrames += sceneFrames;

    return {
      scene,
      index,
      effectiveSec,
      startFrame,
      sceneFrames,
      frameStartSec: startFrame / fps,
      frameDurationSec: sceneFrames / fps
    };
  });

  return {
    scenes: planned,
    totalFrames: cumulativeFrames,
    totalDurationSec: cumulativeFrames / fps,
    fps
  };
}

export function estimateExportSizeMb(
  totalDurationSec: number,
  resolution: ExportResolution,
  aspectRatio: '16:9' | '9:16',
  lowRamMode: boolean
): number {
  const { videoBitrate, audioBitrate } = getResolutionDimensions(resolution, aspectRatio, lowRamMode);
  const totalBitsPerSec = videoBitrate + audioBitrate;
  return Math.max(0.5, Number(((totalBitsPerSec * Math.max(1, totalDurationSec)) / 8 / (1024 * 1024)).toFixed(1)));
}

export function isClientCpuExportSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof VideoEncoder !== 'undefined' &&
    typeof AudioEncoder !== 'undefined' &&
    typeof VideoFrame !== 'undefined' &&
    typeof AudioData !== 'undefined' &&
    typeof OfflineAudioContext !== 'undefined'
  );
}

export function isDirectDiskStreamingSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return typeof (window as any).showSaveFilePicker === 'function';
}

export function isLowRamDevice(): boolean {
  if (typeof navigator === 'undefined') return false;
  const mem = (navigator as any).deviceMemory as number | undefined;
  const cores = navigator.hardwareConcurrency;
  if (typeof mem === 'number' && mem <= 4) return true;
  if (typeof cores === 'number' && cores <= 4) return true;
  return false;
}

export function getResolutionDimensions(
  resolution: ExportResolution,
  aspectRatio: '16:9' | '9:16',
  lowRamMode = false
): { width: number; height: number; videoBitrate: number; audioBitrate: number } {
  const isPortrait = aspectRatio === '9:16';
  if (resolution === '2k') {
    return {
      width: isPortrait ? 1440 : 2560,
      height: isPortrait ? 2560 : 1440,
      videoBitrate: lowRamMode ? 8_500_000 : 15_000_000,
      audioBitrate: lowRamMode ? 160_000 : 256_000
    };
  }
  if (resolution === '720p') {
    return {
      width: isPortrait ? 720 : 1280,
      height: isPortrait ? 1280 : 720,
      videoBitrate: lowRamMode ? 2_200_000 : 4_800_000,
      audioBitrate: lowRamMode ? 128_000 : 160_000
    };
  }
  return {
    width: isPortrait ? 1080 : 1920,
    height: isPortrait ? 1920 : 1080,
    videoBitrate: lowRamMode ? 4_200_000 : 9_500_000,
    audioBitrate: lowRamMode ? 128_000 : 192_000
  };
}

/**
 * Fixed-page chunk store for StreamTarget so 4GB-RAM PCs never suffer
 * giant contiguous ArrayBuffer reallocations or duplicate moov copies.
 */
class PagedMp4Buffer {
  private readonly pageSize = 2 * 1024 * 1024; // 2 MB fixed blocks
  private pages: Uint8Array[] = [];
  private maxByteWritten = 0;

  write(data: Uint8Array, position: number): void {
    let remaining = data.byteLength;
    let srcOffset = 0;
    let cursor = position;

    while (remaining > 0) {
      const pageIdx = Math.floor(cursor / this.pageSize);
      const pageOffset = cursor % this.pageSize;

      while (this.pages.length <= pageIdx) {
        this.pages.push(new Uint8Array(this.pageSize));
      }

      const page = this.pages[pageIdx];
      const copyLen = Math.min(remaining, this.pageSize - pageOffset);
      page.set(data.subarray(srcOffset, srcOffset + copyLen), pageOffset);

      remaining -= copyLen;
      srcOffset += copyLen;
      cursor += copyLen;
    }

    if (position + data.byteLength > this.maxByteWritten) {
      this.maxByteWritten = position + data.byteLength;
    }
  }

  get byteLength(): number {
    return this.maxByteWritten;
  }

  toBlob(): Blob {
    if (this.maxByteWritten === 0) {
      return new Blob([], { type: 'video/mp4' });
    }
    const lastPageIdx = Math.floor((this.maxByteWritten - 1) / this.pageSize);
    const lastPageUsed = this.maxByteWritten - lastPageIdx * this.pageSize;
    const parts: BlobPart[] = [];

    for (let i = 0; i <= lastPageIdx; i++) {
      const page = this.pages[i];
      if (!page) continue;
      if (i === lastPageIdx && lastPageUsed < this.pageSize) {
        parts.push(page.slice(0, lastPageUsed));
      } else {
        parts.push(page as unknown as BlobPart);
      }
    }

    this.pages = [];
    return new Blob(parts, { type: 'video/mp4' });
  }
}

function easeInOutSine(t: number): number {
  const x = Math.max(0, Math.min(1, t));
  return 0.5 - 0.5 * Math.cos(Math.PI * x);
}

async function selectBestVideoEncoderConfig(
  width: number,
  height: number,
  fps: number,
  bitrate: number
): Promise<{ config: VideoEncoderConfig; hardwareMode: string }> {
  const codecs =
    width >= 2560 || height >= 2560
      ? ['avc1.4d0033', 'avc1.640033', 'avc1.420033', 'avc1.640032', 'avc1.4d0032']
      : ['avc1.4d002a', 'avc1.64002a', 'avc1.42E028', 'avc1.640028', 'avc1.42E01F'];

  const accelOrder: Array<{ mode: HardwareAcceleration; label: string }> = [
    { mode: 'no-preference', label: 'PC Fast Encoder (Auto HW/CPU)' },
    { mode: 'prefer-software', label: 'PC CPU Software Encoder' }
  ];

  for (const accel of accelOrder) {
    for (const codec of codecs) {
      const cfg: VideoEncoderConfig = {
        codec,
        width,
        height,
        bitrate,
        framerate: fps,
        hardwareAcceleration: accel.mode,
        latencyMode: 'quality',
        avc: { format: 'avc' }
      };
      try {
        const support = await VideoEncoder.isConfigSupported(cfg);
        if (support.supported) {
          return { config: support.config || cfg, hardwareMode: accel.label };
        }
      } catch {}
    }
  }

  throw new Error('Browser H.264 encoder is unavailable for this resolution. Use Server FFmpeg Export for guaranteed MP4 output.');
}

async function selectBestAudioEncoderConfig(sampleRate: number, bitrate: number): Promise<AudioEncoderConfig> {
  const candidates: AudioEncoderConfig[] = [
    { codec: 'mp4a.40.2', numberOfChannels: 2, sampleRate, bitrate },
    { codec: 'mp4a.40.2', numberOfChannels: 2, sampleRate: 44100, bitrate: 128_000 },
    { codec: 'mp4a.40.2', numberOfChannels: 2, sampleRate: 48000, bitrate: 192_000 }
  ];

  for (const cfg of candidates) {
    try {
      const support = await AudioEncoder.isConfigSupported(cfg);
      if (support.supported) {
        return support.config || cfg;
      }
    } catch {}
  }

  throw new Error('Browser AAC AudioEncoder is unavailable. Switch to Server FFmpeg Export.');
}

async function loadFittedSceneBitmap(
  url: string,
  targetW: number,
  targetH: number,
  lowRamMode: boolean
): Promise<ImageBitmap | HTMLImageElement | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const blob = await res.blob();

    const maxEdge = Math.round(Math.max(targetW, targetH) * (lowRamMode ? 1.1 : 1.15));
    try {
      return await createImageBitmap(blob, {
        resizeWidth: maxEdge,
        resizeQuality: lowRamMode ? 'medium' : 'high'
      });
    } catch {
      try {
        return await createImageBitmap(blob);
      } catch {
        // Clean HTMLImageElement fallback (handles SVG fallback artwork on older browsers)
        const objUrl = URL.createObjectURL(blob);
        try {
          const img = await new Promise<HTMLImageElement>((resolve, reject) => {
            const el = new Image();
            el.onload = () => resolve(el);
            el.onerror = reject;
            el.src = objUrl;
          });
          return img;
        } finally {
          URL.revokeObjectURL(objUrl);
        }
      }
    }
  } catch {
    return null;
  }
}

async function fetchDecodedAudio(url: string, decodeCtx: AudioContext): Promise<AudioBuffer | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const arr = await res.arrayBuffer();
    return await decodeCtx.decodeAudioData(arr);
  } catch {
    return null;
  }
}

function wrapTextLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];
  const lines: string[] = [];
  let current = words[0];

  for (let i = 1; i < words.length; i++) {
    const candidate = `${current} ${words[i]}`;
    if (ctx.measureText(candidate).width <= maxWidth) {
      current = candidate;
    } else {
      lines.push(current);
      current = words[i];
    }
  }
  lines.push(current);
  return lines;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

interface CaptionLayout {
  lines: string[];
  font: string;
  fontPx: number;
  lineHeight: number;
  boxX: number;
  boxY: number;
  boxW: number;
  boxH: number;
  padY: number;
  radius: number;
  preset: SubtitleStylePreset;
}

function prepareSceneVisualCache(
  baseCanvas: HTMLCanvasElement,
  baseCtx: CanvasRenderingContext2D,
  bitmap: ImageBitmap | HTMLImageElement | null,
  scene: Scene,
  width: number,
  height: number,
  style: Project['settings']['style'],
  isPortrait: boolean,
  showCaptions: boolean,
  subtitleStyle: SubtitleStyle,
  lowRamMode: boolean
): CaptionLayout | null {
  baseCtx.fillStyle = '#030712';
  baseCtx.fillRect(0, 0, width, height);

  if (bitmap) {
    const srcW = bitmap instanceof HTMLImageElement ? (bitmap.naturalWidth || width) : bitmap.width;
    const srcH = bitmap instanceof HTMLImageElement ? (bitmap.naturalHeight || height) : bitmap.height;
    const imgRatio = srcW / Math.max(1, srcH);
    const canvasRatio = width / height;
    let drawW = width;
    let drawH = height;
    let drawX = 0;
    let drawY = 0;

    if (imgRatio > canvasRatio) {
      drawW = width;
      drawH = width / imgRatio;
      drawY = (height - drawH) / 2;
    } else {
      drawH = height;
      drawW = height * imgRatio;
      drawX = (width - drawW) / 2;
    }

    baseCtx.imageSmoothingEnabled = true;
    baseCtx.imageSmoothingQuality = lowRamMode ? 'medium' : 'high';
    baseCtx.drawImage(bitmap, drawX, drawY, drawW, drawH);
  } else {
    baseCtx.fillStyle = style === 'stickman' ? '#f1f5f9' : '#0f172a';
    baseCtx.fillRect(0, 0, width, height);
    baseCtx.fillStyle = style === 'stickman' ? '#0f172a' : '#f8fafc';
    baseCtx.font = `700 ${Math.round(height * 0.036)}px "Plus Jakarta Sans", system-ui, sans-serif`;
    baseCtx.textAlign = 'center';
    baseCtx.fillText(scene.title, width / 2, height * 0.46);
  }

  const scaleFactor = width / (isPortrait ? 1080 : 1920);

  let caption: CaptionLayout | null = null;
  if (showCaptions && scene.narration?.trim()) {
    const preset = getSubtitleStylePreset(subtitleStyle);
    const rawText = preset.uppercase ? scene.narration.toUpperCase() : scene.narration;
    const basePx = subtitleStyle === 'youtube-bold' ? (isPortrait ? 25 : 29) : isPortrait ? 22 : 26;
    const fontPx = Math.round(basePx * scaleFactor);
    const lineHeight = Math.round(fontPx * 1.38);
    const maxBoxW = width * (isPortrait ? 0.88 : 0.78);
    const padX = Math.round(24 * scaleFactor);
    const padY = Math.round(12 * scaleFactor);
    const font = `${preset.fontWeight} ${fontPx}px ${preset.fontFamily}`;

    baseCtx.font = font;
    const lines = wrapTextLines(baseCtx, rawText, maxBoxW - padX * 2);

    if (lines.length > 0) {
      const longestLineW = Math.max(...lines.map(l => baseCtx.measureText(l).width));
      const boxW = Math.min(maxBoxW, longestLineW + padX * 2);
      const boxH = lines.length * lineHeight + padY * 2;
      const boxX = (width - boxW) / 2;
      const bottomMargin = Math.round((isPortrait ? 90 : 45) * scaleFactor);
      const boxY = height - bottomMargin - boxH;

      caption = {
        lines,
        font,
        fontPx,
        lineHeight,
        boxX,
        boxY,
        boxW,
        boxH,
        padY,
        radius: Math.round(10 * scaleFactor),
        preset
      };
    }
  }

  return caption;
}

function drawFrameFromSceneCache(
  ctx: CanvasRenderingContext2D,
  baseCanvas: HTMLCanvasElement,
  caption: CaptionLayout | null,
  options: {
    width: number;
    height: number;
    isPortrait: boolean;
    motion: Exclude<AnimationStyle, 'auto'>;
    zoomDelta: number;
    panDelta: number;
    progress: number;
    lowRamMode: boolean;
  }
) {
  const { width, height, isPortrait, motion, zoomDelta, panDelta, progress, lowRamMode } = options;

  if (motion === 'static') {
    ctx.drawImage(baseCanvas, 0, 0);
  } else {
    const eased = easeInOutSine(progress);
    let scale = 1.0;
    let offsetX = 0;

    if (motion === 'zoom-in' || motion === 'slow-zoom-in') {
      scale = 1.0 + zoomDelta * eased;
    } else if (motion === 'zoom-out' || motion === 'slow-zoom-out') {
      scale = 1.0 + zoomDelta * (1 - eased);
    } else if (motion === 'pan-left') {
      scale = 1.0 + zoomDelta * 0.7;
      offsetX = (panDelta - 2 * panDelta * eased) * width;
    } else if (motion === 'pan-right') {
      scale = 1.0 + zoomDelta * 0.7;
      offsetX = (-panDelta + 2 * panDelta * eased) * width;
    }

    ctx.fillStyle = '#030712';
    ctx.fillRect(0, 0, width, height);
    ctx.save();
    ctx.translate(width / 2 + offsetX, height / 2);
    ctx.scale(scale, scale);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = lowRamMode ? 'medium' : 'high';
    ctx.drawImage(baseCanvas, -width / 2, -height / 2, width, height);
    ctx.restore();
  }

  const scaleFactor = width / (isPortrait ? 1080 : 1920);

  if (caption) {
    const { preset } = caption;
    if (preset.bgColor) {
      ctx.save();
      if (preset.id === 'neon-glow') {
        ctx.shadowColor = 'rgba(56, 189, 248, 0.45)';
        ctx.shadowBlur = Math.round(16 * scaleFactor);
      }
      ctx.fillStyle = preset.bgColor;
      drawRoundedRect(ctx, caption.boxX, caption.boxY, caption.boxW, caption.boxH, caption.radius);
      ctx.fill();
      ctx.restore();

      if (preset.borderColor) {
        ctx.save();
        ctx.strokeStyle = preset.borderColor;
        ctx.lineWidth = Math.max(1.5, 1.5 * scaleFactor);
        ctx.stroke();
        ctx.restore();
      }
    }

    ctx.font = caption.font;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.lineJoin = 'round';

    for (let idx = 0; idx < caption.lines.length; idx++) {
      const textX = width / 2;
      const textY = caption.boxY + caption.padY + idx * caption.lineHeight;
      const line = caption.lines[idx];

      if (preset.strokeColor && preset.strokeWidthFactor > 0) {
        ctx.save();
        ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
        ctx.shadowBlur = Math.round(8 * scaleFactor);
        ctx.shadowOffsetY = Math.round(2 * scaleFactor);
        ctx.strokeStyle = preset.strokeColor;
        ctx.lineWidth = Math.max(2, caption.fontPx * preset.strokeWidthFactor);
        ctx.strokeText(line, textX, textY);
        ctx.restore();
      }

      ctx.fillStyle = preset.textColor;
      ctx.fillText(line, textX, textY);
    }
  }
}

/**
 * Evaluates smooth continuous background music gain at exact timeline time `t` (fade-in, fade-out, voice ducking)
 * so 15s chunked audio windows stitch together without clicks or level jumps at window boundaries.
 */
function sampleMusicGainCurve(
  winStartSec: number,
  winDurationSec: number,
  totalDurationSec: number,
  musicTrack: MusicTrack,
  speechSpans: Array<{ start: number; end: number }>
): Float32Array {
  const stepSec = 0.025; // 25ms control points -> 600 points per 15s window
  const steps = Math.max(2, Math.ceil(winDurationSec / stepSec) + 1);
  const curve = new Float32Array(steps);

  const baseVol = Math.max(0, Math.min(1, musicTrack.volume ?? 0.22));
  const fadeIn = Math.max(0, Math.min(totalDurationSec / 2, musicTrack.fadeInSec ?? 1.5));
  const fadeOut = Math.max(0, Math.min(totalDurationSec / 2, musicTrack.fadeOutSec ?? 2.0));
  const duckEnabled = Boolean(musicTrack.ducking && speechSpans.length > 0);

  for (let i = 0; i < steps; i++) {
    const t = Math.min(totalDurationSec, winStartSec + (i / (steps - 1)) * winDurationSec);
    let gain = baseVol;

    if (fadeIn > 0 && t < fadeIn) {
      gain *= Math.max(0.0001, t / fadeIn);
    }
    if (fadeOut > 0 && t > totalDurationSec - fadeOut) {
      gain *= Math.max(0.0001, (totalDurationSec - t) / fadeOut);
    }

    if (duckEnabled) {
      let duckFactor = 1.0;
      const rampIn = 0.12;
      const rampOut = 0.22;
      for (const span of speechSpans) {
        if (t >= span.start - rampIn && t <= span.end + rampOut) {
          if (t < span.start) {
            const p = (t - (span.start - rampIn)) / rampIn;
            duckFactor = Math.min(duckFactor, 1 - 0.58 * p);
          } else if (t > span.end) {
            const p = (t - span.end) / rampOut;
            duckFactor = Math.min(duckFactor, 0.42 + 0.58 * p);
          } else {
            duckFactor = 0.42;
            break;
          }
        }
      }
      gain *= duckFactor;
    }

    curve[i] = Math.max(0.0001, gain);
  }

  return curve;
}

/**
 * Mixes & AAC-encodes audio in 15-second streaming windows so 15-30+ minute videos
 * consume < 30 MB of RAM on 4GB laptops while keeping sample-exact A/V alignment.
 */
async function mixAndEncodeAudioTrackWindowed(
  timeline: ExportTimelinePlan,
  musicTrack: MusicTrack | null | undefined,
  narrationVolume: number,
  audioConfig: AudioEncoderConfig,
  audioEncoder: AudioEncoder,
  lowRamMode: boolean,
  getEncoderError: () => Error | null,
  onAudioWindowProgress: (windowIdx: number, totalWindows: number) => void,
  signal?: AbortSignal
): Promise<void> {
  const targetSampleRate = audioConfig.sampleRate || 44100;
  const totalSamples = Math.max(targetSampleRate, Math.round(timeline.totalDurationSec * targetSampleRate));
  const WINDOW_SECONDS = 15;
  const windowSizeSamples = targetSampleRate * WINDOW_SECONDS;
  const totalWindows = Math.max(1, Math.ceil(totalSamples / windowSizeSamples));

  const decodeCtx = new AudioContext();
  // Small LRU cache (max 3 decoded clips) so clips straddling 15s window boundaries aren't re-fetched,
  // while 100-400 older scenes are released immediately.
  const audioBufferCache = new Map<string, AudioBuffer | null>();
  const cacheOrder: string[] = [];

  const getSceneAudio = async (scene: Scene): Promise<AudioBuffer | null> => {
    if (!scene.audioUrl) return null;
    if (audioBufferCache.has(scene.id)) {
      return audioBufferCache.get(scene.id) || null;
    }
    const decoded = await fetchDecodedAudio(scene.audioUrl, decodeCtx);
    audioBufferCache.set(scene.id, decoded);
    cacheOrder.push(scene.id);
    if (cacheOrder.length > 3) {
      const oldest = cacheOrder.shift();
      if (oldest) audioBufferCache.delete(oldest);
    }
    return decoded;
  };

  let musicBuffer: AudioBuffer | null = null;
  if (musicTrack?.audioUrl) {
    musicBuffer = await fetchDecodedAudio(musicTrack.audioUrl, decodeCtx);
  }

  const speechSpans = timeline.scenes
    .filter(item => Boolean(item.scene.audioUrl))
    .map(item => ({
      start: item.frameStartSec,
      end: item.frameStartSec + item.frameDurationSec
    }));

  const chunkFrames = lowRamMode ? 2048 : 1024;
  const maxQueue = lowRamMode ? 12 : 24;
  let encodedSamples = 0;

  try {
    for (let w = 0; w < totalWindows; w++) {
      const err = getEncoderError();
      if (err) throw err;
      if (signal?.aborted) throw new Error('Export cancelled by user');

      onAudioWindowProgress(w + 1, totalWindows);

      const winStartSample = w * windowSizeSamples;
      const winSamples = Math.min(windowSizeSamples, totalSamples - winStartSample);
      const winStartSec = winStartSample / targetSampleRate;
      const winDurationSec = winSamples / targetSampleRate;
      const winEndSec = winStartSec + winDurationSec;

      const offlineCtx = new OfflineAudioContext(2, winSamples, targetSampleRate);
      const narrationGainNode = offlineCtx.createGain();
      narrationGainNode.gain.value = Math.max(0, Math.min(1.5, narrationVolume));
      narrationGainNode.connect(offlineCtx.destination);

      // Schedule only narration clips overlapping [winStartSec, winEndSec]
      for (const item of timeline.scenes) {
        if (!item.scene.audioUrl) continue;
        const clipStart = item.frameStartSec;
        const clipEnd = clipStart + item.frameDurationSec + 0.35;
        if (clipEnd <= winStartSec || clipStart >= winEndSec) {
          continue;
        }
        const buf = await getSceneAudio(item.scene);
        if (!buf) continue;

        const actualClipEnd = clipStart + buf.duration;
        if (actualClipEnd <= winStartSec) continue;

        const src = offlineCtx.createBufferSource();
        src.buffer = buf;
        src.connect(narrationGainNode);

        if (clipStart >= winStartSec) {
          src.start(clipStart - winStartSec, 0);
        } else {
          const offsetInClip = winStartSec - clipStart;
          if (offsetInClip < buf.duration - 0.005) {
            src.start(0, offsetInClip);
          }
        }
      }

      // Schedule background music slice for [winStartSec, winEndSec]
      if (musicBuffer && musicTrack) {
        const baseOffset = Math.max(0, musicTrack.startOffsetSec || 0);
        const musicDur = Math.max(0.05, musicBuffer.duration);
        const rawPos = baseOffset + winStartSec;
        const shouldPlayMusic = musicTrack.loop || rawPos < musicDur;

        if (shouldPlayMusic) {
          const musicGain = offlineCtx.createGain();
          const curve = sampleMusicGainCurve(
            winStartSec,
            winDurationSec,
            timeline.totalDurationSec,
            musicTrack,
            speechSpans
          );
          try {
            musicGain.gain.setValueCurveAtTime(curve, 0, Math.max(0.01, winDurationSec));
          } catch {
            musicGain.gain.value = Math.max(0, Math.min(1, musicTrack.volume ?? 0.22));
          }
          musicGain.connect(offlineCtx.destination);

          const src = offlineCtx.createBufferSource();
          src.buffer = musicBuffer;
          src.loop = Boolean(musicTrack.loop);
          src.connect(musicGain);

          const offsetInMusic = musicTrack.loop ? rawPos % musicDur : rawPos;
          src.start(0, offsetInMusic);
          if (!musicTrack.loop) {
            const remainingMusic = Math.max(0.01, musicDur - offsetInMusic);
            src.stop(Math.min(winDurationSec, remainingMusic));
          } else {
            src.stop(winDurationSec);
          }
        }
      }

      const renderedWindow = await offlineCtx.startRendering();
      const left = renderedWindow.getChannelData(0);
      const right = renderedWindow.numberOfChannels > 1 ? renderedWindow.getChannelData(1) : left;

      for (let offset = 0; offset < renderedWindow.length; offset += chunkFrames) {
        const encErr = getEncoderError();
        if (encErr) throw encErr;
        if (signal?.aborted) throw new Error('Export cancelled by user');

        const count = Math.min(chunkFrames, renderedWindow.length - offset);
        const planar = new Float32Array(count * 2);
        planar.set(left.subarray(offset, offset + count), 0);
        planar.set(right.subarray(offset, offset + count), count);

        const timestampUs = Math.round((encodedSamples * 1_000_000) / targetSampleRate);
        const audioData = new AudioData({
          format: 'f32-planar',
          sampleRate: targetSampleRate,
          numberOfFrames: count,
          numberOfChannels: 2,
          timestamp: timestampUs,
          data: planar
        });
        audioEncoder.encode(audioData);
        audioData.close();

        encodedSamples += count;

        while (audioEncoder.encodeQueueSize > maxQueue) {
          const qErr = getEncoderError();
          if (qErr) throw qErr;
          if (signal?.aborted) throw new Error('Export cancelled by user');
          await new Promise(r => setTimeout(r, 2));
        }
      }
    }
  } finally {
    audioBufferCache.clear();
    musicBuffer = null;
    await decodeCtx.close().catch(() => {});
  }
}

export async function renderVideoOnClientCpu(
  project: Project,
  options: {
    resolution: ExportResolution;
    fps: number;
    showCaptions: boolean;
    subtitleStyle?: SubtitleStyle;
    autoMotion: boolean;
    motionSpeed?: MotionSpeed;
    narrationVolume: number;
    lowRamMode?: boolean;
    writableStream?: any;
    targetFileName?: string;
    onProgress: (p: ClientRenderProgress) => void;
    signal?: AbortSignal;
  }
): Promise<ClientRenderResult> {
  const startMs = performance.now();
  const {
    resolution,
    fps: rawFps,
    showCaptions,
    subtitleStyle = 'classic-pill',
    autoMotion,
    motionSpeed = 'slow',
    narrationVolume,
    lowRamMode = isLowRamDevice(),
    writableStream = null,
    targetFileName,
    onProgress,
    signal
  } = options;

  const { width, height, videoBitrate, audioBitrate } = getResolutionDimensions(
    resolution,
    project.settings.aspectRatio,
    lowRamMode
  );

  if (!isClientCpuExportSupported()) {
    throw new Error('Browser WebCodecs API is unavailable here. Use Server FFmpeg Export instead.');
  }

  const scenes = project.scenes;
  if (!scenes || scenes.length === 0) {
    throw new Error('No scenes available to export.');
  }

  // Recompute cumulative timeline at the chosen export FPS so duration is ALWAYS 1:1 with preview!
  const timeline = computeExportTimeline(scenes, rawFps);
  const { fps, totalFrames, totalDurationSec } = timeline;

  onProgress({
    progress: 3,
    stage: `Checking ${lowRamMode ? '4GB-RAM Light' : 'Studio'} encoder (${width}×${height} @ ${fps}fps, ${totalDurationSec.toFixed(1)}s)...`,
    currentFrame: 0,
    totalFrames,
    renderFps: 0,
    elapsedSec: 0,
    hardwareMode: 'Checking...'
  });

  const { config: videoConfig, hardwareMode: detectedHardware } = await selectBestVideoEncoderConfig(
    width,
    height,
    fps,
    videoBitrate
  );
  const hardwareMode = writableStream
    ? `${detectedHardware} · Direct-to-Disk`
    : lowRamMode
    ? `${detectedHardware} · Low-RAM`
    : detectedHardware;
  // Normalize AudioEncoder at 44100 Hz first to match server MP3 tracks without resampling
  const preferredSampleRate = 44100;
  const audioConfig = await selectBestAudioEncoderConfig(preferredSampleRate, audioBitrate);

  if (signal?.aborted) {
    if (writableStream) {
      try { await writableStream.abort(); } catch {}
    }
    throw new Error('Export cancelled by user');
  }

  let totalBytesWritten = 0;
  let diskWriteError: Error | null = null;
  let writeChain: Promise<void> = Promise.resolve();
  const pagedBuffer = writableStream ? null : new PagedMp4Buffer();

  const target = new StreamTarget({
    onData: (data, position) => {
      const endPos = position + data.byteLength;
      if (endPos > totalBytesWritten) {
        totalBytesWritten = endPos;
      }

      if (writableStream) {
        // Copy chunk before async disk write since mp4-muxer may reuse internal scratch slices
        const copy = data.slice();
        writeChain = writeChain
          .then(() => writableStream.write({ type: 'write', position, data: copy }))
          .catch((err: any) => {
            diskWriteError = err instanceof Error ? err : new Error(String(err));
          });
      } else if (pagedBuffer) {
        pagedBuffer.write(data, position);
      }
    }
  });

  const muxer = new Muxer({
    target,
    video: {
      codec: 'avc',
      width,
      height
    },
    audio: {
      codec: 'aac',
      numberOfChannels: 2,
      sampleRate: audioConfig.sampleRate || preferredSampleRate
    },
    fastStart: false,
    firstTimestampBehavior: 'offset'
  });

  let encoderFailure: Error | null = null;

  const videoEncoder = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: err => {
      encoderFailure = err instanceof Error ? err : new Error(String(err));
    }
  });
  videoEncoder.configure(videoConfig);

  const audioEncoder = new AudioEncoder({
    output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
    error: err => {
      encoderFailure = err instanceof Error ? err : new Error(String(err));
    }
  });
  audioEncoder.configure(audioConfig);

  // Reusable canvases (allocated once, freed at end)
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false });

  const baseSceneCanvas = document.createElement('canvas');
  baseSceneCanvas.width = width;
  baseSceneCanvas.height = height;
  const baseSceneCtx = baseSceneCanvas.getContext('2d', { alpha: false });

  if (!ctx || !baseSceneCtx) {
    throw new Error('Could not acquire 2D Canvas rendering context.');
  }

  let finishedCleanly = false;

  try {
    // 1. Mix & Encode Audio in 15-second streaming windows
    await mixAndEncodeAudioTrackWindowed(
      timeline,
      project.musicTrack,
      narrationVolume,
      audioConfig,
      audioEncoder,
      lowRamMode,
      () => encoderFailure || diskWriteError,
      (winIdx, totalWins) => {
        const audioPct = 6 + Math.round((winIdx / totalWins) * 16);
        onProgress({
          progress: audioPct,
          stage: project.musicTrack
            ? `Mixing audio chunk ${winIdx}/${totalWins} (voice ${Math.round(narrationVolume * 100)}% + music ${Math.round(project.musicTrack.volume * 100)}%)...`
            : `Mixing voice narration chunk ${winIdx}/${totalWins} (${Math.round(narrationVolume * 100)}%)...`,
          currentFrame: 0,
          totalFrames,
          renderFps: 0,
          elapsedSec: Number(((performance.now() - startMs) / 1000).toFixed(1)),
          hardwareMode
        });
      },
      signal
    );

    // 2. Stream Video Scenes ONE-AT-A-TIME (<= 1 ImageBitmap in memory at any instant)
    const isPortrait = project.settings.aspectRatio === '9:16';
    const keyFrameInterval = fps * (lowRamMode ? 3 : 2);
    const maxVideoQueue = lowRamMode ? 2 : 5;
    const encodeStartMs = performance.now();
    let globalFrame = 0;

    for (let sIdx = 0; sIdx < timeline.scenes.length; sIdx++) {
      if (encoderFailure) throw encoderFailure;
      if (diskWriteError) throw diskWriteError;
      if (signal?.aborted) throw new Error('Export cancelled by user');

      const { scene, sceneFrames } = timeline.scenes[sIdx];
      const { motion, zoomDelta, panDelta } = resolveMotionConfig(scene, autoMotion, motionSpeed);

      let rawBitmap: ImageBitmap | HTMLImageElement | null = null;
      if (scene.imageUrl) {
        rawBitmap = await loadFittedSceneBitmap(scene.imageUrl, width, height, lowRamMode);
      }

      const caption = prepareSceneVisualCache(
        baseSceneCanvas,
        baseSceneCtx,
        rawBitmap,
        scene,
        width,
        height,
        project.settings.style,
        isPortrait,
        showCaptions,
        subtitleStyle,
        lowRamMode
      );

      if (rawBitmap && typeof (rawBitmap as ImageBitmap).close === 'function') {
        (rawBitmap as ImageBitmap).close();
      }
      rawBitmap = null;

      if (motion === 'static') {
        drawFrameFromSceneCache(ctx, baseSceneCanvas, caption, {
          width,
          height,
          isPortrait,
          motion: 'static',
          zoomDelta: 0,
          panDelta: 0,
          progress: 0,
          lowRamMode
        });
      }

      for (let f = 0; f < sceneFrames; f++) {
        if (encoderFailure) throw encoderFailure;
        if (diskWriteError) throw diskWriteError;
        if (signal?.aborted) throw new Error('Export cancelled by user');

        if (motion !== 'static') {
          const progress = sceneFrames > 1 ? f / (sceneFrames - 1) : 0;
          drawFrameFromSceneCache(ctx, baseSceneCanvas, caption, {
            width,
            height,
            isPortrait,
            motion,
            zoomDelta,
            panDelta,
            progress,
            lowRamMode
          });
        }

        // Exact rational timestamps prevent cumulative rounding drift over 30-minute exports
        const timestampUs = Math.round((globalFrame * 1_000_000) / fps);
        const nextTimestampUs = Math.round(((globalFrame + 1) * 1_000_000) / fps);
        const durationUs = Math.max(1, nextTimestampUs - timestampUs);

        const videoFrame = new VideoFrame(canvas, {
          timestamp: timestampUs,
          duration: durationUs
        });

        const keyFrame = globalFrame === 0 || globalFrame % keyFrameInterval === 0;
        videoEncoder.encode(videoFrame, { keyFrame });
        videoFrame.close();

        globalFrame++;

        while (videoEncoder.encodeQueueSize > maxVideoQueue) {
          if (encoderFailure) throw encoderFailure;
          if (diskWriteError) throw diskWriteError;
          if (signal?.aborted) throw new Error('Export cancelled by user');
          await new Promise(r => setTimeout(r, 2));
        }

        const uiTickInterval = totalFrames > 10000 ? 18 : 6;
        if (globalFrame % uiTickInterval === 0 || globalFrame === totalFrames) {
          const encodeElapsed = Math.max(0.05, (performance.now() - encodeStartMs) / 1000);
          const renderFps = Number((globalFrame / encodeElapsed).toFixed(1));
          const pct = Math.min(95, 22 + Math.round((globalFrame / totalFrames) * 73));
          onProgress({
            progress: pct,
            stage: `Encoding ${resolution.toUpperCase()} @ ${fps}fps · Scene ${scene.sequence}/${timeline.scenes.length} · ${globalFrame}/${totalFrames}`,
            currentFrame: globalFrame,
            totalFrames,
            renderFps,
            elapsedSec: Number(((performance.now() - startMs) / 1000).toFixed(1)),
            hardwareMode
          });
          // Periodically flush pending disk writes & yield UI thread on huge 30-min renders
          if (writableStream && globalFrame % 120 === 0) {
            await writeChain;
          }
          await new Promise(r => setTimeout(r, lowRamMode ? 1 : 0));
        }
      }
    }

    onProgress({
      progress: 97,
      stage: writableStream ? 'Flushing MP4 stream to disk...' : 'Finalizing MP4 stream...',
      currentFrame: totalFrames,
      totalFrames,
      renderFps: Number((totalFrames / Math.max(0.1, (performance.now() - encodeStartMs) / 1000)).toFixed(1)),
      elapsedSec: Number(((performance.now() - startMs) / 1000).toFixed(1)),
      hardwareMode
    });

    await videoEncoder.flush();
    await audioEncoder.flush();
    muxer.finalize();

    if (writableStream) {
      await writeChain;
      await writableStream.close();
    }

    if (encoderFailure) throw encoderFailure;
    if (diskWriteError) throw diskWriteError;

    finishedCleanly = true;

    const blob = pagedBuffer ? pagedBuffer.toBlob() : null;
    const objectUrl = blob ? URL.createObjectURL(blob) : null;
    const sizeBytes = blob ? blob.size : totalBytesWritten;
    const totalElapsed = Number(((performance.now() - startMs) / 1000).toFixed(1));

    onProgress({
      progress: 100,
      stage: `${resolution.toUpperCase()} MP4 ready (${totalDurationSec.toFixed(1)}s)!`,
      currentFrame: totalFrames,
      totalFrames,
      renderFps: Number((totalFrames / Math.max(0.1, (performance.now() - encodeStartMs) / 1000)).toFixed(1)),
      elapsedSec: totalElapsed,
      hardwareMode
    });

    return {
      blob,
      objectUrl,
      sizeBytes,
      width,
      height,
      fps,
      durationSec: Number(totalDurationSec.toFixed(2)),
      elapsedSec: totalElapsed,
      codec: videoConfig.codec,
      hardwareMode,
      savedDirectlyToDisk: Boolean(writableStream),
      fileName: targetFileName
    };
  } finally {
    try { videoEncoder.close(); } catch {}
    try { audioEncoder.close(); } catch {}
    if (writableStream && !finishedCleanly) {
      try { await writeChain; } catch {}
      try { await writableStream.abort(); } catch {}
    }
    canvas.width = 0;
    canvas.height = 0;
    baseSceneCanvas.width = 0;
    baseSceneCanvas.height = 0;
  }
}
