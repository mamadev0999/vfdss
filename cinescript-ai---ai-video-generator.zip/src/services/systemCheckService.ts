import { ExportResolution } from '../types';
import { isClientCpuExportSupported } from './clientRenderService';

export type PcPerformanceTier = 'low-budget' | 'balanced' | 'workstation';

export interface ServerSystemInfo {
  cpuModel: string;
  cpuCores: number;
  totalRamGb: number;
  freeRamGb: number;
  platform: string;
  arch: string;
  encoder: string;
}

export interface PcHardwareProfile {
  cpuCores: number;
  ramGb: number | null;
  gpuRenderer: string;
  platform: string;
  webCodecsSupported: boolean;
  hasHardwareEncoder: boolean;
  has1080pEncoder: boolean;
  has2kEncoder: boolean;
  canvasOpsPerSec: number;
  tier: PcPerformanceTier;
  tierLabel: string;
  summary: string;
  recommendedEngine: 'client-cpu' | 'server-ffmpeg';
  recommendedResolution: ExportResolution;
  recommendedFps: 24 | 30 | 60;
  recommendedLowRamMode: boolean;
  checkedAt: number;
  serverInfo?: ServerSystemInfo | null;
}

function detectGpuRenderer(): string {
  try {
    const canvas = document.createElement('canvas');
    const gl = (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')) as WebGLRenderingContext | null;
    if (!gl) return 'Standard 2D Display';
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    let name = dbg
      ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '')
      : String(gl.getParameter(gl.RENDERER) || '');
    const lose = gl.getExtension('WEBGL_lose_context');
    lose?.loseContext();
    canvas.width = 0;
    canvas.height = 0;
    if (!name) return 'Integrated Graphics';
    const angleMatch = name.match(/ANGLE\s*\([^,]+,\s*([^,)]+)/i);
    if (angleMatch?.[1]) {
      name = angleMatch[1].trim();
    }
    return name.slice(0, 48);
  } catch {
    return 'Integrated Graphics';
  }
}

async function probeH264Support(
  width: number,
  height: number,
  bitrate: number,
  hardwareAcceleration: HardwareAcceleration
): Promise<boolean> {
  if (typeof VideoEncoder === 'undefined') return false;
  const codecs =
    width >= 2560 || height >= 2560
      ? ['avc1.4d0033', 'avc1.640033', 'avc1.420033']
      : ['avc1.4d002a', 'avc1.64002a', 'avc1.42E028'];

  for (const codec of codecs) {
    try {
      const res = await VideoEncoder.isConfigSupported({
        codec,
        width,
        height,
        bitrate,
        framerate: 30,
        hardwareAcceleration,
        avc: { format: 'avc' }
      });
      if (res.supported) return true;
    } catch {}
  }
  return false;
}

function measureCanvasBlitSpeed(): number {
  try {
    const src = document.createElement('canvas');
    src.width = 640;
    src.height = 360;
    const sCtx = src.getContext('2d', { alpha: false });
    const dst = document.createElement('canvas');
    dst.width = 1280;
    dst.height = 720;
    const dCtx = dst.getContext('2d', { alpha: false });
    if (!sCtx || !dCtx) return 60;

    sCtx.fillStyle = '#1e293b';
    sCtx.fillRect(0, 0, 640, 360);

    const t0 = performance.now();
    const iterations = 10;
    for (let i = 0; i < iterations; i++) {
      dCtx.save();
      dCtx.translate(640, 360);
      dCtx.scale(1.06, 1.06);
      dCtx.drawImage(src, -640, -360, 1280, 720);
      dCtx.restore();
    }
    const elapsedMs = Math.max(1, performance.now() - t0);
    src.width = 0;
    src.height = 0;
    dst.width = 0;
    dst.height = 0;
    return Math.round((iterations / elapsedMs) * 1000);
  } catch {
    return 60;
  }
}

export async function checkPcAndServerHardware(): Promise<PcHardwareProfile> {
  const cpuCores = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) || 2;
  const ramGb =
    typeof navigator !== 'undefined' && typeof (navigator as any).deviceMemory === 'number'
      ? Number((navigator as any).deviceMemory)
      : null;
  const platform =
    typeof navigator !== 'undefined'
      ? (navigator as any).userAgentData?.platform || navigator.platform || 'Desktop'
      : 'Desktop';

  const webCodecsSupported = isClientCpuExportSupported();
  const gpuRenderer = detectGpuRenderer();
  const canvasOpsPerSec = measureCanvasBlitSpeed();

  const [hasHardwareEncoder, has1080pNoPref, has1080pSw, has2kEncoder, serverInfo] = await Promise.all([
    webCodecsSupported ? probeH264Support(1920, 1080, 5_000_000, 'prefer-hardware') : Promise.resolve(false),
    webCodecsSupported ? probeH264Support(1920, 1080, 5_000_000, 'no-preference') : Promise.resolve(false),
    webCodecsSupported ? probeH264Support(1920, 1080, 5_000_000, 'prefer-software') : Promise.resolve(false),
    webCodecsSupported ? probeH264Support(2560, 1440, 9_000_000, 'no-preference') : Promise.resolve(false),
    fetch('/api/system/info')
      .then(r => (r.ok ? (r.json() as Promise<ServerSystemInfo>) : null))
      .catch(() => null)
  ]);

  const has1080pEncoder = hasHardwareEncoder || has1080pNoPref || has1080pSw;

  let tier: PcPerformanceTier = 'balanced';
  let tierLabel = 'Standard PC';
  let recommendedResolution: ExportResolution = '1080p';
  let recommendedFps: 24 | 30 | 60 = 30;
  let recommendedLowRamMode = true;
  let recommendedEngine: 'client-cpu' | 'server-ffmpeg' =
    webCodecsSupported && has1080pEncoder ? 'client-cpu' : 'server-ffmpeg';
  let summary = '';

  const isLowMemory = ramGb !== null && ramGb <= 4;
  const isLowCore = cpuCores <= 4;

  if (isLowMemory || (isLowCore && !hasHardwareEncoder)) {
    tier = 'low-budget';
    tierLabel = '4GB / Low-Budget PC';
    recommendedLowRamMode = true;
    recommendedFps = 24;
    // Allow 1080p HQ on 4-core/HW machines, or 720p Fast HD on 2-core low-memory PCs
    recommendedResolution = cpuCores >= 4 || hasHardwareEncoder ? '1080p' : '720p';
    summary = hasHardwareEncoder
      ? `Hardware H.264 encoder detected — ready for ${recommendedResolution.toUpperCase()} @ 24fps in Low-RAM streaming mode.`
      : `Low-RAM streaming tuned (${recommendedResolution.toUpperCase()} @ 24fps) to avoid memory spikes on your PC.`;
  } else if (cpuCores >= 8 && (ramGb === null || ramGb >= 8) && has2kEncoder) {
    tier = 'workstation';
    tierLabel = 'High-Spec Workstation';
    recommendedResolution = '2k';
    recommendedFps = 30;
    recommendedLowRamMode = false;
    summary = `Multi-core workstation (${cpuCores} threads) ready for 2K Ultra HD Studio export.`;
  } else {
    tier = 'balanced';
    tierLabel = 'Balanced PC / Laptop';
    recommendedResolution = '1080p';
    recommendedFps = 30;
    recommendedLowRamMode = true;
    summary = hasHardwareEncoder
      ? `Hardware-assisted H.264 ready for fast 1080p Full HD @ 30fps export.`
      : `Multi-threaded CPU encoder tuned for crisp 1080p Full HD @ 30fps export.`;
  }

  return {
    cpuCores,
    ramGb,
    gpuRenderer,
    platform,
    webCodecsSupported,
    hasHardwareEncoder,
    has1080pEncoder,
    has2kEncoder,
    canvasOpsPerSec,
    tier,
    tierLabel,
    summary,
    recommendedEngine,
    recommendedResolution,
    recommendedFps,
    recommendedLowRamMode,
    checkedAt: Date.now(),
    serverInfo
  };
}
