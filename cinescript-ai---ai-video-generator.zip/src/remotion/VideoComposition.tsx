import React from 'react';
import {
  AbsoluteFill,
  Sequence,
  Img,
  Audio,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  Easing
} from 'remotion';
import { Scene, AspectRatio, VisualStyle, MusicTrack, MotionSpeed, SubtitleStyle } from '../types';
import { getSubtitleStylePreset, resolveMotionConfig } from '../utils/studioStyles';

export interface VideoCompositionProps {
  scenes: Scene[];
  aspectRatio: AspectRatio;
  style: VisualStyle;
  musicTrack?: MusicTrack | null;
  showCaptions?: boolean;
  subtitleStyle?: SubtitleStyle;
  autoMotion?: boolean;
  motionSpeed?: MotionSpeed;
  narrationVolume?: number;
}

export const VideoComposition: React.FC<VideoCompositionProps> = ({
  scenes,
  aspectRatio,
  style,
  musicTrack,
  showCaptions = true,
  subtitleStyle = 'classic-pill',
  autoMotion = true,
  motionSpeed = 'slow',
  narrationVolume
}) => {
  const { fps, durationInFrames } = useVideoConfig();

  if (!scenes || scenes.length === 0) {
    return (
      <AbsoluteFill style={{ backgroundColor: '#0b0f19', justifyContent: 'center', alignItems: 'center' }}>
        <div style={{ color: '#94a3b8', fontSize: 24, fontFamily: 'Plus Jakarta Sans, system-ui, sans-serif' }}>
          No scenes loaded in storyboard
        </div>
      </AbsoluteFill>
    );
  }

  const narrVol = narrationVolume ?? musicTrack?.narrationVolume ?? 1.0;

  return (
    <AbsoluteFill style={{ backgroundColor: '#020617' }}>
      {scenes.map((scene) => (
        <Sequence
          key={scene.id}
          from={scene.startFrame}
          durationInFrames={scene.durationInFrames}
        >
          <SceneRenderer
            scene={scene}
            aspectRatio={aspectRatio}
            style={style}
            showCaptions={showCaptions}
            subtitleStyle={subtitleStyle}
            autoMotion={autoMotion}
            motionSpeed={motionSpeed}
            narrationVolume={narrVol}
          />
        </Sequence>
      ))}

      {/* Background Music Track with Fade-In, Fade-Out, Loop & Voice Ducking */}
      {musicTrack?.audioUrl && (
        <Audio
          src={musicTrack.audioUrl}
          loop={Boolean(musicTrack.loop)}
          startFrom={Math.max(0, Math.round((musicTrack.startOffsetSec || 0) * fps))}
          volume={(frame) => {
            const base = Math.max(0, Math.min(1, musicTrack.volume ?? 0.22));
            const fadeInFrames = Math.max(0, Math.round((musicTrack.fadeInSec ?? 1.5) * fps));
            const fadeOutFrames = Math.max(0, Math.round((musicTrack.fadeOutSec ?? 2.0) * fps));

            let gain = base;
            if (fadeInFrames > 0 && frame < fadeInFrames) {
              gain *= frame / fadeInFrames;
            }
            if (fadeOutFrames > 0 && frame > durationInFrames - fadeOutFrames) {
              const remaining = Math.max(0, durationInFrames - frame);
              gain *= remaining / fadeOutFrames;
            }

            if (musicTrack.ducking) {
              const activeSpeech = scenes.some(
                s =>
                  s.audioUrl &&
                  frame >= s.startFrame &&
                  frame <= s.startFrame + Math.round((s.audioDurationSec || s.effectiveDurationSec) * fps)
              );
              if (activeSpeech) {
                gain *= 0.45;
              }
            }

            return Math.max(0, Math.min(1, gain));
          }}
        />
      )}
    </AbsoluteFill>
  );
};

interface SceneRendererProps {
  scene: Scene;
  aspectRatio: AspectRatio;
  style: VisualStyle;
  showCaptions: boolean;
  subtitleStyle: SubtitleStyle;
  autoMotion: boolean;
  motionSpeed: MotionSpeed;
  narrationVolume: number;
}

const SceneRenderer: React.FC<SceneRendererProps> = ({
  scene,
  aspectRatio,
  style,
  showCaptions,
  subtitleStyle,
  autoMotion,
  motionSpeed,
  narrationVolume
}) => {
  const frame = useCurrentFrame();
  const isPortrait = aspectRatio === '9:16';
  const durationFrames = Math.max(15, scene.durationInFrames || 120);
  const { motion, zoomDelta, panDelta } = resolveMotionConfig(scene, autoMotion, motionSpeed);

  let scale = 1.0;
  let translateXPercent = 0;

  if (motion === 'zoom-in' || motion === 'slow-zoom-in') {
    scale = interpolate(frame, [0, durationFrames], [1.0, 1.0 + zoomDelta], {
      easing: Easing.inOut(Easing.sin),
      extrapolateRight: 'clamp'
    });
  } else if (motion === 'zoom-out' || motion === 'slow-zoom-out') {
    scale = interpolate(frame, [0, durationFrames], [1.0 + zoomDelta, 1.0], {
      easing: Easing.inOut(Easing.sin),
      extrapolateRight: 'clamp'
    });
  } else if (motion === 'pan-left') {
    scale = 1.0 + zoomDelta * 0.7;
    const pct = panDelta * 100;
    translateXPercent = interpolate(frame, [0, durationFrames], [pct, -pct], {
      easing: Easing.inOut(Easing.sin),
      extrapolateRight: 'clamp'
    });
  } else if (motion === 'pan-right') {
    scale = 1.0 + zoomDelta * 0.7;
    const pct = panDelta * 100;
    translateXPercent = interpolate(frame, [0, durationFrames], [-pct, pct], {
      easing: Easing.inOut(Easing.sin),
      extrapolateRight: 'clamp'
    });
  }

  const subPreset = getSubtitleStylePreset(subtitleStyle);
  const displayCaption = subPreset.uppercase ? scene.narration.toUpperCase() : scene.narration;

  return (
    <AbsoluteFill style={{ overflow: 'hidden', backgroundColor: '#030712' }}>
      {/* Scene Image with Slow-Motion / Auto Zoom-In / Zoom-Out / Pan Motion */}
      {scene.imageUrl ? (
        <div
          style={{
            width: '100%',
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transform: `translate3d(${translateXPercent}%, 0, 0) scale(${scale})`,
            transformOrigin: 'center center'
          }}
        >
          <Img
            src={scene.imageUrl}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain'
            }}
          />
        </div>
      ) : (
        <AbsoluteFill
          style={{
            backgroundColor: style === 'stickman' ? '#f1f5f9' : '#0f172a',
            justifyContent: 'center',
            alignItems: 'center',
            padding: 40
          }}
        >
          <div
            style={{
              color: style === 'stickman' ? '#0f172a' : '#f8fafc',
              fontSize: isPortrait ? 28 : 36,
              fontWeight: 700,
              fontFamily: 'Plus Jakarta Sans, system-ui, sans-serif',
              textAlign: 'center',
              marginBottom: 12
            }}
          >
            {scene.title}
          </div>
          <div
            style={{
              color: style === 'stickman' ? '#64748b' : '#94a3b8',
              fontSize: isPortrait ? 18 : 22,
              fontFamily: 'Plus Jakarta Sans, system-ui, sans-serif',
              textAlign: 'center',
              maxWidth: 700
            }}
          >
            {scene.visualDescription || scene.imagePrompt}
          </div>
        </AbsoluteFill>
      )}

      {/* Synchronized scene narration audio track */}
      {scene.audioUrl && (
        <Audio
          src={scene.audioUrl}
          volume={Math.max(0, Math.min(1.5, narrationVolume))}
        />
      )}

      {/* Styled subtitle caption overlay */}
      {showCaptions && scene.narration?.trim() && (
        <div
          style={{
            position: 'absolute',
            bottom: isPortrait ? 90 : 45,
            left: '50%',
            transform: 'translateX(-50%)',
            maxWidth: isPortrait ? '88%' : '78%',
            backgroundColor: subPreset.bgColor || 'transparent',
            backdropFilter: subPreset.bgColor ? 'blur(8px)' : undefined,
            borderRadius: subPreset.bgColor ? 10 : 0,
            padding: subPreset.bgColor ? '10px 22px' : '4px 12px',
            border: subPreset.borderColor ? `1.5px solid ${subPreset.borderColor}` : 'none',
            textAlign: 'center',
            boxShadow: subPreset.bgColor ? subPreset.glowShadow || undefined : undefined
          }}
        >
          <span
            style={{
              color: subPreset.textColor,
              fontSize: isPortrait ? (subtitleStyle === 'youtube-bold' ? 23 : 20) : subtitleStyle === 'youtube-bold' ? 26 : 22,
              lineHeight: 1.4,
              fontWeight: subPreset.fontWeight,
              fontFamily: subPreset.fontFamily,
              letterSpacing: subPreset.letterSpacing,
              WebkitTextStroke: subPreset.strokeColor
                ? `${Math.max(1.5, Math.round(subPreset.strokeWidthFactor * 24))}px ${subPreset.strokeColor}`
                : undefined,
              paintOrder: subPreset.strokeColor ? 'stroke fill' : undefined,
              textShadow: subPreset.glowShadow || '0 2px 4px rgba(0, 0, 0, 0.85)'
            }}
          >
            {displayCaption}
          </span>
        </div>
      )}
    </AbsoluteFill>
  );
};
