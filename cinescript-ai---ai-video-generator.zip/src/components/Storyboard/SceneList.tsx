import React, { useState, useRef, useEffect } from 'react';
import { AnimationStyle, Scene, ContinuityProfile } from '../../types';
import {
  Image as ImageIcon,
  Mic,
  Play,
  RotateCw,
  ChevronUp,
  ChevronDown,
  CheckCircle2,
  AlertCircle,
  Lock,
  Sparkles
} from 'lucide-react';

interface SceneListProps {
  scenes: Scene[];
  continuityProfile?: ContinuityProfile;
  onUpdateContinuity?: (updates: Partial<ContinuityProfile>) => void;
  onSyncContinuity?: () => Promise<void>;
  isSyncingContinuity?: boolean;
  onUpdateScene: (sceneId: string, updates: Partial<Scene>) => void;
  onReorderScenes: (fromIndex: number, toIndex: number) => void;
  onGenerateImage: (sceneId: string) => Promise<void>;
  onGenerateVoice: (sceneId: string) => Promise<void>;
  activeGeneratingSceneId: string | null;
  activeAction: string | null;
}

export const SceneList: React.FC<SceneListProps> = ({
  scenes,
  continuityProfile,
  onUpdateContinuity,
  onSyncContinuity,
  isSyncingContinuity,
  onUpdateScene,
  onReorderScenes,
  onGenerateImage,
  onGenerateVoice,
  activeGeneratingSceneId
}) => {
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [showBible, setShowBible] = useState<boolean>(true);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const handlePlayAudio = (scene: Scene) => {
    if (!scene.audioUrl) return;
    if (playingAudioId === scene.id) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      setPlayingAudioId(null);
      return;
    }

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }

    const audio = new Audio(scene.audioUrl);
    audioRef.current = audio;
    setPlayingAudioId(scene.id);
    audio.onended = () => {
      setPlayingAudioId(null);
      audioRef.current = null;
    };
    audio.onerror = () => {
      setPlayingAudioId(null);
      audioRef.current = null;
    };
    audio.play().catch(() => {
      setPlayingAudioId(null);
      audioRef.current = null;
    });
  };

  return (
    <div className="space-y-4">
      {/* Master Character & Visual Continuity Bible */}
      {continuityProfile && (
        <div className="p-4 rounded-xl bg-slate-900/80 border border-amber-500/30 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setShowBible(v => !v)}
              className="flex items-center gap-2 text-left cursor-pointer"
            >
              <div className="p-1.5 rounded-lg bg-amber-500/15 text-amber-400">
                <Lock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Master Character & Visual Continuity Bible
                </h3>
                <p className="text-[11px] text-slate-400">
                  Locked character design, setting, palette & lighting shared across every generated scene image.
                </p>
              </div>
            </button>

            {onSyncContinuity && (
              <button
                type="button"
                onClick={onSyncContinuity}
                disabled={isSyncingContinuity}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all disabled:opacity-50 cursor-pointer shrink-0 self-start sm:self-auto"
              >
                {isSyncingContinuity ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Syncing Continuity...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Sync Continuity to All Prompts</span>
                  </>
                )}
              </button>
            )}
          </div>

          {showBible && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
              <div>
                <label className="text-[10px] font-semibold text-slate-400 uppercase block mb-1">
                  Locked Character Appearance & Outfits
                </label>
                <textarea
                  value={continuityProfile.mainCharacters}
                  onChange={(e) => onUpdateContinuity?.({ mainCharacters: e.target.value })}
                  rows={2}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-800 focus:border-amber-500/70 text-xs text-slate-200 outline-none resize-y"
                />
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-400 uppercase block mb-1">
                  World & Environment Continuity Lock
                </label>
                <textarea
                  value={continuityProfile.environmentLock || ''}
                  onChange={(e) => onUpdateContinuity?.({ environmentLock: e.target.value })}
                  rows={2}
                  placeholder="Recurring location, architecture, weather, time of day, key props..."
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-800 focus:border-amber-500/70 text-xs text-slate-200 outline-none resize-y"
                />
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-400 uppercase block mb-1">
                  Art Direction & Color Palette
                </label>
                <input
                  type="text"
                  value={`${continuityProfile.artDirection}${continuityProfile.colorPalette ? ` · ${continuityProfile.colorPalette}` : ''}`}
                  onChange={(e) => {
                    const [art, ...rest] = e.target.value.split('·');
                    onUpdateContinuity?.({
                      artDirection: art.trim(),
                      ...(rest.length ? { colorPalette: rest.join('·').trim() } : {})
                    });
                  }}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-800 focus:border-amber-500/70 text-xs text-slate-200 outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-400 uppercase block mb-1">
                  Consistent Lighting Style
                </label>
                <input
                  type="text"
                  value={continuityProfile.lightingStyle}
                  onChange={(e) => onUpdateContinuity?.({ lightingStyle: e.target.value })}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-800 focus:border-amber-500/70 text-xs text-slate-200 outline-none"
                />
              </div>
            </div>
          )}
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-white">Analyzed Storyboard Scenes</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Review or refine prompts, edit narration, and generate continuity-locked assets individually or in batch.
          </p>
        </div>
        <div className="text-xs text-slate-400 font-mono">
          Total Scenes: <span className="text-amber-400 font-semibold">{scenes.length}</span>
        </div>
      </div>

      <div className="space-y-4">
        {scenes.map((scene, index) => {
          const isCurrentGenerating = activeGeneratingSceneId === scene.id;

          return (
            <div
              key={scene.id}
              className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all space-y-4"
            >
              {/* Scene Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono text-xs font-bold">
                    #{scene.sequence}
                  </div>
                  <div>
                    <input
                      type="text"
                      value={scene.title}
                      onChange={(e) => onUpdateScene(scene.id, { title: e.target.value })}
                      className="bg-transparent text-sm font-semibold text-white focus:bg-slate-950 px-2 py-0.5 rounded border border-transparent focus:border-slate-700 outline-none"
                    />
                  </div>
                </div>

                {/* Status Badges & Reorder Controls */}
                <div className="flex items-center gap-3">
                  {/* Image status */}
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="text-slate-400">Image:</span>
                    {scene.imageStatus === 'completed' ? (
                      <span className="flex items-center gap-1 text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Ready
                      </span>
                    ) : scene.imageStatus === 'processing' ? (
                      <span className="flex items-center gap-1 text-amber-400 font-medium animate-pulse">
                        <RotateCw className="w-3.5 h-3.5 animate-spin" /> Generating
                      </span>
                    ) : scene.imageStatus === 'failed' ? (
                      <span className="flex items-center gap-1 text-rose-400 font-medium">
                        <AlertCircle className="w-3.5 h-3.5" /> Failed
                      </span>
                    ) : (
                      <span className="text-slate-500">Pending</span>
                    )}
                  </div>

                  <span className="text-slate-700">·</span>

                  {/* Voice status */}
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="text-slate-400">Voice:</span>
                    {scene.voiceStatus === 'completed' ? (
                      <span className="flex items-center gap-1 text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" /> {scene.effectiveDurationSec}s
                      </span>
                    ) : scene.voiceStatus === 'processing' ? (
                      <span className="flex items-center gap-1 text-amber-400 font-medium animate-pulse">
                        <RotateCw className="w-3.5 h-3.5 animate-spin" /> Generating
                      </span>
                    ) : scene.voiceStatus === 'failed' ? (
                      <span className="flex items-center gap-1 text-rose-400 font-medium">
                        <AlertCircle className="w-3.5 h-3.5" /> Failed
                      </span>
                    ) : (
                      <span className="text-slate-500">Pending</span>
                    )}
                  </div>

                  {/* Move Up / Down Buttons */}
                  <div className="flex items-center gap-1 ml-2">
                    <button
                      onClick={() => onReorderScenes(index, Math.max(0, index - 1))}
                      disabled={index === 0}
                      className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400"
                      title="Move Scene Up"
                    >
                      <ChevronUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onReorderScenes(index, Math.min(scenes.length - 1, index + 1))}
                      disabled={index === scenes.length - 1}
                      className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400"
                      title="Move Scene Down"
                    >
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Scene Content Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                {/* Left/Middle: Narration & Image Prompt Editors */}
                <div className="lg:col-span-8 space-y-3">
                  {/* Narration Text Input */}
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Narration Voiceover Text (Verbatim)
                    </label>
                    <textarea
                      value={scene.narration}
                      onChange={(e) => onUpdateScene(scene.id, { narration: e.target.value })}
                      rows={2}
                      className="w-full p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 focus:border-amber-500/80 text-xs text-slate-100 outline-none leading-relaxed resize-y"
                    />
                  </div>

                  {/* Image Generation Prompt Input */}
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Continuity-Locked Visual Image Prompt
                    </label>
                    <textarea
                      value={scene.imagePrompt}
                      onChange={(e) => onUpdateScene(scene.id, { imagePrompt: e.target.value })}
                      rows={3}
                      className="w-full p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 focus:border-amber-500/80 text-xs text-slate-200 outline-none leading-relaxed resize-y font-mono"
                    />
                    {scene.continuityNotes && (
                      <p className="mt-1 text-[11px] text-amber-300/80 leading-relaxed">
                        <span className="font-semibold text-amber-400">Continuity Link:</span> {scene.continuityNotes}
                      </p>
                    )}
                  </div>

                  {/* Scene Direction Controls (Camera, Motion & Manual Duration) */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold block mb-1">
                        Camera Angle
                      </span>
                      <input
                        type="text"
                        value={scene.cameraAngle || 'medium shot'}
                        onChange={(e) => onUpdateScene(scene.id, { cameraAngle: e.target.value })}
                        className="w-full p-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-slate-300 outline-none"
                      />
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold block mb-1">
                        Zoom / Motion Effect
                      </span>
                      <select
                        value={scene.animationStyle || 'auto'}
                        onChange={(e) =>
                          onUpdateScene(scene.id, { animationStyle: e.target.value as AnimationStyle })
                        }
                        className="w-full p-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-slate-300 outline-none"
                      >
                        <option value="auto">Auto (Zoom In/Out)</option>
                        <option value="zoom-in">Zoom In</option>
                        <option value="zoom-out">Zoom Out</option>
                        <option value="pan-left">Pan Left</option>
                        <option value="pan-right">Pan Right</option>
                        <option value="static">Static (No Zoom)</option>
                      </select>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold block mb-1">
                        Manual Duration (if no audio)
                      </span>
                      <input
                        type="number"
                        step="0.5"
                        min="1"
                        max="30"
                        value={scene.customDurationSec || 4.0}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value) || 4.0;
                          onUpdateScene(scene.id, { customDurationSec: val, effectiveDurationSec: val });
                        }}
                        className="w-full p-1.5 rounded bg-slate-950 border border-slate-800 text-xs text-slate-300 font-mono outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Right: Media Thumbnail Preview & Action Buttons */}
                <div className="lg:col-span-4 flex flex-col justify-between space-y-3 bg-slate-950/40 p-3 rounded-lg border border-slate-800/60">
                  {/* Thumbnail */}
                  <div className="relative w-full aspect-video rounded-md bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center">
                    {scene.imageUrl ? (
                      <img
                        src={scene.imageUrl}
                        alt={scene.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex flex-col items-center gap-1.5 text-slate-600">
                        <ImageIcon className="w-6 h-6" />
                        <span className="text-[11px]">Image not generated</span>
                      </div>
                    )}

                    {scene.audioDurationSec > 0 && (
                      <div className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/80 border border-white/10 text-[10px] font-mono text-amber-400">
                        {scene.audioDurationSec}s
                      </div>
                    )}
                  </div>

                  {/* Individual Action Buttons */}
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onGenerateImage(scene.id)}
                        disabled={isCurrentGenerating}
                        className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all disabled:opacity-50"
                      >
                        <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                        <span>{scene.imagePath ? 'Regenerate' : 'Generate'} Image</span>
                      </button>

                      <button
                        onClick={() => onGenerateVoice(scene.id)}
                        disabled={isCurrentGenerating}
                        className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all disabled:opacity-50"
                      >
                        <Mic className="w-3.5 h-3.5 text-amber-400" />
                        <span>{scene.audioPath ? 'Regenerate' : 'Generate'} Voice</span>
                      </button>
                    </div>

                    {scene.audioUrl && (
                      <button
                        onClick={() => handlePlayAudio(scene)}
                        className={`w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          playingAudioId === scene.id
                            ? 'bg-amber-500 text-slate-950 border-amber-400 animate-pulse'
                            : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700'
                        }`}
                      >
                        <Play className="w-3.5 h-3.5" />
                        <span>{playingAudioId === scene.id ? 'Stop Narration' : 'Listen to Audio'}</span>
                      </button>
                    )}

                    {scene.errorMessage && (
                      <div className="p-2 rounded-md bg-rose-950/50 border border-rose-800/70 text-[11px] text-rose-300 break-words">
                        {scene.errorMessage}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
