import React, { useRef } from 'react';
import { Player, PlayerRef } from '@remotion/player';
import { VideoComposition } from '../../remotion/VideoComposition';
import { Scene, AspectRatio, VisualStyle, MusicTrack, MotionSpeed, SubtitleStyle } from '../../types';
import { SUBTITLE_STYLE_PRESETS } from '../../utils/studioStyles';
import { Film, Music, Captions } from 'lucide-react';

interface VideoPlayerProps {
  scenes: Scene[];
  aspectRatio: AspectRatio;
  style: VisualStyle;
  fps?: number;
  totalDurationSec: number;
  totalDurationFrames: number;
  musicTrack?: MusicTrack | null;
  showCaptions?: boolean;
  subtitleStyle?: SubtitleStyle;
  autoMotion?: boolean;
  motionSpeed?: MotionSpeed;
  narrationVolume?: number;
  onToggleCaptions?: (next: boolean) => void;
  onChangeSubtitleStyle?: (next: SubtitleStyle) => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  scenes,
  aspectRatio,
  style,
  fps = 30,
  totalDurationSec,
  totalDurationFrames,
  musicTrack,
  showCaptions = true,
  subtitleStyle = 'classic-pill',
  autoMotion = true,
  motionSpeed = 'slow',
  narrationVolume,
  onToggleCaptions,
  onChangeSubtitleStyle
}) => {
  const playerRef = useRef<PlayerRef>(null);
  const isPortrait = aspectRatio === '9:16';
  const width = isPortrait ? 1080 : 1920;
  const height = isPortrait ? 1920 : 1080;

  const validDurationInFrames = Math.max(1, totalDurationFrames || 120);

  const jumpToScene = (scene: Scene) => {
    if (playerRef.current) {
      playerRef.current.seekTo(scene.startFrame);
      playerRef.current.play();
    }
  };

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remainder = (sec % 60).toFixed(1);
    return `${String(mins).padStart(2, '0')}:${remainder.padStart(4, '0')}`;
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/60 rounded-xl border border-slate-800 overflow-hidden">
      {/* Player Header bar */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950/40 gap-4">
        <div className="flex items-center gap-2 min-w-0">
          <Film className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider whitespace-nowrap">
            Video Preview
          </span>
          <span className="text-xs text-slate-500">·</span>
          <span className="text-xs text-slate-400 font-mono whitespace-nowrap">
            {aspectRatio} ({width}×{height})
          </span>
          {musicTrack && (
            <>
              <span className="text-xs text-slate-500">·</span>
              <span className="inline-flex items-center gap-1 text-xs text-emerald-400 truncate">
                <Music className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{musicTrack.name}</span>
              </span>
            </>
          )}
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          {showCaptions && onChangeSubtitleStyle && (
            <select
              value={subtitleStyle}
              onChange={(e) => onChangeSubtitleStyle(e.target.value as SubtitleStyle)}
              className="px-2 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60 cursor-pointer"
              title="Subtitle style"
            >
              {SUBTITLE_STYLE_PRESETS.map(p => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          )}
          {onToggleCaptions && (
            <button
              type="button"
              onClick={() => onToggleCaptions(!showCaptions)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border transition-colors whitespace-nowrap cursor-pointer ${
                showCaptions
                  ? 'bg-slate-800 border-amber-500/40 text-amber-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Captions className="w-3.5 h-3.5" />
              <span>{showCaptions ? 'Subtitles On' : 'Subtitles Off'}</span>
            </button>
          )}
          <div className="text-xs font-mono text-slate-300 whitespace-nowrap">
            <span className="text-amber-400">{formatSeconds(totalDurationSec)}</span>
            <span className="text-slate-500"> / </span>
            <span className="text-slate-400">{validDurationInFrames} frames</span>
          </div>
        </div>
      </div>

      {/* Main Video Viewport Canvas */}
      <div className="relative flex-1 flex items-center justify-center p-4 bg-black/80 overflow-hidden min-h-[360px]">
        <div
          className="relative shadow-2xl rounded-lg overflow-hidden border border-slate-800"
          style={{
            aspectRatio: isPortrait ? '9 / 16' : '16 / 9',
            maxHeight: '100%',
            maxWidth: '100%',
            width: isPortrait ? '280px' : '100%'
          }}
        >
          <Player
            ref={playerRef}
            component={VideoComposition}
            inputProps={{
              scenes,
              aspectRatio,
              style,
              musicTrack,
              showCaptions,
              subtitleStyle,
              autoMotion,
              motionSpeed,
              narrationVolume
            }}
            durationInFrames={validDurationInFrames}
            compositionWidth={width}
            compositionHeight={height}
            fps={fps}
            controls
            loop
            style={{
              width: '100%',
              height: '100%',
              backgroundColor: '#020617'
            }}
          />
        </div>
      </div>

      {/* Scene Quick-Jumper Navigator */}
      {scenes.length > 0 && (
        <div className="p-3 bg-slate-950/70 border-t border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
              Jump to Scene Marker ({scenes.length} Scenes)
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
            {scenes.map((scene) => (
              <button
                key={scene.id}
                onClick={() => jumpToScene(scene)}
                className="group flex items-center gap-2 px-3 py-1.5 rounded-md bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 hover:border-amber-500/40 text-left transition-all whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span className="text-xs font-mono font-semibold text-amber-400">
                  #{scene.sequence}
                </span>
                <span className="text-xs text-slate-300 truncate max-w-[120px]">
                  {scene.title}
                </span>
                <span className="text-[10px] font-mono text-slate-500 group-hover:text-slate-400">
                  {scene.effectiveDurationSec}s
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
