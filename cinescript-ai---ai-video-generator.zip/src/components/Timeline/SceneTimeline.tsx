import React, { useEffect, useRef, useState } from 'react';
import { Player, PlayerRef } from '@remotion/player';
import { VideoComposition } from '../../remotion/VideoComposition';
import {
  AnimationStyle,
  AspectRatio,
  MotionSpeed,
  MusicPreset,
  MusicTrack,
  Scene,
  SubtitleStyle,
  VisualStyle
} from '../../types';
import {
  MOTION_SPEED_OPTIONS,
  SUBTITLE_STYLE_PRESETS
} from '../../utils/studioStyles';
import {
  Captions,
  Check,
  ChevronLeft,
  ChevronRight,
  Cpu,
  Film,
  Image as ImageIcon,
  Maximize2,
  Mic,
  Music,
  Pause,
  Play,
  Sliders,
  Trash2,
  Upload,
  Volume2
} from 'lucide-react';
import { checkPcAndServerHardware, PcHardwareProfile } from '../../services/systemCheckService';

interface SceneTimelineProps {
  projectId: string;
  scenes: Scene[];
  aspectRatio: AspectRatio;
  style: VisualStyle;
  fps?: number;
  totalDurationSec: number;
  totalDurationFrames: number;
  musicTrack?: MusicTrack | null;
  musicPresets: MusicPreset[];
  showCaptions: boolean;
  subtitleStyle: SubtitleStyle;
  autoMotion: boolean;
  motionSpeed: MotionSpeed;
  narrationVolume: number;
  onToggleCaptions: (next: boolean) => void;
  onChangeSubtitleStyle: (next: SubtitleStyle) => void;
  onToggleAutoMotion: (next: boolean) => void;
  onChangeMotionSpeed: (next: MotionSpeed) => void;
  onUpdateNarrationVolume: (vol: number) => void;
  onSelectMusicPreset: (presetId: string) => Promise<void>;
  onUploadMusicFile: (file: File) => Promise<void>;
  onUpdateMusicSettings: (updates: Partial<MusicTrack>) => Promise<void>;
  onRemoveMusic: () => Promise<void>;
  onUpdateScene: (sceneId: string, updates: Partial<Scene>) => void;
  onOpenExport: () => void;
}

export const SceneTimeline: React.FC<SceneTimelineProps> = ({
  scenes,
  aspectRatio,
  style,
  fps = 30,
  totalDurationSec,
  totalDurationFrames,
  musicTrack,
  musicPresets,
  showCaptions,
  subtitleStyle,
  autoMotion,
  motionSpeed,
  narrationVolume,
  onToggleCaptions,
  onChangeSubtitleStyle,
  onToggleAutoMotion,
  onChangeMotionSpeed,
  onUpdateNarrationVolume,
  onSelectMusicPreset,
  onUploadMusicFile,
  onUpdateMusicSettings,
  onRemoveMusic,
  onUpdateScene,
  onOpenExport
}) => {
  const playerRef = useRef<PlayerRef>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  const [inspectorTab, setInspectorTab] = useState<'music' | 'style' | 'scene'>('music');
  const [selectedSceneId, setSelectedSceneId] = useState<string>(scenes[0]?.id || '');
  const [currentFrame, setCurrentFrame] = useState<number>(0);
  const [isApplyingMusic, setIsApplyingMusic] = useState<string | null>(null);
  const [previewingPresetId, setPreviewingPresetId] = useState<string | null>(null);
  const [hwProfile, setHwProfile] = useState<PcHardwareProfile | null>(null);

  const isPortrait = aspectRatio === '9:16';
  const compWidth = isPortrait ? 1080 : 1920;
  const compHeight = isPortrait ? 1920 : 1080;
  const validTotalFrames = Math.max(1, totalDurationFrames || 120);

  useEffect(() => {
    checkPcAndServerHardware().then(setHwProfile).catch(() => {});
  }, []);

  useEffect(() => {
    if (!scenes.some(s => s.id === selectedSceneId) && scenes[0]?.id) {
      setSelectedSceneId(scenes[0].id);
    }
  }, [scenes, selectedSceneId]);

  useEffect(() => {
    const player = playerRef.current;
    if (!player) return;
    const onFrameUpdate = (e: { detail: { frame: number } }) => {
      setCurrentFrame(e.detail.frame);
    };
    player.addEventListener('frameupdate', onFrameUpdate as any);
    return () => {
      player.removeEventListener('frameupdate', onFrameUpdate as any);
    };
  }, [validTotalFrames]);

  useEffect(() => {
    return () => {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        previewAudioRef.current = null;
      }
    };
  }, []);

  const selectedScene = scenes.find(s => s.id === selectedSceneId) || scenes[0];

  const seekToFrame = (frame: number) => {
    const clamped = Math.max(0, Math.min(validTotalFrames - 1, Math.round(frame)));
    setCurrentFrame(clamped);
    playerRef.current?.seekTo(clamped);
  };

  const handleRulerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    seekToFrame(ratio * validTotalFrames);
  };

  const handlePreviewPreset = (preset: MusicPreset) => {
    if (previewingPresetId === preset.id && previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current = null;
      setPreviewingPresetId(null);
      return;
    }
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current = null;
    }
    const audio = new Audio(preset.audioUrl);
    previewAudioRef.current = audio;
    setPreviewingPresetId(preset.id);
    audio.onended = () => setPreviewingPresetId(null);
    audio.onerror = () => setPreviewingPresetId(null);
    audio.play().catch(() => setPreviewingPresetId(null));
  };

  const handleApplyPreset = async (presetId: string) => {
    try {
      setIsApplyingMusic(presetId);
      await onSelectMusicPreset(presetId);
    } finally {
      setIsApplyingMusic(null);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsApplyingMusic('upload');
      await onUploadMusicFile(file);
    } finally {
      setIsApplyingMusic(null);
      e.target.value = '';
    }
  };

  const formatTimecode = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = (sec % 60).toFixed(1).padStart(4, '0');
    return `${String(mins).padStart(2, '0')}:${secs}`;
  };

  const musicVolPct = Math.max(0, Math.min(100, Math.round((musicTrack?.volume ?? 0.22) * 100)));
  const voiceVolPct = Math.max(1, Math.min(100, Math.round(narrationVolume * 100)));

  const handleMusicPctChange = (raw: number) => {
    const clamped = Math.max(0, Math.min(100, Math.round(raw)));
    onUpdateMusicSettings({ volume: Number((clamped / 100).toFixed(2)) });
  };

  const handleVoicePctChange = (raw: number) => {
    const clamped = Math.max(1, Math.min(100, Math.round(raw)));
    onUpdateNarrationVolume(Number((clamped / 100).toFixed(2)));
  };

  const playheadPercent = validTotalFrames > 0 ? (currentFrame / validTotalFrames) * 100 : 0;
  const rulerTicks = Math.min(10, Math.max(4, Math.ceil(totalDurationSec / 5)));

  return (
    <div className="space-y-5">
      {/* Studio Top Bar */}
      <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Video Editor, Auto Zoom & Music Studio</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Upload your music, adjust music and voice levels (1–100%), fine-tune zoom effects, and export crisp HQ MP4.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="text-xs font-mono text-slate-300 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 whitespace-nowrap tabular-nums">
              <span className="text-amber-400 font-bold">{formatTimecode(currentFrame / fps)}</span>
              <span className="text-slate-600"> / </span>
              <span>{formatTimecode(totalDurationSec)}</span>
            </div>

            <button
              type="button"
              onClick={onOpenExport}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition-all whitespace-nowrap cursor-pointer"
            >
              <Film className="w-4 h-4" />
              <span>Export HQ MP4</span>
            </button>
          </div>
        </div>

        {hwProfile && (
          <div className="pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
              <span className="inline-flex items-center gap-1.5 text-slate-300 font-medium">
                <Cpu className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  Your PC: <b className="text-white">{hwProfile.cpuCores} Cores</b>
                  {hwProfile.ramGb ? ` · ${hwProfile.ramGb} GB RAM` : ''} · {hwProfile.gpuRenderer}
                </span>
              </span>
              {hwProfile.serverInfo && (
                <span className="text-slate-400 font-mono">
                  Website CPU: {hwProfile.serverInfo.cpuCores} Cores · {hwProfile.serverInfo.freeRamGb}/{hwProfile.serverInfo.totalRamGb} GB RAM ({hwProfile.serverInfo.cpuModel})
                </span>
              )}
            </div>
            <span className="font-mono text-emerald-300">
              Auto Export Target: {hwProfile.recommendedResolution.toUpperCase()} @ {hwProfile.recommendedFps}fps ({hwProfile.tierLabel})
            </span>
          </div>
        )}
      </div>

      {/* Top Split: Live Composition Canvas + Music & Clip Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Left: Live Interactive Video Viewport */}
        <div className="lg:col-span-7 flex flex-col rounded-xl bg-slate-900/70 border border-slate-800 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950/60 gap-2 flex-wrap">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
              <Film className="w-4 h-4 text-amber-400" />
              <span>Live Editor Preview</span>
              <span className="text-slate-500">·</span>
              <span className="font-mono text-slate-400">{aspectRatio}</span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {autoMotion && (
                <select
                  value={motionSpeed}
                  onChange={(e) => onChangeMotionSpeed(e.target.value as MotionSpeed)}
                  className="px-2 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60 cursor-pointer"
                  title="Camera zoom motion speed"
                >
                  {MOTION_SPEED_OPTIONS.map(opt => (
                    <option key={opt.id} value={opt.id}>
                      {opt.shortLabel} Zoom
                    </option>
                  ))}
                </select>
              )}

              <button
                type="button"
                onClick={() => onToggleAutoMotion(!autoMotion)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border transition-colors cursor-pointer whitespace-nowrap ${
                  autoMotion
                    ? 'bg-slate-800 border-amber-500/40 text-amber-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
                title="Toggle automatic alternating slow-motion zoom-in / zoom-out"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>{autoMotion ? 'Zoom On' : 'Static'}</span>
              </button>

              <button
                type="button"
                onClick={() => onToggleCaptions(!showCaptions)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border transition-colors cursor-pointer whitespace-nowrap ${
                  showCaptions
                    ? 'bg-slate-800 border-amber-500/40 text-amber-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Captions className="w-3.5 h-3.5" />
                <span>{showCaptions ? 'Subtitles On' : 'Subtitles Off'}</span>
              </button>
            </div>
          </div>

          <div className="flex-1 flex items-center justify-center p-4 bg-black/85 min-h-[340px]">
            <div
              className="relative rounded-lg overflow-hidden border border-slate-800 shadow-2xl"
              style={{
                aspectRatio: isPortrait ? '9 / 16' : '16 / 9',
                maxHeight: '420px',
                maxWidth: '100%',
                width: isPortrait ? '236px' : '100%'
              }}
            >
              <Player
                ref={playerRef}
                component={VideoComposition}
                inputProps={{
                  scenes,
                  aspectRatio,
                  style,
                  musicTrack,
                  showCaptions,
                  subtitleStyle,
                  autoMotion,
                  motionSpeed,
                  narrationVolume
                }}
                durationInFrames={validTotalFrames}
                compositionWidth={compWidth}
                compositionHeight={compHeight}
                fps={fps}
                controls
                loop
                style={{
                  width: '100%',
                  height: '100%',
                  backgroundColor: '#020617'
                }}
              />
            </div>
          </div>
        </div>

        {/* Right: Music Mix, Subtitles & Motion, Selected Clip Inspector */}
        <div className="lg:col-span-5 flex flex-col rounded-xl bg-slate-900/70 border border-slate-800 overflow-hidden">
          <div className="flex items-center gap-1 p-1.5 bg-slate-950/80 border-b border-slate-800">
            <button
              type="button"
              onClick={() => setInspectorTab('music')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                inspectorTab === 'music'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Music className="w-3.5 h-3.5 text-amber-400" />
              <span>Audio Mix</span>
            </button>
            <button
              type="button"
              onClick={() => setInspectorTab('style')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                inspectorTab === 'style'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Captions className="w-3.5 h-3.5 text-amber-400" />
              <span>Subtitles & Zoom</span>
            </button>
            <button
              type="button"
              onClick={() => setInspectorTab('scene')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                inspectorTab === 'scene'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>Clip #{selectedScene?.sequence || 1}</span>
            </button>
          </div>

          <div className="flex-1 p-4 space-y-4 overflow-y-auto max-h-[470px]">
            {inspectorTab === 'music' ? (
              <>
                {/* Upload Custom Music */}
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-semibold text-slate-200">Upload Background Music</div>
                    <div className="text-[11px] text-slate-400">
                      MP3, WAV, M4A, AAC, OGG, or FLAC (up to 80 MB).
                    </div>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isApplyingMusic === 'upload'}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isApplyingMusic === 'upload' ? 'Uploading...' : 'Upload Music'}</span>
                  </button>
                </div>

                {/* Voiceover Narration Level (Always editable 1% - 100%) */}
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                      <Mic className="w-3.5 h-3.5 text-sky-400" />
                      <span>Voice Narration Level (1–100%)</span>
                    </span>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={voiceVolPct}
                        onChange={(e) => handleVoicePctChange(Number(e.target.value) || 1)}
                        className="w-14 px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-right font-mono text-xs text-sky-300 font-bold outline-none"
                      />
                      <span className="text-xs font-mono text-slate-400">%</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={100}
                    value={voiceVolPct}
                    onChange={(e) => handleVoicePctChange(Number(e.target.value))}
                    className="w-full accent-sky-400 cursor-pointer"
                  />

                  {/* Active Music Track Mix Controls (1% - 100%) */}
                  {musicTrack ? (
                    <div className="pt-3 border-t border-slate-800 space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-emerald-300 truncate">
                            {musicTrack.name}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            {musicTrack.source === 'upload' ? 'Uploaded Audio' : 'Studio Track'} · {musicTrack.durationSec.toFixed(1)}s
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={onRemoveMusic}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-900 transition-colors cursor-pointer"
                          title="Remove background music"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div>
                        <div className="flex items-center justify-between text-xs mb-1 gap-2">
                          <span className="text-slate-200 font-semibold flex items-center gap-1.5">
                            <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Music Level (1–100%)</span>
                          </span>
                          <div className="flex items-center gap-1.5">
                            <input
                              type="number"
                              min={1}
                              max={100}
                              value={Math.max(1, musicVolPct)}
                              onChange={(e) => handleMusicPctChange(Number(e.target.value) || 1)}
                              className="w-14 px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-right font-mono text-xs text-amber-400 font-bold outline-none"
                            />
                            <span className="text-xs font-mono text-slate-400">%</span>
                          </div>
                        </div>
                        <input
                          type="range"
                          min={1}
                          max={100}
                          value={Math.max(1, musicVolPct)}
                          onChange={(e) => handleMusicPctChange(Number(e.target.value))}
                          className="w-full accent-amber-400 cursor-pointer"
                        />
                        <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                          <button type="button" onClick={() => handleMusicPctChange(15)} className="hover:text-slate-300 cursor-pointer">15% Subtle</button>
                          <button type="button" onClick={() => handleMusicPctChange(30)} className="hover:text-slate-300 cursor-pointer">30% Balanced</button>
                          <button type="button" onClick={() => handleMusicPctChange(60)} className="hover:text-slate-300 cursor-pointer">60% Strong</button>
                          <button type="button" onClick={() => handleMusicPctChange(100)} className="hover:text-slate-300 cursor-pointer">100% Full</button>
                        </div>
                      </div>

                      {musicTrack.durationSec > 2 && (
                        <div>
                          <div className="flex items-center justify-between text-[11px] mb-1">
                            <span className="text-slate-400">Music Start Offset (Trim)</span>
                            <span className="font-mono text-slate-200">{(musicTrack.startOffsetSec || 0).toFixed(1)}s</span>
                          </div>
                          <input
                            type="range"
                            min={0}
                            max={Math.max(0, Math.floor((musicTrack.durationSec - 1) * 10))}
                            value={Math.round((musicTrack.startOffsetSec || 0) * 10)}
                            onChange={(e) => onUpdateMusicSettings({ startOffsetSec: Number(e.target.value) / 10 })}
                            className="w-full accent-amber-400 cursor-pointer"
                          />
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="flex items-center justify-between text-[11px] mb-1">
                            <span className="text-slate-400">Fade In</span>
                            <span className="font-mono text-slate-200">{musicTrack.fadeInSec.toFixed(1)}s</span>
                          </div>
                          <input
                            type="range"
                            min={0}
                            max={50}
                            value={Math.round(musicTrack.fadeInSec * 10)}
                            onChange={(e) => onUpdateMusicSettings({ fadeInSec: Number(e.target.value) / 10 })}
                            className="w-full accent-amber-400 cursor-pointer"
                          />
                        </div>
                        <div>
                          <div className="flex items-center justify-between text-[11px] mb-1">
                            <span className="text-slate-400">Fade Out</span>
                            <span className="font-mono text-slate-200">{musicTrack.fadeOutSec.toFixed(1)}s</span>
                          </div>
                          <input
                            type="range"
                            min={0}
                            max={50}
                            value={Math.round(musicTrack.fadeOutSec * 10)}
                            onChange={(e) => onUpdateMusicSettings({ fadeOutSec: Number(e.target.value) / 10 })}
                            className="w-full accent-amber-400 cursor-pointer"
                          />
                        </div>
                      </div>

                      <div className="flex items-center gap-4 pt-1">
                        <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={musicTrack.ducking}
                            onChange={(e) => onUpdateMusicSettings({ ducking: e.target.checked })}
                            className="accent-amber-400 rounded"
                          />
                          <span>Auto-duck under voice</span>
                        </label>
                        <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={musicTrack.loop}
                            onChange={(e) => onUpdateMusicSettings({ loop: e.target.checked })}
                            className="accent-amber-400 rounded"
                          />
                          <span>Loop music</span>
                        </label>
                      </div>
                    </div>
                  ) : (
                    <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                      Upload your own music track above or choose a built-in studio track below to mix music level (1–100%).
                    </div>
                  )}
                </div>

                {/* Built-in Studio Tracks */}
                <div className="space-y-2">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Built-In Studio Tracks
                  </div>
                  <div className="space-y-1.5">
                    {musicPresets.map((preset) => {
                      const isActive = musicTrack?.presetId === preset.id;
                      const isPreviewing = previewingPresetId === preset.id;
                      return (
                        <div
                          key={preset.id}
                          className={`flex items-center justify-between gap-2 p-2.5 rounded-lg border transition-colors ${
                            isActive
                              ? 'bg-slate-800/90 border-amber-500/40'
                              : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <button
                              type="button"
                              onClick={() => handlePreviewPreset(preset)}
                              className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-amber-400 shrink-0 cursor-pointer"
                              title={isPreviewing ? 'Stop preview' : 'Preview track'}
                            >
                              {isPreviewing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                            </button>
                            <div className="min-w-0">
                              <div className="text-xs font-semibold text-slate-200 truncate">
                                {preset.name}
                              </div>
                              <div className="text-[11px] text-slate-500 truncate font-mono">
                                {preset.mood} · {preset.bpm} BPM
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleApplyPreset(preset.id)}
                            disabled={isApplyingMusic === preset.id}
                            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                              isActive
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200'
                            }`}
                          >
                            {isActive ? (
                              <>
                                <Check className="w-3.5 h-3.5" />
                                <span>Active</span>
                              </>
                            ) : isApplyingMusic === preset.id ? (
                              <span>Adding...</span>
                            ) : (
                              <span>Use Track</span>
                            )}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            ) : inspectorTab === 'style' ? (
              <div className="space-y-4">
                {/* Subtitles ON/OFF + Style Picker */}
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-semibold text-white">Video Subtitles</div>
                      <div className="text-[11px] text-slate-400">
                        Choose a subtitle style below or turn subtitles off for clean export.
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onToggleCaptions(!showCaptions)}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-bold cursor-pointer transition-colors shrink-0 ${
                        showCaptions
                          ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-300'
                          : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {showCaptions ? 'Subtitles: ON' : 'Subtitles: OFF'}
                    </button>
                  </div>

                  <div className={`grid grid-cols-2 gap-2 ${!showCaptions ? 'opacity-45 pointer-events-none' : ''}`}>
                    {SUBTITLE_STYLE_PRESETS.map(preset => {
                      const active = subtitleStyle === preset.id;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => onChangeSubtitleStyle(preset.id)}
                          className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer space-y-1.5 ${
                            active
                              ? 'bg-slate-800 border-amber-400 shadow-md'
                              : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="h-8 rounded-md bg-slate-950 flex items-center justify-center px-2 overflow-hidden">
                            <span
                              style={{
                                color: preset.textColor,
                                backgroundColor: preset.bgColor || 'transparent',
                                border: preset.borderColor ? `1px solid ${preset.borderColor}` : 'none',
                                padding: preset.bgColor ? '2px 7px' : '0',
                                borderRadius: preset.bgColor ? 5 : 0,
                                fontFamily: preset.fontFamily,
                                fontWeight: preset.fontWeight,
                                fontSize: '10px',
                                letterSpacing: preset.letterSpacing,
                                WebkitTextStroke: preset.strokeColor ? `1px ${preset.strokeColor}` : undefined
                              }}
                              className="truncate"
                            >
                              {preset.uppercase ? 'SAMPLE TEXT' : 'Sample Subtitle'}
                            </span>
                          </div>
                          <div className="text-[11px] font-semibold text-slate-200 truncate">
                            {preset.name}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Slow-Motion Zoom Speed Controls */}
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-semibold text-white">Slow-Motion Zoom In / Out</div>
                      <div className="text-[11px] text-slate-400">
                        Control how gently the camera zooms across every scene.
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onToggleAutoMotion(!autoMotion)}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-bold cursor-pointer transition-colors shrink-0 ${
                        autoMotion
                          ? 'bg-amber-500/15 border-amber-500/50 text-amber-300'
                          : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {autoMotion ? 'Motion: ON' : 'Static'}
                    </button>
                  </div>

                  <div className={`grid grid-cols-1 gap-2 ${!autoMotion ? 'opacity-45 pointer-events-none' : ''}`}>
                    {MOTION_SPEED_OPTIONS.map(opt => {
                      const active = motionSpeed === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => onChangeMotionSpeed(opt.id)}
                          className={`p-2.5 rounded-lg border text-left flex items-center justify-between gap-2 transition-all cursor-pointer ${
                            active
                              ? 'bg-slate-800 border-amber-400 text-white'
                              : 'bg-slate-900/70 border-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <div>
                            <div className="text-xs font-semibold">{opt.label}</div>
                            <div className="text-[11px] text-slate-400">{opt.description}</div>
                          </div>
                          {active && <Check className="w-4 h-4 text-amber-400 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : selectedScene ? (
              <div className="space-y-3.5">
                <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Clip {selectedScene.sequence} of {scenes.length}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={selectedScene.sequence <= 1}
                      onClick={() => {
                        const prev = scenes[Math.max(0, selectedScene.sequence - 2)];
                        if (prev) setSelectedSceneId(prev.id);
                      }}
                      className="p-1 rounded bg-slate-950 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-35 cursor-pointer"
                      title="Previous scene"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={selectedScene.sequence >= scenes.length}
                      onClick={() => {
                        const next = scenes[Math.min(scenes.length - 1, selectedScene.sequence)];
                        if (next) setSelectedSceneId(next.id);
                      }}
                      className="p-1 rounded bg-slate-950 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-35 cursor-pointer"
                      title="Next scene"
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-20 h-12 rounded-lg overflow-hidden bg-slate-950 border border-slate-800 shrink-0 flex items-center justify-center">
                    {selectedScene.imageUrl ? (
                      <img
                        src={selectedScene.imageUrl}
                        alt={selectedScene.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <ImageIcon className="w-4 h-4 text-slate-600" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-mono text-amber-400 font-bold">
                      Scene #{selectedScene.sequence}
                    </div>
                    <div className="text-xs text-slate-400 font-mono">
                      Frames {selectedScene.startFrame}–{selectedScene.startFrame + selectedScene.durationInFrames} ({selectedScene.effectiveDurationSec.toFixed(2)}s)
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      seekToFrame(selectedScene.startFrame);
                      playerRef.current?.play();
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-amber-300 cursor-pointer whitespace-nowrap"
                  >
                    Play Here
                  </button>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 uppercase block mb-1">
                    Zoom / Motion Effect
                  </label>
                  <select
                    value={selectedScene.animationStyle || 'auto'}
                    onChange={(e) =>
                      onUpdateScene(selectedScene.id, { animationStyle: e.target.value as AnimationStyle })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60"
                  >
                    <option value="auto">Auto (Slow Zoom In / Out)</option>
                    <option value="slow-zoom-in">Slow Motion Zoom In</option>
                    <option value="slow-zoom-out">Slow Motion Zoom Out</option>
                    <option value="zoom-in">Zoom In</option>
                    <option value="zoom-out">Zoom Out</option>
                    <option value="pan-left">Pan Left</option>
                    <option value="pan-right">Pan Right</option>
                    <option value="static">Static (No Zoom)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 uppercase block mb-1">
                    Scene Title
                  </label>
                  <input
                    type="text"
                    value={selectedScene.title}
                    onChange={(e) => onUpdateScene(selectedScene.id, { title: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 uppercase block mb-1">
                    Caption / Narration Text
                  </label>
                  <textarea
                    rows={3}
                    value={selectedScene.narration}
                    onChange={(e) => onUpdateScene(selectedScene.id, { narration: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="font-semibold text-slate-400 uppercase">
                      Clip Duration (seconds)
                    </span>
                    <span className="font-mono text-amber-400 font-bold">
                      {selectedScene.effectiveDurationSec.toFixed(2)}s
                    </span>
                  </div>
                  {selectedScene.audioDurationSec > 0 ? (
                    <p className="text-[11px] text-slate-500">
                      Locked to measured voiceover length ({selectedScene.audioDurationSec.toFixed(2)}s) for zero audio-visual drift.
                    </p>
                  ) : (
                    <input
                      type="range"
                      min={15}
                      max={150}
                      value={Math.round((selectedScene.customDurationSec || selectedScene.effectiveDurationSec || 4) * 10)}
                      onChange={(e) => {
                        const val = Number(e.target.value) / 10;
                        onUpdateScene(selectedScene.id, {
                          customDurationSec: val,
                          effectiveDurationSec: val
                        });
                      }}
                      className="w-full accent-amber-400 cursor-pointer"
                    />
                  )}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {/* Bottom: Multi-Track Creatomate-Style Timeline */}
      <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-3 select-none">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-200 uppercase tracking-wider">
              Multi-Track Timeline
            </span>
            <span className="text-slate-500">·</span>
            <span className="font-mono text-slate-400">
              {scenes.length} clips · {validTotalFrames} frames @{fps}fps
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Click any clip or ruler position to scrub preview
          </span>
        </div>

        {/* Clickable Time Ruler */}
        <div className="flex items-center gap-3">
          <div className="w-28 shrink-0 text-[11px] font-mono text-slate-500 text-right pr-2">
            TIMECODE
          </div>
          <div
            onClick={handleRulerClick}
            className="relative flex-1 h-6 rounded bg-slate-950 border border-slate-800 cursor-pointer overflow-hidden flex items-center justify-between px-2"
          >
            {Array.from({ length: rulerTicks + 1 }).map((_, idx) => {
              const t = (idx / rulerTicks) * totalDurationSec;
              return (
                <span key={idx} className="text-[10px] font-mono text-slate-500">
                  {formatTimecode(t)}
                </span>
              );
            })}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-amber-400 pointer-events-none"
              style={{ left: `${playheadPercent}%` }}
            />
          </div>
        </div>

        {/* Track Rows Container */}
        <div className="space-y-2">
          {/* Track 1: Visual Scenes */}
          <div className="flex items-center gap-3">
            <div className="w-28 shrink-0 flex items-center justify-end gap-1.5 text-xs font-medium text-slate-300 pr-2">
              <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>Visuals</span>
            </div>
            <div className="relative flex-1 h-16 rounded-lg bg-slate-950 border border-slate-800 flex overflow-hidden">
              {scenes.map((scene) => {
                const widthPct = totalDurationSec > 0
                  ? (scene.effectiveDurationSec / totalDurationSec) * 100
                  : 100 / Math.max(1, scenes.length);
                const isSelected = selectedScene?.id === scene.id;
                const motionLabel = !autoMotion
                  ? 'static'
                  : scene.animationStyle === 'auto'
                  ? scene.sequence % 2 === 1
                    ? 'slow zoom-in'
                    : 'slow zoom-out'
                  : scene.animationStyle;
                return (
                  <button
                    key={scene.id}
                    type="button"
                    onClick={() => {
                      setSelectedSceneId(scene.id);
                      setInspectorTab('scene');
                      seekToFrame(scene.startFrame);
                    }}
                    style={{ width: `${widthPct}%` }}
                    className={`h-full border-r border-slate-800 relative flex items-center gap-2 px-2 text-left overflow-hidden transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/15 ring-1 ring-inset ring-amber-400/70'
                        : 'hover:bg-slate-900/90'
                    }`}
                    title={`Scene ${scene.sequence}: ${scene.title} (${scene.effectiveDurationSec.toFixed(2)}s · ${motionLabel})`}
                  >
                    {scene.imageUrl && (
                      <img
                        src={scene.imageUrl}
                        alt=""
                        className="w-9 h-9 rounded object-cover border border-slate-800 shrink-0"
                      />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1 text-[10px] font-mono">
                        <span className="text-amber-400 font-bold">#{scene.sequence}</span>
                        <span className="text-slate-400">{scene.effectiveDurationSec.toFixed(1)}s</span>
                      </div>
                      <div className="text-[11px] text-slate-200 truncate font-medium">
                        {scene.title}
                      </div>
                      <div className="text-[10px] text-slate-500 truncate capitalize">
                        {motionLabel.replace('-', ' ')}
                      </div>
                    </div>
                  </button>
                );
              })}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-amber-400/80 pointer-events-none"
                style={{ left: `${playheadPercent}%` }}
              />
            </div>
          </div>

          {/* Track 2: Voiceover Narration */}
          <div className="flex items-center gap-3">
            <div className="w-28 shrink-0 flex items-center justify-end gap-1.5 text-xs font-medium text-slate-300 pr-2">
              <Mic className="w-3.5 h-3.5 text-sky-400" />
              <span>Voice ({voiceVolPct}%)</span>
            </div>
            <div className="relative flex-1 h-11 rounded-lg bg-slate-950 border border-slate-800 flex overflow-hidden">
              {scenes.map((scene) => {
                const widthPct = totalDurationSec > 0
                  ? (scene.effectiveDurationSec / totalDurationSec) * 100
                  : 100 / Math.max(1, scenes.length);
                const hasVoice = scene.voiceStatus === 'completed' && Boolean(scene.audioUrl);
                return (
                  <div
                    key={scene.id}
                    onClick={() => seekToFrame(scene.startFrame)}
                    style={{ width: `${widthPct}%` }}
                    className={`h-full border-r border-slate-800 px-2 flex items-center justify-between overflow-hidden cursor-pointer ${
                      hasVoice ? 'bg-sky-950/35 hover:bg-sky-900/40' : 'bg-slate-950 opacity-50'
                    }`}
                  >
                    <span className="text-[10px] font-mono text-sky-300 truncate">
                      {hasVoice ? `VO #${scene.sequence}` : 'Silent'}
                    </span>
                    {hasVoice && (
                      <span className="text-[10px] font-mono text-slate-400 shrink-0">
                        {scene.audioDurationSec.toFixed(1)}s
                      </span>
                    )}
                  </div>
                );
              })}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-amber-400/80 pointer-events-none"
                style={{ left: `${playheadPercent}%` }}
              />
            </div>
          </div>

          {/* Track 3: Background Music */}
          <div className="flex items-center gap-3">
            <div className="w-28 shrink-0 flex items-center justify-end gap-1.5 text-xs font-medium text-slate-300 pr-2">
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Music {musicTrack ? `(${musicVolPct}%)` : ''}</span>
            </div>
            <div
              onClick={() => setInspectorTab('music')}
              className="relative flex-1 h-11 rounded-lg bg-slate-950 border border-slate-800 overflow-hidden flex items-center cursor-pointer hover:border-slate-700 transition-colors"
            >
              {musicTrack ? (
                <div
                  className="h-full bg-emerald-950/45 border-r border-emerald-500/30 flex items-center justify-between px-3 gap-3"
                  style={{
                    width:
                      musicTrack.loop || totalDurationSec <= 0
                        ? '100%'
                        : `${Math.min(100, (musicTrack.durationSec / totalDurationSec) * 100)}%`
                  }}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <Music className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="text-xs font-semibold text-emerald-200 truncate">
                      {musicTrack.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] font-mono text-emerald-300/90 shrink-0">
                    <span>Level {musicVolPct}%</span>
                    <span>{musicTrack.loop ? 'Looped' : `${musicTrack.durationSec.toFixed(1)}s`}</span>
                    {musicTrack.ducking && <span>Auto-Duck</span>}
                  </div>
                </div>
              ) : (
                <div className="w-full px-3 flex items-center justify-between text-xs text-slate-500">
                  <span>No background music added — click to upload MP3/WAV or pick a studio track</span>
                  <span className="text-amber-400 font-semibold">+ Upload / Add Music</span>
                </div>
              )}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-amber-400/80 pointer-events-none"
                style={{ left: `${playheadPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
