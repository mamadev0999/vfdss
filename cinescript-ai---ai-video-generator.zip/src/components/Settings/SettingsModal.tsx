import React, { useState, useEffect, useRef } from 'react';
import { ProjectSettings } from '../../types';
import {
  Sliders,
  X,
  Check,
  Key,
  Globe,
  Volume2,
  RotateCw,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Activity,
  Eye,
  EyeOff,
  Play
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ProjectSettings;
  onSaveSettings: (newSettings: Partial<ProjectSettings>) => void;
}

const DEFAULT_BASE_URL = 'https://kite-mushily-bling.ngrok-free.dev';

export const GEMINI_MODEL_OPTIONS = [
  { id: 'gemini-3.1-flash-lite', label: 'Gemini 3.1 Flash Lite (Recommended - Auto-Fallback Enabled)' },
  { id: 'gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash Lite (Ultra-Fast High Availability)' },
  { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash (Balanced & Fast)' },
  { id: 'gemini-4-hydrogen', label: 'Gemini 4 Hydrogen (Deep Reasoning)' },
  { id: 'gemini-flash-lite-latest', label: 'Gemini Flash Lite Latest' },
  { id: 'gemini-3.7-flash', label: 'Gemini 3.7 Flash' },
  { id: 'gemini-3.5-flash', label: 'Gemini 3.5 Flash' },
  { id: 'gemini-4-argon', label: 'Gemini 4 Argon (Custom Paid Key)' },
  { id: 'gemini-4-carbon', label: 'Gemini 4 Carbon (Custom Paid Key)' },
  { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash (Custom Key)' },
  { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro (Custom Key)' }
];

function normalizeDisplayBaseUrl(url?: string): string {
  const cleaned = (url || DEFAULT_BASE_URL).trim().replace(/\/+$/, '');
  return (
    cleaned
      .replace(/\/docs$/i, '')
      .replace(/\/image$/i, '')
      .replace(/\/bulk$/i, '')
      .replace(/\/generate$/i, '') || DEFAULT_BASE_URL
  );
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings
}) => {
  const [geminiKey, setGeminiKey] = useState(settings.geminiApiKey || '');
  const [geminiModel, setGeminiModel] = useState(settings.geminiModel || 'gemini-3.1-flash-lite');
  const [showGeminiKey, setShowGeminiKey] = useState(false);

  const [groqKey, setGroqKey] = useState(settings.groqApiKey || '');
  const [showGroqKey, setShowGroqKey] = useState(false);

  const [imageEndpoint, setImageEndpoint] = useState(
    normalizeDisplayBaseUrl(settings.imageApiUrl)
  );
  const normalizeModelOption = (m?: string) => (m === 'narwhal' ? 'narwhal' : 'beluga');
  const [imageModel, setImageModel] = useState(normalizeModelOption(settings.imageModel));

  // Testing states for Gemini (Script Analysis & Splitting)
  const [testingGemini, setTestingGemini] = useState(false);
  const [geminiResult, setGeminiResult] = useState<{
    ok: boolean;
    message?: string;
    warning?: string;
    error?: string;
    latencyMs?: number;
    reply?: string;
    model?: string;
    usedFallback?: boolean;
  } | null>(null);

  // Testing states for Groq Voice TTS
  const [testingGroq, setTestingGroq] = useState(false);
  const [groqResult, setGroqResult] = useState<{
    ok: boolean;
    message?: string;
    error?: string;
    latencyMs?: number;
    voice?: string;
    keySource?: 'custom' | 'server-env' | 'none';
    durationSec?: number;
    audioPreviewUrl?: string;
    requiresTermsAcceptance?: boolean;
    termsUrl?: string;
  } | null>(null);
  const [isPlayingTestAudio, setIsPlayingTestAudio] = useState(false);
  const testAudioRef = useRef<HTMLAudioElement | null>(null);

  // Testing states for Backup Edge TTS
  const [testingTTS, setTestingTTS] = useState(false);
  const [ttsResult, setTtsResult] = useState<{
    ok: boolean;
    message?: string;
    error?: string;
    latencyMs?: number;
  } | null>(null);

  // Testing states for Image Endpoint
  const [testingImageStatus, setTestingImageStatus] = useState(false);
  const [testingImageGen, setTestingImageGen] = useState(false);
  const [imageResult, setImageResult] = useState<{
    ok: boolean;
    message?: string;
    error?: string;
    latencyMs?: number;
    contentType?: string;
    imageSizeKb?: number;
    previewUrl?: string;
    jobId?: string;
    baseUrl?: string;
    statusData?: any;
  } | null>(null);

  // Sync local modal state whenever modal opens or settings change externally
  useEffect(() => {
    if (isOpen) {
      setGeminiKey(settings.geminiApiKey || '');
      setGeminiModel(settings.geminiModel || 'gemini-3.1-flash-lite');
      setGroqKey(settings.groqApiKey || '');
      setImageEndpoint(normalizeDisplayBaseUrl(settings.imageApiUrl));
      setImageModel(normalizeModelOption(settings.imageModel));
    } else if (testAudioRef.current) {
      testAudioRef.current.pause();
      setIsPlayingTestAudio(false);
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleTestGemini = async () => {
    setTestingGemini(true);
    setGeminiResult(null);
    try {
      const res = await fetch('/api/test/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: geminiKey.trim() || undefined,
          model: geminiModel
        })
      });
      const data = await res.json();
      setGeminiResult(data);
    } catch (err: any) {
      setGeminiResult({
        ok: false,
        error: `Network request failed: ${err.message}`
      });
    } finally {
      setTestingGemini(false);
    }
  };

  const handleTestGroqVoice = async () => {
    setTestingGroq(true);
    setGroqResult(null);
    if (testAudioRef.current) {
      testAudioRef.current.pause();
      setIsPlayingTestAudio(false);
    }
    try {
      const res = await fetch('/api/test/groq', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: groqKey.trim(),
          voiceId: settings.voiceId || 'troy'
        })
      });
      const data = await res.json();
      setGroqResult(data);
    } catch (err: any) {
      setGroqResult({
        ok: false,
        error: `Network request failed: ${err.message}`
      });
    } finally {
      setTestingGroq(false);
    }
  };

  const handlePlayGroqTestAudio = () => {
    if (!groqResult?.audioPreviewUrl) return;
    if (isPlayingTestAudio && testAudioRef.current) {
      testAudioRef.current.pause();
      setIsPlayingTestAudio(false);
      return;
    }
    const audio = new Audio(groqResult.audioPreviewUrl);
    testAudioRef.current = audio;
    setIsPlayingTestAudio(true);
    audio.play().catch(() => setIsPlayingTestAudio(false));
    audio.onended = () => setIsPlayingTestAudio(false);
    audio.onerror = () => setIsPlayingTestAudio(false);
  };

  const handleCheckFlowStatus = async () => {
    setTestingImageStatus(true);
    setImageResult(null);
    try {
      const res = await fetch('/api/test/image-endpoint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: imageEndpoint.trim(),
          mode: 'status'
        })
      });
      const data = await res.json();
      setImageResult(data);
    } catch (err: any) {
      setImageResult({
        ok: false,
        error: `Failed to check Flow status: ${err.message}`
      });
    } finally {
      setTestingImageStatus(false);
    }
  };

  const handleTestImageEndpoint = async () => {
    setTestingImageGen(true);
    setImageResult(null);
    try {
      const res = await fetch('/api/test/image-endpoint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: imageEndpoint.trim(),
          imageModel: imageModel || 'beluga',
          mode: 'generate'
        })
      });
      const data = await res.json();
      setImageResult(data);
    } catch (err: any) {
      setImageResult({
        ok: false,
        error: `Failed POST /image test: ${err.message}`
      });
    } finally {
      setTestingImageGen(false);
    }
  };

  const handleTestEdgeBackupTTS = async () => {
    setTestingTTS(true);
    setTtsResult(null);
    try {
      const res = await fetch('/api/test/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voiceId: 'en-US-ChristopherNeural'
        })
      });
      const data = await res.json();
      setTtsResult(data);
    } catch (err: any) {
      setTtsResult({
        ok: false,
        error: `Backup TTS Test failed: ${err.message}`
      });
    } finally {
      setTestingTTS(false);
    }
  };

  const handleSave = () => {
    onSaveSettings({
      geminiApiKey: geminiKey.trim() || undefined,
      geminiModel,
      groqApiKey: groqKey.trim() || undefined,
      imageApiUrl: normalizeDisplayBaseUrl(imageEndpoint),
      imageModel: imageModel || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">API Keys & Provider Settings</h3>
              <p className="text-xs text-slate-400">
                Manage Gemini (Script Analysis), Groq (Voice TTS), and Flow Image API endpoints.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-5">
          {/* Section 1: Gemini API Key & Model (Script Analysis & Verbatim Splitting) */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Gemini API Key (Script Analysis & Splitting)</span>
              </label>
              <span className="text-[10px] text-slate-500 font-mono">GEMINI_API_KEY</span>
            </div>

            <div className="space-y-1">
              <div className="relative">
                <input
                  type={showGeminiKey ? 'text' : 'password'}
                  value={geminiKey}
                  onChange={(e) => {
                    setGeminiKey(e.target.value);
                    setGeminiResult(null);
                  }}
                  placeholder="Leave blank to use default server Gemini key"
                  className="w-full p-2.5 pr-10 rounded-lg bg-slate-900 border border-slate-700/80 focus:border-amber-500 text-xs text-slate-100 outline-none font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowGeminiKey(v => !v)}
                  title={showGeminiKey ? 'Hide key' : 'Show key'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  {showGeminiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                Used strictly for verbatim script splitting and visual scene prompts. Default server key is preconfigured if left blank.
              </p>
            </div>

            {/* Gemini Model Selection */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400">
                Gemini Analysis Model
              </label>
              <select
                value={geminiModel}
                onChange={(e) => {
                  setGeminiModel(e.target.value);
                  setGeminiResult(null);
                }}
                className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700/80 text-xs text-slate-200 outline-none focus:border-amber-500"
              >
                {GEMINI_MODEL_OPTIONS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Test Gemini Button & Result */}
            <div className="pt-1 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <button
                type="button"
                onClick={handleTestGemini}
                disabled={testingGemini}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all disabled:opacity-50 cursor-pointer shrink-0"
              >
                {testingGemini ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                    <span>Testing Gemini API...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Test Gemini Connection</span>
                  </>
                )}
              </button>

              {geminiResult && (
                <div
                  className={`text-xs px-3 py-1.5 rounded-lg border flex items-center gap-2 ${
                    geminiResult.ok
                      ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                      : 'bg-rose-950/60 border-rose-800 text-rose-300'
                  }`}
                >
                  {geminiResult.ok ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>
                        {geminiResult.usedFallback
                          ? `Ready via ${geminiResult.model} fallback (${geminiResult.latencyMs}ms)`
                          : `Valid (${geminiResult.latencyMs}ms) · ${geminiResult.model}`}
                      </span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      <span className="break-words">{geminiResult.error}</span>
                    </>
                  )}
                </div>
              )}
            </div>

            {geminiResult?.warning && (
              <p className="text-[11px] text-amber-300/90 leading-relaxed">
                {geminiResult.warning}
              </p>
            )}
          </div>

          {/* Section 2: Groq API Key (Voice Generation Only — Orpheus TTS) */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Groq API Key (Voice Generation Only — Orpheus TTS)</span>
              </label>
              <span className="text-[10px] text-slate-500 font-mono">canopylabs/orpheus-v1-english</span>
            </div>

            <div className="space-y-1">
              <div className="relative">
                <input
                  type={showGroqKey ? 'text' : 'password'}
                  value={groqKey}
                  onChange={(e) => {
                    setGroqKey(e.target.value);
                    setGroqResult(null);
                  }}
                  placeholder="gsk_... (enter your Groq key for studio Orpheus TTS voices)"
                  className="w-full p-2.5 pr-10 rounded-lg bg-slate-900 border border-slate-700/80 focus:border-amber-500 text-xs text-slate-100 outline-none font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowGroqKey(v => !v)}
                  title={showGroqKey ? 'Hide key' : 'Show key'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  {showGroqKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Used exclusively for Groq Orpheus voiceover synthesis (<code className="text-slate-300">troy, daniel, austin, hannah, diana, autumn</code>) with automatic 200-char chunking and FFmpeg MP3 mastering. Falls back to Edge Neural TTS if left blank.
              </p>
            </div>

            {/* Test Groq Voice & Backup TTS Buttons */}
            <div className="pt-1 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleTestGroqVoice}
                disabled={testingGroq}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all disabled:opacity-50 cursor-pointer"
              >
                {testingGroq ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                    <span>Testing Groq Voice...</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>Test Groq Voice (Orpheus TTS)</span>
                  </>
                )}
              </button>

              {groqResult?.ok && groqResult.audioPreviewUrl && (
                <button
                  type="button"
                  onClick={handlePlayGroqTestAudio}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-700/60 text-xs font-semibold transition-all cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isPlayingTestAudio ? 'Stop Sample' : `Play Sample (${groqResult.durationSec}s)`}</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleTestEdgeBackupTTS}
                disabled={testingTTS}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 text-xs font-medium transition-all disabled:opacity-50 cursor-pointer"
              >
                {testingTTS ? (
                  <>
                    <RotateCw className="w-3 h-3 animate-spin" />
                    <span>Checking Backup...</span>
                  </>
                ) : (
                  <span>Test Backup TTS</span>
                )}
              </button>
            </div>

            {groqResult && (
              <div
                className={`text-xs px-3 py-2.5 rounded-lg border flex items-start gap-2 ${
                  groqResult.ok
                    ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                    : groqResult.requiresTermsAcceptance
                    ? 'bg-amber-950/50 border-amber-700/70 text-amber-200'
                    : 'bg-rose-950/60 border-rose-800 text-rose-300'
                }`}
              >
                {groqResult.ok ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>
                      {groqResult.message || `Groq Orpheus "${groqResult.voice}" active (${groqResult.latencyMs}ms)`}
                    </span>
                  </>
                ) : groqResult.requiresTermsAcceptance ? (
                  <>
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div className="space-y-1.5 min-w-0">
                      <div className="font-semibold text-amber-300">
                        Action Required in Groq Console ({groqResult.keySource === 'custom' ? 'Your Entered Key' : 'Server Environment Key'})
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        Groq blocks <code className="text-amber-200">canopylabs/orpheus-v1-english</code> until your Groq org admin clicks <b>Accept Terms</b> once in the Groq Console—or paste a Groq key whose org already accepted terms.
                      </p>
                      {groqResult.termsUrl && (
                        <div className="flex flex-wrap items-center gap-3 pt-0.5 text-[11px]">
                          <a
                            href={groqResult.termsUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-colors"
                          >
                            Accept Orpheus Terms on Groq ↗
                          </a>
                          <span className="text-emerald-400 font-medium">
                            Built-in Edge Neural TTS is active automatically so your videos still generate voiceovers.
                          </span>
                        </div>
                      )}
                    </div>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div className="space-y-1 min-w-0">
                      <div className="break-words">{groqResult.error}</div>
                    </div>
                  </>
                )}
              </div>
            )}

            {ttsResult && (
              <div
                className={`text-xs px-3 py-1.5 rounded-lg border flex items-center gap-2 ${
                  ttsResult.ok
                    ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                    : 'bg-rose-950/60 border-rose-800 text-rose-300'
                }`}
              >
                {ttsResult.ok ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Backup Edge TTS Active ({ttsResult.latencyMs}ms)</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <span className="truncate max-w-xs">{ttsResult.error}</span>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Section 3: Flow Image Generation Base URL */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-amber-400" />
                <span>Flow Image Generation Base URL</span>
              </label>
              <span className="text-[10px] text-slate-500 font-mono">POST /image · POST /bulk</span>
            </div>

            <input
              type="text"
              value={imageEndpoint}
              onChange={(e) => {
                setImageEndpoint(e.target.value);
                setImageResult(null);
              }}
              placeholder={DEFAULT_BASE_URL}
              className="w-full p-2.5 rounded-lg bg-slate-900 border border-slate-700/80 focus:border-amber-500 text-xs text-slate-100 outline-none font-mono"
            />

            {/* Flow Image Model Selection */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400">
                Flow Image Model (captcha: broker)
              </label>
              <select
                value={imageModel}
                onChange={(e) => {
                  setImageModel(e.target.value);
                  setImageResult(null);
                }}
                className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700/80 text-xs text-slate-200 outline-none focus:border-amber-500"
              >
                <option value="beluga">beluga (Recommended · Reliable)</option>
                <option value="narwhal">narwhal (Experimental)</option>
              </select>
            </div>

            <p className="text-[11px] text-slate-500 leading-relaxed">
              Sends <code className="text-slate-300">ngrok-skip-browser-warning: true</code> and uses <code className="text-slate-300">POST /image</code> for single scenes or <code className="text-slate-300">POST /bulk</code> (concurrency 2) for multi-scene batches. Automatically falls back to local visuals if offline.
            </p>

            {/* Test Image Endpoint Buttons */}
            <div className="pt-1 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleCheckFlowStatus}
                disabled={testingImageStatus || testingImageGen}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all disabled:opacity-50 cursor-pointer"
              >
                {testingImageStatus ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                    <span>Checking /docs...</span>
                  </>
                ) : (
                  <>
                    <Activity className="w-3.5 h-3.5 text-amber-400" />
                    <span>Check Server (/docs)</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleTestImageEndpoint}
                disabled={testingImageGen || testingImageStatus}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all disabled:opacity-50 cursor-pointer"
              >
                {testingImageGen ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                    <span>Testing POST /image...</span>
                  </>
                ) : (
                  <>
                    <Globe className="w-3.5 h-3.5 text-amber-400" />
                    <span>Test POST /image</span>
                  </>
                )}
              </button>
            </div>

            {imageResult && (
              <div
                className={`text-xs px-3 py-2 rounded-lg border flex items-start gap-2 ${
                  imageResult.ok
                    ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                    : 'bg-amber-950/60 border-amber-800 text-amber-300'
                }`}
              >
                {imageResult.ok ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                )}
                <div className="space-y-1 flex-1 min-w-0">
                  <div className="font-medium break-words">
                    {imageResult.ok
                      ? imageResult.message || `Online (${imageResult.latencyMs}ms)`
                      : imageResult.error}
                  </div>
                  {imageResult.statusData && (
                    <div className="text-[11px] text-slate-300 font-mono">
                      Docs: {imageResult.statusData.docsReachable ? 'online' : 'unavailable'} · Endpoints: {(imageResult.statusData.endpoints || ['/image', '/bulk']).join(', ')} · Model: {imageModel}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Live image preview card if test image was generated */}
            {imageResult?.previewUrl && (
              <div className="mt-2 p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center gap-3">
                <img
                  src={imageResult.previewUrl}
                  alt="Flow API Test Preview"
                  className="w-16 h-16 rounded object-cover border border-slate-700"
                />
                <div className="text-xs space-y-0.5">
                  <div className="font-semibold text-slate-200">Live POST /image Received</div>
                  <div className="text-[11px] text-slate-400">
                    Size: {imageResult.imageSizeKb} KB · Type: {imageResult.contentType}
                  </div>
                  {imageResult.jobId && (
                    <div className="text-[10px] text-slate-500 font-mono">
                      Job ID: {imageResult.jobId}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg shadow-md transition-all cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
