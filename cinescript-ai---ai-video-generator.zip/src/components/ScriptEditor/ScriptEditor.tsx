import React from 'react';
import { VisualStyle, VoiceOption, ProjectSettings, SplitGranularity } from '../../types';
import { Volume2, Sparkles, Monitor, Smartphone, Sliders, Globe, Scissors, CheckCircle2 } from 'lucide-react';
import { GEMINI_MODEL_OPTIONS } from '../Settings/SettingsModal';

interface ScriptEditorProps {
  script: string;
  setScript: (s: string) => void;
  settings: ProjectSettings;
  setSettings: (s: ProjectSettings | ((prev: ProjectSettings) => ProjectSettings)) => void;
  voices: VoiceOption[];
  onStartAnalysis: () => void;
  isAnalyzing: boolean;
  onPreviewVoice: (voiceId: string) => void;
  playingVoiceId: string | null;
  onOpenSettings?: () => void;
}

const SAMPLE_SCRIPTS = [
  {
    title: 'The Cosmic Stickman',
    style: 'stickman' as VisualStyle,
    text: `Deep in the quiet void of space, a solitary stickman floated beside a glowing asteroid. With a simple pencil in hand, he drew a rocket ship into existence. He jumped aboard and ignited the starlight thrusters. Passing swirling nebulae and shimmering rings, he reached a distant planet. He planted his black-and-white flag into the neon soil, proving that imagination has no boundaries.`
  },
  {
    title: 'The AI City in 2050',
    style: 'realistic' as VisualStyle,
    text: `By the dawn of 2050, megacities had transformed into living, breathing ecosystems. Autonomous aerial pods glided gracefully between vertical botanical towers. Sunlight filtered through translucent solar glass, illuminating thousands of urban gardens. Beneath the bustling skyline, smart magnetic transit moved millions silently every minute. Humanity and artificial intelligence had finally built harmony with nature.`
  },
  {
    title: 'Kitchen Catastrophe',
    style: 'cartoon' as VisualStyle,
    text: `Chef Oliver was about to bake the greatest pancake the kingdom had ever tasted. He poured three buckets of milk and tossed forty giant eggs into the bubbling pan. Suddenly, the batter started expanding like an angry volcano. The pancake rose to the ceiling, bouncing wildly off the copper pots. Oliver leaped with his trusty spatula, catching the golden pancake right as it landed!`
  }
];

const SPLIT_OPTIONS: { id: SplitGranularity; label: string; hint: string }[] = [
  {
    id: 'very-small',
    label: 'Very Small Parts (4–10 words / micro-clips — Recommended)',
    hint: 'Fast-paced dynamic cuts: splits into tight visual phrases without altering a single word.'
  },
  {
    id: 'small',
    label: 'Small Parts (1 sentence per clip)',
    hint: 'Balanced pacing: keeps each sentence intact as its own visual scene.'
  },
  {
    id: 'standard',
    label: 'Standard Beats (2–3 sentences)',
    hint: 'Longer contemplative beats with fewer scene transitions.'
  }
];

export const ScriptEditor: React.FC<ScriptEditorProps> = ({
  script,
  setScript,
  settings,
  setSettings,
  voices,
  onStartAnalysis,
  isAnalyzing,
  onPreviewVoice,
  playingVoiceId,
  onOpenSettings
}) => {
  const charCount = script.length;
  const wordCount = script.trim() ? script.trim().split(/\s+/).length : 0;
  // Standard speech rate: ~140 words per minute => ~2.33 words per sec
  const estimatedSeconds = Math.max(1, Math.round((wordCount / 140) * 60));

  const currentSplit = settings.splitGranularity || 'very-small';
  const currentGeminiModel = settings.geminiModel || 'gemini-3.1-flash-lite';

  const handleLoadSample = (sample: typeof SAMPLE_SCRIPTS[0]) => {
    setScript(sample.text);
    setSettings(prev => ({ ...prev, style: sample.style }));
  };

  const activeVoice = voices.find(v => v.id === settings.voiceId) || voices[0];

  return (
    <div className="space-y-6">
      {/* Top Banner / Sample Script Selector */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-slate-900/70 border border-slate-800">
        <div>
          <h2 className="text-sm font-semibold text-white">Create New Video Project</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Enter a narrative script or choose a sample. Gemini splits your exact words into visual scenes with smooth auto zoom motion.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-slate-500 font-medium">Load sample:</span>
          {SAMPLE_SCRIPTS.map((sample) => (
            <button
              key={sample.title}
              onClick={() => handleLoadSample(sample)}
              className="text-xs px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors whitespace-nowrap"
            >
              {sample.title}
            </button>
          ))}
        </div>
      </div>

      {/* Script Text Area */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Step 1: Enter Video Script
          </label>
          <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
            <span>{charCount} chars</span>
            <span>·</span>
            <span>{wordCount} words</span>
            <span>·</span>
            <span className="text-amber-400 font-semibold">
              Est. ~{estimatedSeconds}s narration
            </span>
          </div>
        </div>

        <div className="relative">
          <textarea
            value={script}
            onChange={(e) => setScript(e.target.value)}
            placeholder="Type or paste your complete video script here..."
            rows={7}
            className="w-full p-4 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-amber-500/80 focus:ring-1 focus:ring-amber-500/50 text-slate-100 placeholder-slate-600 text-sm leading-relaxed outline-none transition-all resize-y"
          />
        </div>

        {/* Gemini Model & Verbatim Split Granularity Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Gemini Analysis Model</span>
              </label>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-medium">
                <CheckCircle2 className="w-3 h-3" />
                100% Verbatim
              </span>
            </div>
            <select
              value={currentGeminiModel}
              onChange={(e) => setSettings(prev => ({ ...prev, geminiModel: e.target.value }))}
              className="w-full p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:border-amber-500 outline-none"
            >
              {GEMINI_MODEL_OPTIONS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.label}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-400">
              Script text is never rewritten or altered—Gemini strictly segments your exact words.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Scissors className="w-3.5 h-3.5 text-amber-400" />
                <span>Scene Split Granularity</span>
              </label>
              <span className="text-[10px] text-slate-500 font-mono">{currentSplit}</span>
            </div>
            <select
              value={currentSplit}
              onChange={(e) =>
                setSettings(prev => ({ ...prev, splitGranularity: e.target.value as SplitGranularity }))
              }
              className="w-full p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:border-amber-500 outline-none"
            >
              {SPLIT_OPTIONS.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.label}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-400">
              {SPLIT_OPTIONS.find(o => o.id === currentSplit)?.hint}
            </p>
          </div>
        </div>
      </div>

      {/* Grid: Style, Aspect Ratio, Voice Settings */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Step 2: Choose Visual Style */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Step 2: Visual Style
            </label>
          </div>

          <div className="space-y-2.5">
            {/* Stickman Style */}
            <div
              onClick={() => setSettings(prev => ({ ...prev, style: 'stickman' }))}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                settings.style === 'stickman'
                  ? 'bg-slate-800/90 border-amber-400 shadow-md shadow-amber-500/5'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white">Stickman</span>
                {settings.style === 'stickman' && (
                  <span className="text-[11px] font-semibold text-amber-400">Selected</span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Minimalist black outlines, clean background, expressive poses, and consistent stick protagonist across all scenes.
              </p>
            </div>

            {/* Cartoon Style */}
            <div
              onClick={() => setSettings(prev => ({ ...prev, style: 'cartoon' }))}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                settings.style === 'cartoon'
                  ? 'bg-slate-800/90 border-amber-400 shadow-md shadow-amber-500/5'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white">Cartoon</span>
                {settings.style === 'cartoon' && (
                  <span className="text-[11px] font-semibold text-amber-400">Selected</span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Vibrant colors, playful stylized character features, rich cel-shading, and unified character art direction.
              </p>
            </div>

            {/* Realistic Style */}
            <div
              onClick={() => setSettings(prev => ({ ...prev, style: 'realistic' }))}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                settings.style === 'realistic'
                  ? 'bg-slate-800/90 border-amber-400 shadow-md shadow-amber-500/5'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white">Realistic</span>
                {settings.style === 'realistic' && (
                  <span className="text-[11px] font-semibold text-amber-400">Selected</span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Photorealistic cinematic lighting, realistic environments, 35mm composition, and consistent human identities.
              </p>
            </div>
          </div>
        </div>

        {/* Step 3: Choose Aspect Ratio */}
        <div className="space-y-3">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Step 3: Aspect Ratio
          </label>

          <div className="space-y-2.5">
            <div
              onClick={() => setSettings(prev => ({ ...prev, aspectRatio: '16:9' }))}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                settings.aspectRatio === '16:9'
                  ? 'bg-slate-800/90 border-amber-400 shadow-md shadow-amber-500/5'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-3">
                <Monitor className="w-5 h-5 text-amber-400" />
                <div>
                  <div className="text-sm font-bold text-white">Landscape (16:9)</div>
                  <div className="text-xs text-slate-400 mt-0.5">1920 × 1080 · YouTube, Web, TV</div>
                </div>
              </div>
            </div>

            <div
              onClick={() => setSettings(prev => ({ ...prev, aspectRatio: '9:16' }))}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                settings.aspectRatio === '9:16'
                  ? 'bg-slate-800/90 border-amber-400 shadow-md shadow-amber-500/5'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-3">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <div>
                  <div className="text-sm font-bold text-white">Portrait (9:16)</div>
                  <div className="text-xs text-slate-400 mt-0.5">1080 × 1920 · TikTok, Shorts, Reels</div>
                </div>
              </div>
            </div>

            <label className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-950/60 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
              <input
                type="checkbox"
                checked={settings.autoMotion !== false}
                onChange={(e) => setSettings(prev => ({ ...prev, autoMotion: e.target.checked }))}
                className="mt-0.5 accent-amber-400 rounded cursor-pointer"
              />
              <div className="text-xs">
                <div className="font-semibold text-slate-200">Auto Slow-Motion Zoom In / Out</div>
                <div className="text-slate-400 mt-0.5 leading-relaxed">
                  Automatically applies silky slow-motion zoom-in and zoom-out camera motion across scenes.
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* Step 4: Choose Voice (Groq Orpheus TTS + Edge Backup) */}
        <div className="space-y-3">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Step 4: Narration Voice (Groq TTS)
          </label>

          <div className="space-y-2">
            <select
              value={settings.voiceId}
              onChange={(e) => setSettings(prev => ({ ...prev, voiceId: e.target.value }))}
              className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-sm focus:border-amber-500 outline-none"
            >
              {voices.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.displayName} ({v.gender})
                </option>
              ))}
            </select>

            {/* Selected Voice Details & Preview */}
            {activeVoice && (() => {
              const isPlaying = playingVoiceId === activeVoice.id;

              return (
                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>{activeVoice.name}</span>
                        {activeVoice.provider === 'groq' && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 font-medium">
                            Groq Orpheus
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">{activeVoice.language} · {activeVoice.gender}</div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onPreviewVoice(activeVoice.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                        isPlaying
                          ? 'bg-amber-500 text-slate-950 animate-pulse'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                      }`}
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>{isPlaying ? 'Playing...' : 'Preview Voice'}</span>
                    </button>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {activeVoice.description}
                  </p>
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      {/* AI Services & Endpoint Status Strip */}
      <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-slate-300">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">Gemini:</span>
            <span className="font-mono text-slate-200 font-semibold">{currentGeminiModel}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Scissors className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">Split:</span>
            <span className="font-mono text-slate-200 font-semibold">{currentSplit}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Volume2 className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">Voice:</span>
            <span className="font-mono text-slate-200 font-semibold">{activeVoice?.name || settings.voiceId || 'troy'}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">Flow Base:</span>
            <span
              className="font-mono text-slate-200 truncate max-w-[180px]"
              title={(settings.imageApiUrl || 'https://kite-mushily-bling.ngrok-free.dev').replace(/\/generate$/i, '')}
            >
              {(settings.imageApiUrl || 'https://kite-mushily-bling.ngrok-free.dev').replace(/\/generate$/i, '')}
            </span>
          </div>
        </div>

        {onOpenSettings && (
          <button
            type="button"
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-semibold transition-all cursor-pointer self-start md:self-auto shrink-0"
          >
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>API Keys & Tests</span>
          </button>
        )}
      </div>

      {/* Start Processing Action Area */}
      <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-800">
        <div className="text-xs text-slate-400">
          Gemini splits your exact script verbatim without word changes and assigns alternating zoom-in / zoom-out motion.
        </div>

        <button
          onClick={onStartAnalysis}
          disabled={!script.trim() || isAnalyzing}
          className={`flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-sm font-bold shadow-lg transition-all ${
            !script.trim() || isAnalyzing
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 cursor-pointer shadow-amber-500/20'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>{isAnalyzing ? 'Splitting Script with Gemini...' : 'Start Processing (Analyze Script)'}</span>
        </button>
      </div>
    </div>
  );
};
