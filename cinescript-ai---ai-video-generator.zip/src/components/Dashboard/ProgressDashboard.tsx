import React from 'react';
import { GenerationMode, Scene } from '../../types';
import {
  Sparkles,
  Image as ImageIcon,
  Mic,
  RotateCw,
  CheckCircle2,
  AlertCircle,
  Play
} from 'lucide-react';

interface ProgressDashboardProps {
  generationMode: GenerationMode;
  setGenerationMode: (mode: GenerationMode) => void;
  isGenerating: boolean;
  onStartBatchGeneration: () => void;
  onOpenEditor?: () => void;
  scenes: Scene[];
  progress: {
    totalScenes: number;
    completedScenes: number;
    currentSceneIndex: number;
    currentAction: string;
    percentage: number;
  };
}

export const ProgressDashboard: React.FC<ProgressDashboardProps> = ({
  generationMode,
  setGenerationMode,
  isGenerating,
  onStartBatchGeneration,
  onOpenEditor,
  scenes,
  progress
}) => {
  const total = scenes.length;
  const completedImages = scenes.filter(s => s.imageStatus === 'completed').length;
  const completedVoices = scenes.filter(s => s.voiceStatus === 'completed').length;
  const failedScenes = scenes.filter(s => s.imageStatus === 'failed' || s.voiceStatus === 'failed').length;

  return (
    <div className="p-5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-5">
      {/* Step 7: Mode Selector */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Step 7: Choose Generation Mode
          </label>
          <span className="text-xs text-slate-500">Sequential AI Pipeline</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Option A: Images Only */}
          <div
            onClick={() => !isGenerating && setGenerationMode('image-only')}
            className={`p-3 rounded-xl border transition-all cursor-pointer ${
              generationMode === 'image-only'
                ? 'bg-slate-800/90 border-amber-400'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            } ${isGenerating ? 'opacity-60 cursor-not-allowed' : ''}`}
          >
            <div className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-white">Images Only</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Generates scene illustrations. Uses configurable scene duration for timeline.
            </p>
          </div>

          {/* Option B: Voice Only */}
          <div
            onClick={() => !isGenerating && setGenerationMode('voice-only')}
            className={`p-3 rounded-xl border transition-all cursor-pointer ${
              generationMode === 'voice-only'
                ? 'bg-slate-800/90 border-amber-400'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            } ${isGenerating ? 'opacity-60 cursor-not-allowed' : ''}`}
          >
            <div className="flex items-center gap-2">
              <Mic className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-white">Voice Only</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Generates neural narration audio and synchronizes timeline durations.
            </p>
          </div>

          {/* Option C: Both Images and Voice */}
          <div
            onClick={() => !isGenerating && setGenerationMode('both')}
            className={`p-3 rounded-xl border transition-all cursor-pointer ${
              generationMode === 'both'
                ? 'bg-slate-800/90 border-amber-400'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            } ${isGenerating ? 'opacity-60 cursor-not-allowed' : ''}`}
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-white">Both Images & Voice</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Generates full visuals and synced audio sequentially for complete export.
            </p>
          </div>
        </div>
      </div>

      {/* Progress & Generation Trigger Bar */}
      <div className="space-y-3 pt-2 border-t border-slate-800/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-xs font-semibold text-slate-200">
              {isGenerating ? 'Generating Video Assets in Progress...' : 'Ready to Generate'}
            </div>
            <div className="text-xs text-slate-400">
              {progress.currentAction || 'Configure your mode and click Start Generation to run all scenes.'}
            </div>
          </div>

          <button
            onClick={onStartBatchGeneration}
            disabled={isGenerating || total === 0}
            className={`flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold shadow-lg transition-all ${
              isGenerating || total === 0
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer shadow-amber-500/20'
            }`}
          >
            {isGenerating ? (
              <>
                <RotateCw className="w-4 h-4 animate-spin" />
                <span>Generating ({progress.percentage}%)...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>
                  {failedScenes > 0 ? 'Retry / Generate All Scenes' : 'Start Batch Generation'}
                </span>
              </>
            )}
          </button>
        </div>

        {/* Real Progress Bar */}
        <div className="space-y-1.5">
          <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-amber-400 transition-all duration-300"
              style={{ width: `${progress.percentage}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono gap-3 flex-wrap">
            <span>
              Images: <b className="text-slate-200">{completedImages}</b>/{total} · Voices:{' '}
              <b className="text-slate-200">{completedVoices}</b>/{total}
            </span>
            <div className="flex items-center gap-3">
              <span className="text-amber-400 font-bold">{progress.percentage}% Completed</span>
              {onOpenEditor && total > 0 && !isGenerating && (
                <button
                  type="button"
                  onClick={onOpenEditor}
                  className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-amber-500/40 text-amber-300 font-sans font-semibold transition-colors cursor-pointer"
                >
                  Next: Add Music & Edit Video →
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
