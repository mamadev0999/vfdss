import React from 'react';
import { Sliders, Sparkles, Download, Film } from 'lucide-react';

interface HeaderProps {
  activeTab: 'script' | 'storyboard' | 'timeline' | 'preview';
  setActiveTab: (tab: 'script' | 'storyboard' | 'timeline' | 'preview') => void;
  onOpenSettings: () => void;
  onOpenExport: () => void;
  hasScenes: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenSettings,
  onOpenExport,
  hasScenes
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-2 whitespace-nowrap shrink-0">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-amber-500/10">
          <Film className="w-4 h-4 text-white" />
        </div>
        <span className="text-base font-bold tracking-tight text-white">
          CineScript AI
        </span>
      </div>

      {/* Zone 2: 4 concise single-line text navigation links with active state */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('script')}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
            activeTab === 'script'
              ? 'text-white border-amber-400'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          1. Script & Style
        </button>
        <button
          onClick={() => setActiveTab('storyboard')}
          disabled={!hasScenes}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
            !hasScenes
              ? 'text-slate-600 cursor-not-allowed border-transparent'
              : activeTab === 'storyboard'
              ? 'text-white border-amber-400'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          2. Storyboard
        </button>
        <button
          onClick={() => setActiveTab('timeline')}
          disabled={!hasScenes}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
            !hasScenes
              ? 'text-slate-600 cursor-not-allowed border-transparent'
              : activeTab === 'timeline'
              ? 'text-white border-amber-400'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          3. Editor & Music
        </button>
        <button
          onClick={() => setActiveTab('preview')}
          disabled={!hasScenes}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
            !hasScenes
              ? 'text-slate-600 cursor-not-allowed border-transparent'
              : activeTab === 'preview'
              ? 'text-white border-amber-400'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          4. Full Preview
        </button>
      </nav>

      {/* Zone 3: 1 primary action + Settings */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenSettings}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer"
          title="Configure & Test Groq AI, Image API Endpoint, and Voice Engine"
          aria-label="Settings and API Testing"
        >
          <Sliders className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">Test APIs & Settings</span>
        </button>

        <button
          onClick={onOpenExport}
          disabled={!hasScenes}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg shadow-md transition-all whitespace-nowrap shrink-0 ${
            hasScenes
              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer shadow-amber-500/20'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export MP4</span>
        </button>
      </div>
    </header>
  );
};
