import React, { useEffect, useRef, useState } from 'react';
import { ExportResolution, MotionSpeed, Project, SubtitleStyle } from '../../types';
import { MOTION_SPEED_OPTIONS, SUBTITLE_STYLE_PRESETS } from '../../utils/studioStyles';
import {
  ClientRenderProgress,
  ClientRenderResult,
  computeExportTimeline,
  estimateExportSizeMb,
  getResolutionDimensions,
  isClientCpuExportSupported,
  isDirectDiskStreamingSupported,
  isLowRamDevice,
  renderVideoOnClientCpu
} from '../../services/clientRenderService';
import {
  checkPcAndServerHardware,
  PcHardwareProfile
} from '../../services/systemCheckService';
import {
  Download,
  Film,
  RotateCw,
  CheckCircle2,
  AlertCircle,
  X,
  Copy,
  Check,
  ExternalLink,
  RefreshCw,
  Cpu,
  Server,
  Music,
  Captions,
  Maximize2,
  Zap,
  Gauge
} from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project | null;
  onStartRender: (
    resolution: ExportResolution,
    fps: number,
    showCaptions: boolean,
    lowRamMode?: boolean,
    subtitleStyle?: SubtitleStyle,
    motionSpeed?: MotionSpeed
  ) => Promise<void>;
  isRendering?: boolean;
  showCaptions: boolean;
  onToggleCaptions: (next: boolean) => void;
  subtitleStyle: SubtitleStyle;
  onChangeSubtitleStyle: (next: SubtitleStyle) => void;
  autoMotion: boolean;
  motionSpeed: MotionSpeed;
  narrationVolume: number;
  onToggleAutoMotion?: (next: boolean) => void;
  onChangeMotionSpeed?: (next: MotionSpeed) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  project,
  onStartRender,
  isRendering = false,
  showCaptions,
  onToggleCaptions,
  subtitleStyle,
  onChangeSubtitleStyle,
  autoMotion,
  motionSpeed,
  narrationVolume,
  onToggleAutoMotion,
  onChangeMotionSpeed
}) => {
  const clientSupported = isClientCpuExportSupported();
  const detectedLowRam = isLowRamDevice();

  const [lowRamMode, setLowRamMode] = useState<boolean>(true);
  const [resolution, setResolution] = useState<ExportResolution>(detectedLowRam ? '720p' : '1080p');
  const [fps, setFps] = useState<number>(detectedLowRam ? 24 : 30);
  const [engine, setEngine] = useState<'client-cpu' | 'server-ffmpeg'>(
    clientSupported ? 'client-cpu' : 'server-ffmpeg'
  );

  // Server render state
  const [isSubmittingServer, setIsSubmittingServer] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Client PC CPU render state
  const [isClientRendering, setIsClientRendering] = useState(false);
  const [clientProgress, setClientProgress] = useState<ClientRenderProgress | null>(null);
  const [clientResult, setClientResult] = useState<ClientRenderResult | null>(null);
  const [clientError, setClientError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // PC & Website Server Hardware check state
  const [hwProfile, setHwProfile] = useState<PcHardwareProfile | null>(null);
  const [isCheckingHw, setIsCheckingHw] = useState(false);
  const autoAppliedRef = useRef(false);

  const runHardwareCheck = async (applyRecommended = false) => {
    setIsCheckingHw(true);
    try {
      const profile = await checkPcAndServerHardware();
      setHwProfile(profile);
      if (applyRecommended || !autoAppliedRef.current) {
        autoAppliedRef.current = true;
        setEngine(profile.recommendedEngine);
        setResolution(profile.recommendedResolution);
        setFps(profile.recommendedFps);
        setLowRamMode(profile.recommendedLowRamMode);
      }
    } finally {
      setIsCheckingHw(false);
    }
  };

  useEffect(() => {
    if (isOpen && !hwProfile) {
      runHardwareCheck(true);
    }
  }, [isOpen]);

  useEffect(() => {
    return () => {
      if (clientResult?.objectUrl) {
        URL.revokeObjectURL(clientResult.objectUrl);
      }
      abortControllerRef.current?.abort();
    };
  }, []);

  if (!isOpen || !project) return null;

  const dims = getResolutionDimensions(resolution, project.settings.aspectRatio, lowRamMode);
  const dims2k = getResolutionDimensions('2k', project.settings.aspectRatio, lowRamMode);
  const dims1080 = getResolutionDimensions('1080p', project.settings.aspectRatio, lowRamMode);
  const dims720 = getResolutionDimensions('720p', project.settings.aspectRatio, lowRamMode);
  const serverRenderStatus = project.renderStatus;

  const exportTimeline = computeExportTimeline(project.scenes, fps);
  const exactTotalDurationSec = exportTimeline.totalDurationSec;
  const isLongProject = exactTotalDurationSec >= 300 || project.scenes.length >= 40;
  const estSizeMb = estimateExportSizeMb(exactTotalDurationSec, resolution, project.settings.aspectRatio, lowRamMode);
  const canStreamDisk = isDirectDiskStreamingSupported();

  const formatDurationLabel = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const rem = sec % 60;
    if (mins > 0) {
      return `${mins}m ${rem.toFixed(1)}s`;
    }
    return `${rem.toFixed(1)}s`;
  };

  const isCurrentlyRendering =
    engine === 'client-cpu'
      ? isClientRendering
      : isRendering || isSubmittingServer || Boolean(serverRenderStatus?.isRendering);

  const isClientComplete = engine === 'client-cpu' && !isClientRendering && Boolean(clientResult);
  const isServerComplete =
    engine === 'server-ffmpeg' &&
    !isCurrentlyRendering &&
    serverRenderStatus?.progress === 100 &&
    Boolean(serverRenderStatus?.outputFile);

  const isComplete = isClientComplete || isServerComplete;
  const activeError =
    engine === 'client-cpu'
      ? !isClientRendering
        ? clientError
        : null
      : !isCurrentlyRendering
      ? serverRenderStatus?.error || null
      : null;

  const handleExport = async () => {
    if (engine === 'client-cpu') {
      if (clientResult?.objectUrl) {
        URL.revokeObjectURL(clientResult.objectUrl);
      }
      setClientResult(null);
      setClientError(null);

      // For long 5-30+ minute videos, stream straight to disk when File System Access API is allowed
      let writableStream: any = null;
      let targetFileName = `cinescript_${resolution}_${project.id}.mp4`;
      if (canStreamDisk && (isLongProject || estSizeMb >= 180)) {
        try {
          const handle = await (window as any).showSaveFilePicker({
            suggestedName: targetFileName,
            types: [
              {
                description: 'MP4 Video',
                accept: { 'video/mp4': ['.mp4'] }
              }
            ]
          });
          targetFileName = handle.name || targetFileName;
          writableStream = await handle.createWritable();
        } catch (pickerErr: any) {
          if (pickerErr?.name === 'AbortError') {
            return; // User cancelled save dialog cleanly
          }
          // SecurityError inside cross-origin iFrame -> fall back smoothly to PagedMp4Buffer
          writableStream = null;
        }
      }

      setIsClientRendering(true);

      const controller = new AbortController();
      abortControllerRef.current = controller;

      try {
        const res = await renderVideoOnClientCpu(project, {
          resolution,
          fps,
          showCaptions,
          subtitleStyle,
          autoMotion,
          motionSpeed,
          narrationVolume,
          lowRamMode,
          writableStream,
          targetFileName,
          onProgress: (p) => setClientProgress(p),
          signal: controller.signal
        });
        setClientResult(res);
      } catch (err: any) {
        if (err?.message !== 'Export cancelled by user') {
          setClientError(err?.message || 'PC CPU render failed');
        }
      } finally {
        setIsClientRendering(false);
        abortControllerRef.current = null;
      }
      return;
    }

    try {
      setIsSubmittingServer(true);
      await onStartRender(resolution, fps, showCaptions, lowRamMode, subtitleStyle, motionSpeed);
    } catch (e) {
      console.error('Server render error:', e);
    } finally {
      setIsSubmittingServer(false);
    }
  };

  const handleCancelClientRender = () => {
    abortControllerRef.current?.abort();
  };

  const handleDownloadClientBlob = () => {
    if (!clientResult?.objectUrl) return;
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = clientResult.objectUrl;
    a.download = clientResult.fileName || `cinescript_${resolution}_${project.id}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleCopyLink = () => {
    const fullUrl = `${window.location.origin}/api/project/${project.id}/download`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const formatMb = (bytes: number) => `${(bytes / (1024 * 1024)).toFixed(2)} MB`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-5">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Export High-Quality MP4</h3>
              <p className="text-xs text-slate-400">
                {project.scenes.length} scenes · {formatDurationLabel(exactTotalDurationSec)} exact timeline · ~{estSizeMb} MB est.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            disabled={isClientRendering}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors disabled:opacity-40 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Complete State */}
        {isComplete ? (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/80 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  {isClientComplete
                    ? clientResult?.savedDirectlyToDisk
                      ? `Streamed directly to "${clientResult.fileName}" in ${clientResult.elapsedSec}s (${formatMb(clientResult.sizeBytes)})`
                      : `Compiled on PC CPU in ${clientResult?.elapsedSec}s (${formatMb(clientResult?.sizeBytes || 0)})`
                    : `Server MP4 Compiled (${formatDurationLabel(exactTotalDurationSec)})!`}
                </span>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 font-bold shrink-0">
                {isClientComplete
                  ? `${clientResult?.durationSec}s · ${clientResult?.width}×${clientResult?.height} @ ${clientResult?.fps}fps`
                  : `${exactTotalDurationSec.toFixed(1)}s · ${dims.width}×${dims.height} @ ${fps}fps`}
              </span>
            </div>

            {/* Embedded Video Preview */}
            {(!isClientComplete || clientResult?.objectUrl) ? (
              <div className="relative rounded-xl overflow-hidden bg-black border border-slate-800 shadow-2xl flex items-center justify-center">
                <video
                  controls
                  autoPlay
                  playsInline
                  className="w-full max-h-[380px] object-contain"
                  src={
                    isClientComplete
                      ? clientResult?.objectUrl || undefined
                      : `/api/project/${project.id}/download?inline=true&t=${serverRenderStatus?.completedAt || Date.now()}`
                  }
                >
                  Your browser does not support HTML5 MP4 playback.
                </video>
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300">
                Your MP4 was streamed directly to <b>{clientResult?.fileName}</b> on disk so long exports use minimal RAM.
              </div>
            )}

            {/* Download Bar */}
            {isClientComplete ? (
              <div className={`grid grid-cols-1 ${clientResult?.objectUrl ? 'sm:grid-cols-2' : ''} gap-3 pt-1`}>
                {clientResult?.objectUrl && (
                  <button
                    type="button"
                    onClick={handleDownloadClientBlob}
                    className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-lg shadow-emerald-500/25 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 shrink-0" />
                    <span>Download {resolution.toUpperCase()} .mp4</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    if (clientResult?.objectUrl) URL.revokeObjectURL(clientResult.objectUrl);
                    setClientResult(null);
                  }}
                  className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Change Quality / Re-Export</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <a
                    href={`/api/project/${project.id}/download`}
                    download={`cinescript_${resolution}_${project.id}.mp4`}
                    className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-lg shadow-emerald-500/25 transition-all text-center cursor-pointer"
                  >
                    <Download className="w-4 h-4 shrink-0" />
                    <span>Download .mp4</span>
                  </a>

                  <a
                    href={`/api/project/${project.id}/download?inline=true`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all text-center"
                  >
                    <ExternalLink className="w-4 h-4 shrink-0 text-amber-400" />
                    <span>Open in Tab</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all cursor-pointer"
                  >
                    {copiedLink ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Copied Link!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 shrink-0" />
                        <span>Copy MP4 Link</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-400">
                  <span>Export another resolution or switch render engine?</span>
                  <button
                    type="button"
                    onClick={handleExport}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                    <span>Re-Export MP4</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Configuration & Live Rendering State */
          <div className="space-y-4">
            {/* PC CPU & Website Server Hardware Inspector */}
            <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="text-xs font-bold text-white">
                    PC & Website CPU Check
                  </span>
                  {hwProfile && (
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-amber-300 border border-slate-700">
                      {hwProfile.tierLabel}
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  disabled={isCurrentlyRendering || isCheckingHw}
                  onClick={() => runHardwareCheck(true)}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-semibold text-slate-200 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 text-amber-400 ${isCheckingHw ? 'animate-spin' : ''}`} />
                  <span>{isCheckingHw ? 'Checking CPU...' : 'Check PC CPU & Apply Best HQ'}</span>
                </button>
              </div>

              {hwProfile ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-[11px]">
                  <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between font-semibold text-slate-200">
                      <span>Your PC CPU & RAM</span>
                      <span className="font-mono text-emerald-400 tabular-nums">
                        {hwProfile.cpuCores} Cores · {hwProfile.ramGb ? `${hwProfile.ramGb} GB` : 'Auto RAM'}
                      </span>
                    </div>
                    <div className="text-slate-400 truncate">
                      GPU: {hwProfile.gpuRenderer}
                    </div>
                    <div className="text-slate-400 font-mono">
                      Encoder: {hwProfile.hasHardwareEncoder ? 'HW H.264 Fast' : hwProfile.has1080pEncoder ? 'CPU H.264' : 'Server Recommended'} · Max: {hwProfile.has2kEncoder ? '2K' : hwProfile.has1080pEncoder ? '1080p' : 'Server'}
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between font-semibold text-slate-200">
                      <span>Website Server CPU</span>
                      <span className="font-mono text-sky-400 tabular-nums">
                        {hwProfile.serverInfo
                          ? `${hwProfile.serverInfo.cpuCores} Cores · ${hwProfile.serverInfo.freeRamGb}/${hwProfile.serverInfo.totalRamGb} GB`
                          : 'Cloud Ready'}
                      </span>
                    </div>
                    <div className="text-slate-400 truncate">
                      {hwProfile.serverInfo?.cpuModel || 'FFmpeg Server Encoder'}
                    </div>
                    <div className="text-slate-400 font-mono">
                      Pipeline: {hwProfile.serverInfo?.encoder || 'libx264 + AAC'}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-[11px] text-slate-400">
                  Scanning your PC CPU threads, RAM, and WebCodecs H.264 capability...
                </div>
              )}

              {hwProfile && (
                <p className="text-[11px] text-emerald-300/90 leading-snug">
                  Recommended for your PC: <b>{hwProfile.recommendedResolution.toUpperCase()} @ {hwProfile.recommendedFps}fps</b> ({hwProfile.recommendedEngine === 'client-cpu' ? 'Your PC CPU' : 'Server FFmpeg'}) — {hwProfile.summary}
                </p>
              )}
            </div>

            {/* Render Engine Toggle */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                Render Processor
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  disabled={!clientSupported || isCurrentlyRendering}
                  onClick={() => setEngine('client-cpu')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    engine === 'client-cpu'
                      ? 'bg-slate-800 border-amber-400 text-white'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white'
                  } ${!clientSupported ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <div className="flex items-center gap-2 text-xs font-bold">
                    <Cpu className="w-4 h-4 text-amber-400" />
                    <span>Your PC CPU (WebCodecs)</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {clientSupported
                      ? 'Renders locally on your computer CPU at full 1080p / 2K bitrate with instant download.'
                      : 'WebCodecs unavailable in this browser — use Server FFmpeg.'}
                  </p>
                </button>

                <button
                  type="button"
                  disabled={isCurrentlyRendering}
                  onClick={() => setEngine('server-ffmpeg')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    engine === 'server-ffmpeg'
                      ? 'bg-slate-800 border-amber-400 text-white'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2 text-xs font-bold">
                    <Server className="w-4 h-4 text-sky-400" />
                    <span>Server FFmpeg Encoder</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    High-craft libx264 + Lanczos pipeline with shareable server download link.
                  </p>
                </button>
              </div>
            </div>

            {/* 4GB RAM / Low-Budget PC Speed Mode */}
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                  <Zap className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>4GB RAM Fast Mode</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Streams 1 scene at a time in 2 MB chunks for faster, crash-free export on low-budget PCs.
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {!(lowRamMode && resolution === '720p' && fps === 24) && (
                  <button
                    type="button"
                    disabled={isCurrentlyRendering}
                    onClick={() => {
                      setLowRamMode(true);
                      setResolution('720p');
                      setFps(24);
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-semibold text-emerald-300 cursor-pointer"
                  >
                    Apply 4GB Preset (720p · 24fps)
                  </button>
                )}

                <button
                  type="button"
                  disabled={isCurrentlyRendering}
                  onClick={() => setLowRamMode(prev => !prev)}
                  className={`px-3 py-1.5 rounded-lg border text-[11px] font-bold cursor-pointer transition-colors ${
                    lowRamMode
                      ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-300'
                      : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  {lowRamMode ? 'On · Low RAM' : 'Off · Max Bitrate'}
                </button>
              </div>
            </div>

            {/* Quality & Resolution Selector */}
            <div className="space-y-2.5">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                Export Resolution & Quality
              </label>
              <div className="grid grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setResolution('2k')}
                  disabled={isCurrentlyRendering}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer ${
                    resolution === '2k'
                      ? 'bg-slate-800 border-amber-400 text-white shadow-md'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div>2K Ultra HD</div>
                  <div className="text-[10px] font-mono text-amber-400 mt-0.5 tabular-nums">
                    {dims2k.width}×{dims2k.height} · {(dims2k.videoBitrate / 1_000_000).toFixed(1)} Mbps
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setResolution('1080p')}
                  disabled={isCurrentlyRendering}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer ${
                    resolution === '1080p'
                      ? 'bg-slate-800 border-amber-400 text-white shadow-md'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div>1080p Full HD</div>
                  <div className="text-[10px] font-mono text-slate-400 mt-0.5 tabular-nums">
                    {dims1080.width}×{dims1080.height} · {(dims1080.videoBitrate / 1_000_000).toFixed(1)} Mbps
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setResolution('720p')}
                  disabled={isCurrentlyRendering}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer ${
                    resolution === '720p'
                      ? 'bg-slate-800 border-amber-400 text-white shadow-md'
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div>720p Fast HD</div>
                  <div className="text-[10px] font-mono text-emerald-400 mt-0.5 tabular-nums">
                    {dims720.width}×{dims720.height} · {(dims720.videoBitrate / 1_000_000).toFixed(1)} Mbps
                  </div>
                </button>
              </div>
            </div>

            {/* Frame Rate + Audio/Caption Summary */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-slate-400 font-semibold">Frame Rate</div>
                  <div className="font-mono text-slate-200 font-bold mt-0.5 tabular-nums">
                    {fps} FPS · {fps === 24 ? 'Fastest / Low RAM' : 'H.264 / AAC'}
                  </div>
                </div>
                <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                  {[24, 30, 60].map(rate => (
                    <button
                      key={rate}
                      type="button"
                      disabled={isCurrentlyRendering}
                      onClick={() => setFps(rate)}
                      className={`px-2 py-1 rounded text-[11px] font-mono font-bold cursor-pointer ${
                        fps === rate ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {rate}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
                    <Music className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">
                      {project.musicTrack ? project.musicTrack.name : 'Voiceover Only'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 tabular-nums truncate">
                    Voice {Math.round(narrationVolume * 100)}%
                    {project.musicTrack
                      ? ` · Music ${Math.round(project.musicTrack.volume * 100)}%${project.musicTrack.ducking ? ' (Auto-Duck)' : ''}`
                      : ' · Add music in Editor'}
                  </div>
                </div>

                {onToggleAutoMotion && (
                  <button
                    type="button"
                    disabled={isCurrentlyRendering}
                    onClick={() => onToggleAutoMotion(!autoMotion)}
                    title="Toggle slow-motion zoom-in / zoom-out camera motion"
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-[11px] font-semibold cursor-pointer shrink-0 ${
                      autoMotion
                        ? 'bg-slate-800 border-emerald-500/40 text-emerald-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Maximize2 className="w-3 h-3" />
                    <span>{autoMotion ? 'Zoom On' : 'Static'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Subtitles (ON / OFF + Style) & Slow-Motion Zoom Speed */}
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Captions className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">Subtitles in Exported Video</div>
                    <div className="text-[11px] text-slate-400">
                      Turn subtitles ON or OFF and pick your preferred subtitle style.
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-lg border border-slate-800">
                  <button
                    type="button"
                    disabled={isCurrentlyRendering}
                    onClick={() => onToggleCaptions(true)}
                    className={`px-3 py-1 rounded text-[11px] font-bold cursor-pointer transition-colors ${
                      showCaptions
                        ? 'bg-amber-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Subtitles ON
                  </button>
                  <button
                    type="button"
                    disabled={isCurrentlyRendering}
                    onClick={() => onToggleCaptions(false)}
                    className={`px-3 py-1 rounded text-[11px] font-bold cursor-pointer transition-colors ${
                      !showCaptions
                        ? 'bg-rose-500/80 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Subtitles OFF
                  </button>
                </div>
              </div>

              {showCaptions ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {SUBTITLE_STYLE_PRESETS.map(preset => {
                    const active = subtitleStyle === preset.id;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        disabled={isCurrentlyRendering}
                        onClick={() => onChangeSubtitleStyle(preset.id)}
                        className={`p-2 rounded-lg border text-left transition-all cursor-pointer space-y-1 ${
                          active
                            ? 'bg-slate-800 border-amber-400 shadow-sm'
                            : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="h-7 rounded bg-slate-950 flex items-center justify-center px-1.5 overflow-hidden">
                          <span
                            style={{
                              color: preset.textColor,
                              backgroundColor: preset.bgColor || 'transparent',
                              border: preset.borderColor ? `1px solid ${preset.borderColor}` : 'none',
                              padding: preset.bgColor ? '1px 6px' : '0',
                              borderRadius: preset.bgColor ? 4 : 0,
                              fontFamily: preset.fontFamily,
                              fontWeight: preset.fontWeight,
                              fontSize: '10px',
                              letterSpacing: preset.letterSpacing,
                              WebkitTextStroke: preset.strokeColor ? `1px ${preset.strokeColor}` : undefined
                            }}
                            className="truncate"
                          >
                            {preset.uppercase ? 'SAMPLE LINE' : 'Sample Subtitle'}
                          </span>
                        </div>
                        <div className="text-[11px] font-semibold text-slate-200 truncate">
                          {preset.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 text-[11px] text-slate-400">
                  Subtitles are turned <b className="text-rose-300">OFF</b> — your exported MP4 will have clean visuals with no captions.
                </div>
              )}

              {onChangeMotionSpeed && (
                <div className="pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] font-semibold text-slate-300">
                    Slow-Motion Zoom Speed:
                  </span>
                  <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                    {MOTION_SPEED_OPTIONS.map(opt => (
                      <button
                        key={opt.id}
                        type="button"
                        disabled={isCurrentlyRendering || !autoMotion}
                        onClick={() => onChangeMotionSpeed(opt.id)}
                        className={`px-2.5 py-1 rounded text-[11px] font-semibold cursor-pointer disabled:opacity-45 ${
                          motionSpeed === opt.id
                            ? 'bg-emerald-500 text-slate-950 font-bold'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt.shortLabel}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Live Progress Display */}
            {isCurrentlyRendering && (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">
                    {engine === 'client-cpu'
                      ? `Rendering ${resolution.toUpperCase()} MP4 on PC CPU...`
                      : `Compiling ${resolution.toUpperCase()} MP4 on Server...`}
                  </span>
                  <span className="font-mono text-amber-400 font-bold">
                    {engine === 'client-cpu'
                      ? `${clientProgress?.progress || 5}%`
                      : `${serverRenderStatus?.progress || 10}%`}
                  </span>
                </div>

                <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-400 transition-all duration-200"
                    style={{
                      width: `${Math.max(
                        6,
                        engine === 'client-cpu'
                          ? clientProgress?.progress || 6
                          : serverRenderStatus?.progress || 10
                      )}%`
                    }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 gap-3">
                  <span className="truncate">
                    {engine === 'client-cpu'
                      ? clientProgress?.stage || 'Initializing WebCodecs...'
                      : serverRenderStatus?.currentStep || 'Encoding frames...'}
                  </span>
                  <span className="font-mono text-slate-300 shrink-0">
                    {engine === 'client-cpu' && clientProgress
                      ? `${clientProgress.renderFps > 0 ? `${clientProgress.renderFps} fps · ` : ''}${clientProgress.elapsedSec}s`
                      : `${dims.width}×${dims.height}`}
                  </span>
                </div>

                {engine === 'client-cpu' && (
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    <span>{clientProgress?.hardwareMode || 'PC CPU Encoder'}</span>
                    <button
                      type="button"
                      onClick={handleCancelClientRender}
                      className="text-rose-400 hover:text-rose-300 font-semibold cursor-pointer"
                    >
                      Cancel Render
                    </button>
                  </div>
                )}
              </div>
            )}

            {activeError && (
              <div className="p-4 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 text-xs space-y-2">
                <div className="flex items-center gap-2 font-semibold">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>Render Issue Encountered</span>
                </div>
                <p className="text-[11px] text-rose-300/85 leading-relaxed">{activeError}</p>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleExport}
                    className="px-3 py-1.5 rounded-lg bg-rose-800/80 hover:bg-rose-700 text-white text-xs font-semibold cursor-pointer"
                  >
                    Retry Export
                  </button>
                  {engine === 'client-cpu' && (
                    <button
                      type="button"
                      onClick={() => {
                        setClientError(null);
                        setEngine('server-ffmpeg');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer"
                    >
                      Switch to Server FFmpeg
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            disabled={isClientRendering}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-40 cursor-pointer"
          >
            Close
          </button>

          {!isComplete && (
            <button
              onClick={handleExport}
              disabled={isCurrentlyRendering}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold shadow-lg transition-all ${
                isCurrentlyRendering
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer shadow-amber-500/20'
              }`}
            >
              {isCurrentlyRendering ? (
                <>
                  <RotateCw className="w-4 h-4 animate-spin" />
                  <span>
                    Encoding {resolution.toUpperCase()} (
                    {engine === 'client-cpu'
                      ? clientProgress?.progress || 5
                      : serverRenderStatus?.progress || 10}
                    %)...
                  </span>
                </>
              ) : (
                <>
                  {engine === 'client-cpu' ? <Cpu className="w-4 h-4" /> : <Film className="w-4 h-4" />}
                  <span>
                    Export {resolution.toUpperCase()} MP4 ({engine === 'client-cpu' ? 'PC CPU' : 'Server'})
                  </span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
