import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { ScriptEditor } from './components/ScriptEditor/ScriptEditor';
import { SceneList } from './components/Storyboard/SceneList';
import { ProgressDashboard } from './components/Dashboard/ProgressDashboard';
import { SceneTimeline } from './components/Timeline/SceneTimeline';
import { VideoPlayer } from './components/Player/VideoPlayer';
import { ExportModal } from './components/Export/ExportModal';
import { SettingsModal } from './components/Settings/SettingsModal';
import {
  Project,
  ProjectSettings,
  Scene,
  VoiceOption,
  ContinuityProfile,
  MusicPreset,
  MusicTrack,
  ExportResolution,
  MotionSpeed,
  SubtitleStyle
} from './types';
import { Sparkles, AlertCircle, CheckCircle2, Film } from 'lucide-react';

const INITIAL_SCRIPT = `Deep in the quiet void of space, a solitary stickman floated beside a glowing asteroid.
With a simple pencil in hand, he drew a rocket ship into existence.
He jumped aboard and ignited the starlight thrusters.
Passing swirling nebulae and shimmering rings, he reached a distant planet.
He planted his black-and-white flag into the neon soil, proving that imagination has no boundaries.`;

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'script' | 'storyboard' | 'timeline' | 'preview'>('script');
  const [script, setScript] = useState<string>(INITIAL_SCRIPT);
  const [voices, setVoices] = useState<VoiceOption[]>([]);
  const [musicPresets, setMusicPresets] = useState<MusicPreset[]>([]);
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);

  const [settings, setSettings] = useState<ProjectSettings>(() => {
    try {
      const saved = localStorage.getItem('cinescript_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.imageApiUrl) {
          parsed.imageApiUrl =
            parsed.imageApiUrl
              .trim()
              .replace(/\/+$/, '')
              .replace(/\/(docs|image|bulk|generate)$/i, '') || 'https://kite-mushily-bling.ngrok-free.dev';
        }
        if (parsed.imageModel && parsed.imageModel !== 'beluga' && parsed.imageModel !== 'narwhal') {
          parsed.imageModel = 'beluga';
        }
        // Migrate away from old groqModel / legacy default voice
        delete parsed.groqModel;
        if (!parsed.geminiModel) {
          parsed.geminiModel = 'gemini-3.1-flash-lite';
        }
        if (!parsed.splitGranularity) {
          parsed.splitGranularity = 'very-small';
        }
        if (!parsed.voiceId || parsed.voiceId === 'en-US-ChristopherNeural') {
          parsed.voiceId = 'troy';
        }
        if (typeof parsed.autoMotion !== 'boolean') {
          parsed.autoMotion = true;
        }
        if (!parsed.motionSpeed) {
          parsed.motionSpeed = 'slow';
        }
        if (!parsed.subtitleStyle) {
          parsed.subtitleStyle = 'classic-pill';
        }
        if (typeof parsed.narrationVolume !== 'number') {
          parsed.narrationVolume = 1.0;
        }
        return parsed;
      }
    } catch {}
    return {
      style: 'stickman',
      aspectRatio: '16:9',
      voiceId: 'troy',
      generationMode: 'both',
      fps: 30,
      geminiModel: 'gemini-3.1-flash-lite',
      splitGranularity: 'very-small',
      imageApiUrl: 'https://kite-mushily-bling.ngrok-free.dev',
      imageModel: 'beluga',
      autoMotion: true,
      motionSpeed: 'slow',
      showCaptions: true,
      subtitleStyle: 'classic-pill',
      narrationVolume: 1.0
    };
  });

  const [project, setProject] = useState<Project | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSyncingContinuity, setIsSyncingContinuity] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isRendering, setIsRendering] = useState(false);
  const [activeGeneratingSceneId, setActiveGeneratingSceneId] = useState<string | null>(null);
  const [activeAction, setActiveAction] = useState<string | null>(null);

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const audioPreviewRef = useRef<HTMLAudioElement | null>(null);
  const audioPreviewObjectUrlRef = useRef<string | null>(null);

  // Save settings to localStorage on change & sync to active backend project
  const handleUpdateSettings = (newSettings: Partial<ProjectSettings> | ((prev: ProjectSettings) => ProjectSettings)) => {
    setSettings(prev => {
      const updated = typeof newSettings === 'function' ? newSettings(prev) : { ...prev, ...newSettings };
      try {
        localStorage.setItem('cinescript_settings', JSON.stringify(updated));
      } catch {}
      if (project?.id) {
        setProject(p => (p ? { ...p, settings: { ...p.settings, ...updated } } : null));
        fetch(`/api/project/${project.id}/scenes`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ settings: updated })
        }).catch(() => {});
      }
      return updated;
    });
  };

  // Fetch supported neural voices and restore last project on mount
  useEffect(() => {
    async function loadInitialData() {
      try {
        const [voicesRes, presetsRes] = await Promise.all([
          fetch('/api/voices'),
          fetch('/api/music/presets')
        ]);
        if (voicesRes.ok) {
          const data = await voicesRes.json();
          if (data.voices && Array.isArray(data.voices)) {
            setVoices(data.voices);
          }
        }
        if (presetsRes.ok) {
          const pData = await presetsRes.json();
          if (pData.presets && Array.isArray(pData.presets)) {
            setMusicPresets(pData.presets);
          }
        }
      } catch (err) {
        console.warn('Failed to fetch voices/presets:', err);
      }

      // Check for last project in localStorage
      try {
        const lastId = localStorage.getItem('cinescript_last_project_id');
        if (lastId) {
          const pRes = await fetch(`/api/project/${lastId}/scenes`);
          if (pRes.ok) {
            const data = await pRes.json();
            if (data.project && data.project.scenes?.length > 0) {
              setProject(data.project);
              if (data.project.renderStatus?.outputFile) {
                setActiveTab('preview');
              } else {
                setActiveTab('storyboard');
              }
            }
          }
        }
      } catch (e) {
        console.warn('Failed to restore previous project:', e);
      }
    }
    loadInitialData();
  }, []);

  // Poll project status while generation or rendering is active
  useEffect(() => {
    if (!project?.id) return;
    if (!isGenerating && !project.renderStatus?.isRendering) return;

    const interval = setInterval(async () => {
      try {
        const statusRes = await fetch(`/api/project/${project.id}/status`);
        if (statusRes.ok) {
          const statusData = await statusRes.json();

          // If generation finished
          if (isGenerating && !statusData.isGenerating) {
            setIsGenerating(false);
            // Refresh scenes
            const scenesRes = await fetch(`/api/project/${project.id}/scenes`);
            if (scenesRes.ok) {
              const fullProj = await scenesRes.json();
              setProject(fullProj.project);
            }
          }

          // Update project render status and progress
          setProject(prev => {
            if (!prev) return null;
            return {
              ...prev,
              renderStatus: statusData.renderStatus,
              generationProgress: statusData.generationProgress
            };
          });
        }
      } catch (e) {
        console.warn('Error polling status:', e);
      }
    }, 1500);

    return () => clearInterval(interval);
  }, [project?.id, isGenerating, project?.renderStatus?.isRendering]);

  const showNotification = (type: 'success' | 'error' | 'info', text: string) => {
    setNotification({ type, text });
    setTimeout(() => setNotification(null), 6000);
  };

  // Preview Voice Sample (supports Groq Orpheus TTS via groqApiKey + Edge backup)
  const handlePreviewVoice = async (voiceId: string) => {
    if (playingVoiceId === voiceId && audioPreviewRef.current) {
      audioPreviewRef.current.pause();
      setPlayingVoiceId(null);
      return;
    }

    if (audioPreviewRef.current) {
      audioPreviewRef.current.pause();
    }
    if (audioPreviewObjectUrlRef.current) {
      URL.revokeObjectURL(audioPreviewObjectUrlRef.current);
      audioPreviewObjectUrlRef.current = null;
    }

    try {
      setPlayingVoiceId(voiceId);
      const res = await fetch('/api/voices/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voiceId,
          groqApiKey: settings.groqApiKey
        })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Voice preview failed');
      }

      const blob = await res.blob();
      const objUrl = URL.createObjectURL(blob);
      audioPreviewObjectUrlRef.current = objUrl;

      const audio = new Audio(objUrl);
      audioPreviewRef.current = audio;

      const cleanup = () => {
        setPlayingVoiceId(null);
        if (audioPreviewObjectUrlRef.current === objUrl) {
          URL.revokeObjectURL(objUrl);
          audioPreviewObjectUrlRef.current = null;
        }
      };

      audio.onended = cleanup;
      audio.onerror = cleanup;
      await audio.play();
    } catch (e: any) {
      console.warn('Playback error:', e);
      setPlayingVoiceId(null);
      showNotification('error', e?.message || 'Voice preview playback failed');
    }
  };

  // Step 5: Start Gemini Script Analysis & Verbatim Splitting
  const handleStartAnalysis = async () => {
    if (!script.trim()) return;

    try {
      setIsAnalyzing(true);
      showNotification('info', `Splitting script verbatim with Gemini (${settings.geminiModel || 'gemini-3.1-flash-lite'})...`);

      const res = await fetch('/api/script/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          script,
          style: settings.style,
          aspectRatio: settings.aspectRatio,
          voiceId: settings.voiceId,
          geminiApiKey: settings.geminiApiKey,
          geminiModel: settings.geminiModel || 'gemini-3.1-flash-lite',
          splitGranularity: settings.splitGranularity || 'very-small',
          groqApiKey: settings.groqApiKey,
          imageApiUrl: settings.imageApiUrl,
          imageModel: settings.imageModel,
          motionSpeed: settings.motionSpeed || 'slow',
          subtitleStyle: settings.subtitleStyle || 'classic-pill',
          showCaptions: settings.showCaptions !== false,
          autoMotion: settings.autoMotion !== false
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to analyze script');
      }

      const data = await res.json();

      const newProj: Project = {
        id: data.projectId,
        script,
        settings,
        continuityProfile: data.continuityProfile,
        scenes: data.scenes,
        totalDurationSec: data.totalDurationSec,
        totalDurationFrames: Math.round(data.totalDurationSec * settings.fps)
      };

      try {
        localStorage.setItem('cinescript_last_project_id', data.projectId);
      } catch {}

      setProject(newProj);
      setActiveTab('storyboard');
      showNotification(
        'success',
        data.fallbackNote
          ? `Split into ${data.scenes.length} scenes! (${data.fallbackNote})`
          : `Script split into ${data.scenes.length} consistent scenes via ${data.modelUsed}!`
      );
    } catch (err: any) {
      console.error('Analysis error:', err);
      showNotification('error', err.message || 'Script analysis failed');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Step 8: Generate Single Scene Image
  const handleGenerateImage = async (sceneId: string) => {
    if (!project) return;
    try {
      setActiveGeneratingSceneId(sceneId);
      setActiveAction('Generating Image...');

      const res = await fetch(`/api/scenes/${sceneId}/generate-image`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: project.id,
          customApiUrl: settings.imageApiUrl,
          imageModel: settings.imageModel
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to generate image');
      }

      const data = await res.json();

      setProject(prev => {
        if (!prev) return null;
        const updated = prev.scenes.map(s => {
          if (s.id === sceneId) {
            return {
              ...s,
              imageUrl: data.imageUrl,
              imagePath: data.imagePath,
              imageStatus: 'completed' as const
            };
          }
          return s;
        });
        return { ...prev, scenes: updated };
      });

      showNotification('success', `Image generated for ${data.sceneId}! ${data.note ? `(${data.note})` : ''}`);
    } catch (err: any) {
      showNotification('error', `Image failed: ${err.message}`);
    } finally {
      setActiveGeneratingSceneId(null);
      setActiveAction(null);
    }
  };

  // Step 9: Generate Single Scene Voice
  const handleGenerateVoice = async (sceneId: string) => {
    if (!project) return;
    try {
      setActiveGeneratingSceneId(sceneId);
      setActiveAction('Generating Neural Voiceover...');
      const targetScene = project.scenes.find(s => s.id === sceneId);

      const res = await fetch(`/api/scenes/${sceneId}/generate-voice`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: project.id,
          narration: targetScene?.narration,
          voiceId: settings.voiceId || project.settings.voiceId,
          groqApiKey: settings.groqApiKey
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to generate voice');
      }

      const data = await res.json();

      // Refresh full project scenes and updated cumulative timeline
      const scenesRes = await fetch(`/api/project/${project.id}/scenes`);
      if (scenesRes.ok) {
        const full = await scenesRes.json();
        setProject(full.project);
      }

      const engineLabel = data.provider === 'groq' ? 'Groq Orpheus' : 'Edge Neural';
      showNotification('success', `Voice generated for ${sceneId} (${data.durationSec}s · ${engineLabel})!`);
    } catch (err: any) {
      showNotification('error', `Voice failed: ${err.message}`);
    } finally {
      setActiveGeneratingSceneId(null);
      setActiveAction(null);
    }
  };

  // Step 7: Batch Generation (both, image-only, voice-only)
  const handleStartBatchGeneration = async () => {
    if (!project) return;

    try {
      setIsGenerating(true);
      showNotification('info', `Starting sequential generation (${settings.generationMode})...`);

      const res = await fetch('/api/project/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: project.id,
          mode: settings.generationMode,
          imageApiUrl: settings.imageApiUrl,
          imageModel: settings.imageModel,
          groqApiKey: settings.groqApiKey,
          voiceId: settings.voiceId
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to start batch generation');
      }
    } catch (err: any) {
      setIsGenerating(false);
      showNotification('error', err.message || 'Generation failed');
    }
  };

  // Scene Reordering
  const handleReorderScenes = async (fromIndex: number, toIndex: number) => {
    if (!project) return;
    const reordered = [...project.scenes];
    const [moved] = reordered.splice(fromIndex, 1);
    reordered.splice(toIndex, 0, moved);

    // Re-sequence
    const resequenced = reordered.map((s, idx) => ({ ...s, sequence: idx + 1 }));

    // Send to backend
    try {
      const res = await fetch(`/api/project/${project.id}/scenes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenes: resequenced })
      });
      if (res.ok) {
        const data = await res.json();
        setProject(data.project);
      }
    } catch (err) {
      console.warn('Failed to update scene order:', err);
    }
  };

  // Scene Property Update (narration, prompt, duration, title) with backend timeline sync
  const handleUpdateScene = async (sceneId: string, updates: Partial<Scene>) => {
    if (!project) return;

    const updated = project.scenes.map(s => (s.id === sceneId ? { ...s, ...updates } : s));
    setProject(prev => (prev ? { ...prev, scenes: updated } : null));

    try {
      const res = await fetch(`/api/project/${project.id}/scenes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenes: updated })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.project) {
          setProject(data.project);
        }
      }
    } catch {}
  };

  // Background Music Handlers
  const handleSelectMusicPreset = async (presetId: string) => {
    if (!project) return;
    try {
      const res = await fetch(`/api/project/${project.id}/music`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          presetId,
          overrides: {
            narrationVolume: settings.narrationVolume ?? 1.0
          }
        })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to add background music');
      }
      const data = await res.json();
      setProject(data.project);
      showNotification('success', `Added "${data.musicTrack?.name}" to timeline!`);
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to add studio track');
    }
  };

  const handleUploadMusicFile = async (file: File) => {
    if (!project) return;
    try {
      if (file.size > 80 * 1024 * 1024) {
        throw new Error('Audio file must be under 80 MB.');
      }

      const res = await fetch(`/api/project/${project.id}/music/upload`, {
        method: 'POST',
        headers: {
          'Content-Type': file.type || 'application/octet-stream',
          'x-file-name': encodeURIComponent(file.name)
        },
        body: file
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to upload music file');
      }
      const data = await res.json();
      setProject(data.project);
      showNotification('success', `Uploaded "${data.musicTrack?.name}" to timeline!`);
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to upload music track');
    }
  };

  const handleUpdateMusicSettings = async (updates: Partial<MusicTrack>) => {
    if (!project || !project.musicTrack) return;
    setProject(prev =>
      prev && prev.musicTrack
        ? { ...prev, musicTrack: { ...prev.musicTrack, ...updates } }
        : prev
    );
    try {
      await fetch(`/api/project/${project.id}/music`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
    } catch {}
  };

  const handleUpdateNarrationVolume = (vol: number) => {
    const clamped = Math.max(0.01, Math.min(1, Number.isFinite(vol) ? vol : 1.0));
    handleUpdateSettings({ narrationVolume: clamped });
    if (project?.musicTrack) {
      handleUpdateMusicSettings({ narrationVolume: clamped });
    }
  };

  const handleRemoveMusic = async () => {
    if (!project) return;
    try {
      const res = await fetch(`/api/project/${project.id}/music`, { method: 'DELETE' });
      if (res.ok) {
        const data = await res.json();
        setProject(data.project);
        showNotification('info', 'Background music removed.');
      }
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to remove background music');
    }
  };

  // Update Master Continuity Profile (character sheet, environment lock, palette, lighting)
  const handleUpdateContinuity = (updates: Partial<ContinuityProfile>) => {
    if (!project) return;
    const nextProfile: ContinuityProfile = {
      ...(project.continuityProfile || {
        style: project.settings.style,
        mainCharacters: '',
        artDirection: '',
        colorPalette: '',
        lightingStyle: ''
      }),
      ...updates
    };
    setProject(prev => (prev ? { ...prev, continuityProfile: nextProfile } : null));
    fetch(`/api/project/${project.id}/scenes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ continuityProfile: nextProfile })
    }).catch(() => {});
  };

  // Re-unify all scene prompts to match the locked Character & Visual Continuity Bible
  const handleSyncContinuity = async () => {
    if (!project) return;
    try {
      setIsSyncingContinuity(true);
      showNotification('info', 'Synchronizing character & visual continuity across all scene prompts...');
      const res = await fetch(`/api/project/${project.id}/reprompt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          continuityProfile: project.continuityProfile,
          geminiApiKey: settings.geminiApiKey,
          geminiModel: settings.geminiModel || 'gemini-3.1-flash-lite'
        })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to sync continuity prompts');
      }
      const data = await res.json();
      setProject(data.project);
      showNotification('success', 'All scene prompts updated for strict character & scene-to-scene consistency!');
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to sync continuity prompts');
    } finally {
      setIsSyncingContinuity(false);
    }
  };

  // Render MP4 Export (Server FFmpeg)
  const handleStartRender = async (
    resolution: ExportResolution,
    fps: number,
    showCaptionsFlag: boolean,
    lowRamMode = true,
    overrideSubtitleStyle?: SubtitleStyle,
    overrideMotionSpeed?: MotionSpeed
  ) => {
    if (!project) return;

    try {
      setIsRendering(true);
      showNotification('info', `Rendering ${resolution.toUpperCase()} MP4... compiling scenes & audio.`);

      setProject(prev => prev ? ({
        ...prev,
        renderStatus: {
          isRendering: true,
          progress: 10,
          currentStep: 'Preparing assets and initializing video encoder...'
        }
      }) : null);

      const res = await fetch(`/api/project/${project.id}/render`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resolution,
          fps,
          showCaptions: showCaptionsFlag,
          subtitleStyle: overrideSubtitleStyle || subtitleStyle,
          autoMotion,
          motionSpeed: overrideMotionSpeed || motionSpeed,
          narrationVolume,
          musicTrack: project.musicTrack,
          lowRamMode
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Render request failed');
      }

      // Start active poll until render completes
      const projId = project.id;
      const pollTimer = setInterval(async () => {
        try {
          const pollRes = await fetch(`/api/project/${projId}/render-status`);
          if (pollRes.ok) {
            const data = await pollRes.json();
            const rStatus = data.renderStatus;

            setProject(prev => prev ? ({
              ...prev,
              renderStatus: rStatus
            }) : null);

            if (!rStatus.isRendering && rStatus.progress === 100) {
              clearInterval(pollTimer);
              setIsRendering(false);
              showNotification('success', 'MP4 video compiled successfully! Ready for download.');
            } else if (!rStatus.isRendering && rStatus.error) {
              clearInterval(pollTimer);
              setIsRendering(false);
              showNotification('error', `Render failed: ${rStatus.error}`);
            }
          }
        } catch (pollErr) {
          console.warn('Render poll error:', pollErr);
        }
      }, 1000);

    } catch (err: any) {
      setIsRendering(false);
      showNotification('error', err.message || 'Render failed');
      throw err;
    }
  };

  const hasScenes = Boolean(project && project.scenes.length > 0);
  const totalDurationSec = project?.scenes.reduce((acc, s) => acc + s.effectiveDurationSec, 0) || 0;
  const totalDurationFrames = Math.round(totalDurationSec * (project?.settings.fps || 30));
  const showCaptions = settings.showCaptions !== undefined ? settings.showCaptions : true;
  const subtitleStyle: SubtitleStyle =
    settings.subtitleStyle || project?.settings?.subtitleStyle || 'classic-pill';
  const autoMotion =
    project?.settings?.autoMotion !== undefined
      ? project.settings.autoMotion
      : settings.autoMotion !== false;
  const motionSpeed: MotionSpeed =
    settings.motionSpeed || project?.settings?.motionSpeed || 'slow';
  const narrationVolume =
    typeof project?.musicTrack?.narrationVolume === 'number'
      ? project.musicTrack.narrationVolume
      : typeof settings.narrationVolume === 'number'
      ? settings.narrationVolume
      : typeof project?.settings?.narrationVolume === 'number'
      ? project.settings.narrationVolume
      : 1.0;

  return (
    <div className="min-h-screen flex flex-col bg-[#0b0f19] text-slate-100 antialiased">
      {/* Top Bar Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        hasScenes={hasScenes}
      />

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Floating Notification */}
        {notification && (
          <div
            className={`p-4 rounded-xl border flex items-center justify-between shadow-xl transition-all ${
              notification.type === 'success'
                ? 'bg-emerald-950/80 border-emerald-800 text-emerald-200'
                : notification.type === 'error'
                ? 'bg-rose-950/80 border-rose-800 text-rose-200'
                : 'bg-slate-900 border-amber-500/40 text-amber-200'
            }`}
          >
            <div className="flex items-center gap-2.5 text-xs font-medium">
              {notification.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : notification.type === 'error' ? (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              ) : (
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
              )}
              <span>{notification.text}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-slate-400 hover:text-white text-xs ml-4"
            >
              ✕
            </button>
          </div>
        )}

        {/* Tab 1: Script & Style Settings */}
        {activeTab === 'script' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <ScriptEditor
              script={script}
              setScript={setScript}
              settings={settings}
              setSettings={handleUpdateSettings}
              voices={voices}
              onStartAnalysis={handleStartAnalysis}
              isAnalyzing={isAnalyzing}
              onPreviewVoice={handlePreviewVoice}
              playingVoiceId={playingVoiceId}
              onOpenSettings={() => setIsSettingsOpen(true)}
            />
          </div>
        )}

        {/* Tab 2: Storyboard & Generation Progress */}
        {activeTab === 'storyboard' && project && (
          <div className="space-y-6 animate-in fade-in duration-150">
            {/* Generation Progress Dashboard */}
            <ProgressDashboard
              generationMode={settings.generationMode}
              setGenerationMode={(mode) => setSettings(prev => ({ ...prev, generationMode: mode }))}
              isGenerating={isGenerating}
              onStartBatchGeneration={handleStartBatchGeneration}
              onOpenEditor={() => setActiveTab('timeline')}
              scenes={project.scenes}
              progress={
                project.generationProgress || {
                  totalScenes: project.scenes.length,
                  completedScenes: 0,
                  currentSceneIndex: 0,
                  currentAction: 'Ready to generate',
                  percentage: 0
                }
              }
            />

            {/* Editable Scenes Storyboard List */}
            <SceneList
              scenes={project.scenes}
              continuityProfile={project.continuityProfile}
              onUpdateContinuity={handleUpdateContinuity}
              onSyncContinuity={handleSyncContinuity}
              isSyncingContinuity={isSyncingContinuity}
              onUpdateScene={handleUpdateScene}
              onReorderScenes={handleReorderScenes}
              onGenerateImage={handleGenerateImage}
              onGenerateVoice={handleGenerateVoice}
              activeGeneratingSceneId={activeGeneratingSceneId}
              activeAction={activeAction}
            />
          </div>
        )}

        {/* Tab 3: Video Editor, Background Music & Multi-Track Timeline */}
        {activeTab === 'timeline' && project && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <SceneTimeline
              projectId={project.id}
              scenes={project.scenes}
              aspectRatio={project.settings.aspectRatio}
              style={project.settings.style}
              fps={project.settings.fps}
              totalDurationSec={totalDurationSec}
              totalDurationFrames={totalDurationFrames}
              musicTrack={project.musicTrack}
              musicPresets={musicPresets}
              showCaptions={showCaptions}
              subtitleStyle={subtitleStyle}
              autoMotion={autoMotion}
              motionSpeed={motionSpeed}
              narrationVolume={narrationVolume}
              onToggleCaptions={(next) => handleUpdateSettings({ showCaptions: next })}
              onChangeSubtitleStyle={(next) => handleUpdateSettings({ subtitleStyle: next })}
              onToggleAutoMotion={(next) => handleUpdateSettings({ autoMotion: next })}
              onChangeMotionSpeed={(next) => handleUpdateSettings({ motionSpeed: next })}
              onUpdateNarrationVolume={handleUpdateNarrationVolume}
              onSelectMusicPreset={handleSelectMusicPreset}
              onUploadMusicFile={handleUploadMusicFile}
              onUpdateMusicSettings={handleUpdateMusicSettings}
              onRemoveMusic={handleRemoveMusic}
              onUpdateScene={handleUpdateScene}
              onOpenExport={() => setIsExportOpen(true)}
            />
          </div>
        )}

        {/* Tab 4: Full Video Preview */}
        {activeTab === 'preview' && project && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">Full Video Composition Preview</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Synchronized visuals, voice narration, background music mix, and subtitles.
                </p>
              </div>

              <button
                onClick={() => setIsExportOpen(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
              >
                <Film className="w-4 h-4" />
                <span>Export 1080p / 2K MP4</span>
              </button>
            </div>

            <div className="h-[600px]">
              <VideoPlayer
                scenes={project.scenes}
                aspectRatio={project.settings.aspectRatio}
                style={project.settings.style}
                fps={project.settings.fps}
                totalDurationSec={totalDurationSec}
                totalDurationFrames={totalDurationFrames}
                musicTrack={project.musicTrack}
                showCaptions={showCaptions}
                subtitleStyle={subtitleStyle}
                autoMotion={autoMotion}
                motionSpeed={motionSpeed}
                narrationVolume={narrationVolume}
                onToggleCaptions={(next) => handleUpdateSettings({ showCaptions: next })}
                onChangeSubtitleStyle={(next) => handleUpdateSettings({ subtitleStyle: next })}
              />
            </div>
          </div>
        )}
      </main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={(newSettings) => {
          handleUpdateSettings(newSettings);
          showNotification('success', 'Settings updated');
        }}
      />

      {/* Export MP4 Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        project={project}
        onStartRender={handleStartRender}
        isRendering={isRendering}
        showCaptions={showCaptions}
        onToggleCaptions={(next) => handleUpdateSettings({ showCaptions: next })}
        subtitleStyle={subtitleStyle}
        onChangeSubtitleStyle={(next) => handleUpdateSettings({ subtitleStyle: next })}
        autoMotion={autoMotion}
        motionSpeed={motionSpeed}
        narrationVolume={narrationVolume}
        onToggleAutoMotion={(next) => handleUpdateSettings({ autoMotion: next })}
        onChangeMotionSpeed={(next) => handleUpdateSettings({ motionSpeed: next })}
      />

      {/* Footer */}
      <footer className="mt-auto py-6 border-t border-slate-900 text-center text-xs text-slate-500">
        <p>CineScript AI · Powered by React, Remotion, Node.js, and Neural Voice Synthesis</p>
      </footer>
    </div>
  );
};

export default App;
