export type VisualStyle = 'cartoon' | 'stickman' | 'realistic';
export type AspectRatio = '16:9' | '9:16';
export type AnimationStyle =
  | 'auto'
  | 'slow-zoom-in'
  | 'slow-zoom-out'
  | 'zoom-in'
  | 'zoom-out'
  | 'pan-left'
  | 'pan-right'
  | 'static';
export type MotionSpeed = 'ultra-slow' | 'slow' | 'normal';
export type SubtitleStyle =
  | 'classic-pill'
  | 'youtube-bold'
  | 'cinematic-clean'
  | 'neon-glow'
  | 'paper-light'
  | 'minimal-shadow';
export type SplitGranularity = 'very-small' | 'small' | 'standard';
export type GenerationMode = 'both' | 'image-only' | 'voice-only';
export type SceneStatus = 'pending' | 'processing' | 'completed' | 'failed';
export type ExportResolution = '2k' | '1080p' | '720p';

export interface MusicPreset {
  id: string;
  name: string;
  mood: string;
  bpm: number;
  durationSec: number;
  audioUrl: string;
}

export interface MusicTrack {
  id: string;
  name: string;
  source: 'upload' | 'preset';
  presetId?: string;
  filePath?: string;
  audioUrl: string;
  durationSec: number;
  volume: number;          // 0.0 - 1.0
  narrationVolume: number; // 0.0 - 1.5
  fadeInSec: number;
  fadeOutSec: number;
  loop: boolean;
  ducking: boolean;
  startOffsetSec: number;
}

export interface Scene {
  id: string;
  sequence: number;
  title: string;
  summary: string;
  narration: string;
  visualDescription: string;
  imagePrompt: string;
  negativePrompt?: string;
  characterDescriptions?: string;
  environment?: string;
  cameraAngle?: string;
  lighting?: string;
  continuityNotes?: string;
  suggestedTransition?: string;
  animationStyle: AnimationStyle;
  
  // Media assets
  imagePath?: string;
  imageUrl?: string;
  audioPath?: string;
  audioUrl?: string;
  
  // Timing
  audioDurationSec: number;
  customDurationSec?: number;
  effectiveDurationSec: number;
  startFrame: number;
  durationInFrames: number;
  
  // Statuses
  imageStatus: SceneStatus;
  voiceStatus: SceneStatus;
  errorMessage?: string;
}

export interface VoiceOption {
  id: string;
  name: string;
  displayName: string;
  language: string;
  gender: 'Male' | 'Female';
  provider?: 'groq' | 'edge';
  description: string;
  sampleText: string;
}

export interface ContinuityProfile {
  style: VisualStyle;
  mainCharacters: string;
  artDirection: string;
  colorPalette: string;
  lightingStyle: string;
  environmentLock?: string;
  consistencyRules?: string;
}

export interface ProjectSettings {
  style: VisualStyle;
  aspectRatio: AspectRatio;
  voiceId: string;
  generationMode: GenerationMode;
  fps: number;
  autoMotion?: boolean;
  motionSpeed?: MotionSpeed;
  narrationVolume?: number;
  showCaptions?: boolean;
  subtitleStyle?: SubtitleStyle;
  geminiApiKey?: string;
  geminiModel?: string;
  splitGranularity?: SplitGranularity;
  groqApiKey?: string;
  imageApiUrl?: string;
  imageModel?: string;
  ttsApiKey?: string;
}

export interface Project {
  id: string;
  script: string;
  settings: ProjectSettings;
  continuityProfile?: ContinuityProfile;
  musicTrack?: MusicTrack | null;
  scenes: Scene[];
  totalDurationSec: number;
  totalDurationFrames: number;
  generationProgress?: {
    totalScenes: number;
    completedScenes: number;
    currentSceneIndex: number;
    currentAction: string;
    percentage: number;
  };
  renderStatus?: {
    isRendering: boolean;
    progress: number;
    currentStep: string;
    outputFile?: string;
    outputUrl?: string;
    error?: string;
    completedAt?: number;
  };
}
