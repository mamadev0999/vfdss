import { AnimationStyle, MotionSpeed, Scene, SubtitleStyle } from '../types';

export interface SubtitleStylePreset {
  id: SubtitleStyle;
  name: string;
  tagline: string;
  textColor: string;
  bgColor: string | null;
  borderColor: string | null;
  strokeColor: string | null;
  strokeWidthFactor: number;
  fontFamily: string;
  fontWeight: number;
  uppercase: boolean;
  letterSpacing: string;
  glowShadow: string | null;
}

export const SUBTITLE_STYLE_PRESETS: SubtitleStylePreset[] = [
  {
    id: 'classic-pill',
    name: 'Classic Dark Pill',
    tagline: 'Clean white text on translucent dark box',
    textColor: '#ffffff',
    bgColor: 'rgba(9, 13, 22, 0.78)',
    borderColor: 'rgba(255, 255, 255, 0.16)',
    strokeColor: null,
    strokeWidthFactor: 0,
    fontFamily: '"Plus Jakarta Sans", system-ui, -apple-system, sans-serif',
    fontWeight: 600,
    uppercase: false,
    letterSpacing: '0px',
    glowShadow: '0 8px 30px rgba(0, 0, 0, 0.55)'
  },
  {
    id: 'youtube-bold',
    name: 'Creator Pop Gold',
    tagline: 'Bold gold uppercase with crisp black outline',
    textColor: '#facc15',
    bgColor: null,
    borderColor: null,
    strokeColor: '#020617',
    strokeWidthFactor: 0.14,
    fontFamily: '"Plus Jakarta Sans", system-ui, -apple-system, sans-serif',
    fontWeight: 800,
    uppercase: true,
    letterSpacing: '0.6px',
    glowShadow: '0 4px 10px rgba(0, 0, 0, 0.95)'
  },
  {
    id: 'cinematic-clean',
    name: 'Cinema Serif',
    tagline: 'Film-grade ivory serif without background box',
    textColor: '#f8fafc',
    bgColor: null,
    borderColor: null,
    strokeColor: 'rgba(2, 6, 23, 0.9)',
    strokeWidthFactor: 0.08,
    fontFamily: 'Georgia, "DejaVu Serif", serif',
    fontWeight: 600,
    uppercase: false,
    letterSpacing: '0.4px',
    glowShadow: '0 3px 12px rgba(0, 0, 0, 0.95)'
  },
  {
    id: 'neon-glow',
    name: 'Neon Cyber',
    tagline: 'Electric sky-blue border on deep navy bar',
    textColor: '#e0f2fe',
    bgColor: 'rgba(8, 20, 38, 0.86)',
    borderColor: '#38bdf8',
    strokeColor: null,
    strokeWidthFactor: 0,
    fontFamily: '"Plus Jakarta Sans", system-ui, -apple-system, sans-serif',
    fontWeight: 700,
    uppercase: false,
    letterSpacing: '0.2px',
    glowShadow: '0 0 22px rgba(56, 189, 248, 0.45)'
  },
  {
    id: 'paper-light',
    name: 'Paper Light Card',
    tagline: 'High-contrast dark ink on crisp white card',
    textColor: '#0f172a',
    bgColor: 'rgba(255, 255, 255, 0.93)',
    borderColor: 'rgba(15, 23, 42, 0.16)',
    strokeColor: null,
    strokeWidthFactor: 0,
    fontFamily: '"Plus Jakarta Sans", system-ui, -apple-system, sans-serif',
    fontWeight: 700,
    uppercase: false,
    letterSpacing: '0px',
    glowShadow: '0 8px 24px rgba(0, 0, 0, 0.35)'
  },
  {
    id: 'minimal-shadow',
    name: 'Minimal Clean',
    tagline: 'Subtle clean white text with soft drop shadow',
    textColor: '#ffffff',
    bgColor: null,
    borderColor: null,
    strokeColor: 'rgba(0, 0, 0, 0.85)',
    strokeWidthFactor: 0.09,
    fontFamily: '"Plus Jakarta Sans", system-ui, -apple-system, sans-serif',
    fontWeight: 600,
    uppercase: false,
    letterSpacing: '0.1px',
    glowShadow: '0 3px 10px rgba(0, 0, 0, 0.92)'
  }
];

export function getSubtitleStylePreset(style?: SubtitleStyle): SubtitleStylePreset {
  return SUBTITLE_STYLE_PRESETS.find(s => s.id === style) || SUBTITLE_STYLE_PRESETS[0];
}

export const MOTION_SPEED_OPTIONS: Array<{
  id: MotionSpeed;
  label: string;
  shortLabel: string;
  zoomDelta: number;
  panDelta: number;
  description: string;
}> = [
  {
    id: 'ultra-slow',
    label: 'Ultra-Slow Drift (4.5%)',
    shortLabel: 'Ultra-Slow',
    zoomDelta: 0.045,
    panDelta: 0.015,
    description: 'Whisper-smooth slow-motion drift'
  },
  {
    id: 'slow',
    label: 'Slow-Mo Zoom (7.5%)',
    shortLabel: 'Slow-Mo',
    zoomDelta: 0.075,
    panDelta: 0.022,
    description: 'Smooth cinematic slow-motion zoom in & out'
  },
  {
    id: 'normal',
    label: 'Dynamic Zoom (13%)',
    shortLabel: 'Dynamic',
    zoomDelta: 0.13,
    panDelta: 0.036,
    description: 'Energetic zoom & pan motion'
  }
];

export function resolveMotionConfig(
  scene: Scene,
  autoMotion: boolean,
  motionSpeed: MotionSpeed = 'slow'
): {
  motion: Exclude<AnimationStyle, 'auto'>;
  zoomDelta: number;
  panDelta: number;
} {
  if (!autoMotion) {
    return { motion: 'static', zoomDelta: 0, panDelta: 0 };
  }

  const rawStyle = scene.animationStyle || 'auto';
  const motion: Exclude<AnimationStyle, 'auto'> =
    rawStyle === 'auto'
      ? scene.sequence % 2 === 1
        ? 'slow-zoom-in'
        : 'slow-zoom-out'
      : rawStyle;

  if (motion === 'static') {
    return { motion: 'static', zoomDelta: 0, panDelta: 0 };
  }

  if (motion === 'slow-zoom-in' || motion === 'slow-zoom-out') {
    const speedDelta = motionSpeed === 'ultra-slow' ? 0.045 : 0.065;
    return { motion, zoomDelta: speedDelta, panDelta: 0.018 };
  }

  const speedPreset =
    MOTION_SPEED_OPTIONS.find(o => o.id === motionSpeed) || MOTION_SPEED_OPTIONS[1];
  return {
    motion,
    zoomDelta: speedPreset.zoomDelta,
    panDelta: speedPreset.panDelta
  };
}
