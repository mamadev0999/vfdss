# CineScript AI — AI-Powered Video Generator

A complete, production-grade AI-powered video creation web application built with **React.js, Node.js, Express, Remotion, and FFmpeg**.

Enter a narrative script, choose a visual style (Cartoon, Stickman, or Realistic), pick an aspect ratio (16:9 Landscape or 9:16 Portrait) and a neural voiceover, and CineScript AI will analyze the script using Groq AI, break it down into emotionally resonant scenes, generate scene visuals and narration, and compile everything into a downloadable high-quality MP4 video with Ken Burns zoom/pan animations.

---

## Features

1. **AI Script Analysis & Scene Breakdown (Groq API)**
   - Analyzes narrative arc, emotional tone, character continuity, camera angles, and transitions.
   - Preserves 100% of original narration.
   - Generates independent, style-consistent image generation prompts and negative prompts.
   - Smart offline heuristic fallback if no API key is provided.

2. **Visual Consistency & Styles**
   - **Stickman**: Minimalist black ink on textured paper with consistent proportions, props, and expressive poses.
   - **Cartoon**: Vibrant, saturated cel-shaded animation style with unified character color palette.
   - **Realistic**: 35mm cinematic lighting, photorealistic textures, and consistent facial identity.

3. **Neural Voiceover & Millisecond Duration Sync**
   - Natural speech synthesis powered by Edge Neural TTS (Christopher, Guy, Jenny, Aria, Sonia, Ryan, Natasha).
   - Exact audio duration measured using FFmpeg/ffprobe.
   - Zero-drift cumulative timeline calculation ensuring images stay perfectly synced with their voice narration.

4. **Remotion Video Composition & Preview**
   - Live interactive Remotion Player in the browser with play/pause, scrubbing, and scene jump markers.
   - Smooth Ken Burns zoom-in (1.0 → 1.12), zoom-out (1.12 → 1.0), and slow pan animations.
   - Clean cinematic subtitle overlay.

5. **MP4 Video Export & Download**
   - Direct high-quality MP4 compilation using FFmpeg & Remotion pipeline.
   - H.264 video codec and AAC audio codec at 30 FPS.
   - Instant download button upon render completion.

6. **Temporary File Management (No Database)**
   - In-memory project tracking with isolated working folders (`project-temp/:projectId/`).
   - Safe cleanup of abandoned temporary projects older than 4 hours without interrupting active renders.

---

## Technology Stack

- **Frontend**: React 19, Vite, Tailwind CSS v4, Lucide Icons
- **Backend**: Node.js, Express.js (mounted via Vite middleware in dev)
- **Video Composition**: Remotion 4.x (`remotion`, `@remotion/player`)
- **Video & Audio Processing**: FFmpeg & FFprobe
- **AI Narrative Analysis**: Groq API (`llama-3.3-70b-versatile`, `llama-3.1-8b-instant`)
- **Speech Synthesis (TTS)**: Edge Neural TTS (`msedge-tts`)
- **Image Generation Endpoint**: Configurable via `IMAGE_API_URL` (default: `https://kite-mushily-bling.ngrok-free.dev`, 3-step Flow Jobs API)

---

## Installation & Setup

### 1. Prerequisites
- Node.js >= 18
- FFmpeg installed on system (`ffmpeg` and `ffprobe` in PATH)

### 2. Install Dependencies
```bash
npm install
```

### 3. Environment Configuration
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Edit `.env` with your preferred configuration:
```env
# Optional: Groq API key for script analysis
GROQ_API_KEY="gsk_your_groq_api_key_here"

# Flow Image API base URL
IMAGE_API_URL="https://kite-mushily-bling.ngrok-free.dev"

# Port (default 3000)
PORT=3000
```

*Note: You can also configure your Groq API Key and Image Endpoint directly in the application UI via the Settings icon (top right).*

### 4. Run Development Server
```bash
npm run dev
```
Open `http://localhost:3000` in your browser.

### 5. Build for Production
```bash
npm run build
npm start
```

---

## User Workflow Guide

1. **Step 1: Enter Video Script**
   - Type or paste your script in the editor, or click one of the pre-loaded sample scripts (**"The Cosmic Stickman"**, **"The AI City in 2050"**, or **"Kitchen Catastrophe"**).
   - Review the character count, word count, and estimated narration duration.

2. **Step 2: Choose Visual Style**
   - Select **Stickman**, **Cartoon**, or **Realistic**.

3. **Step 3: Choose Aspect Ratio**
   - Select **Landscape (16:9)** for YouTube/Web or **Portrait (9:16)** for TikTok/Shorts.

4. **Step 4: Choose Narration Voice**
   - Choose a voice and click **"Preview Voice"** to hear a sample.

5. **Step 5: Start Processing**
   - Click **"Start Processing (Analyze Script)"**. Groq AI splits the script into structured scenes with detailed visual prompts and camera angles.

6. **Step 6 & 7: Storyboard & Generation**
   - Edit scene titles, prompts, narration, or animations as desired.
   - Choose generation mode: **Both Images & Voice**, **Images Only**, or **Voice Only**.
   - Click **"Start Batch Generation"** or generate/regenerate individual scenes.

7. **Step 8: Remotion Preview**
   - Switch to the **Remotion Preview** tab. Play the video, scrub across scenes, and preview the dynamic zoom animations and synced narration.

8. **Step 9: Export & Download MP4**
   - Click **"Export MP4"**, choose your resolution (1080p or 720p), and click **"Start MP4 Export"**.
   - When rendering completes, click **"Download MP4 Video"** to save your video.

---

## Troubleshooting

- **Image Endpoint Returns 404 / ERR_NGROK_3200**:
  - The default ngrok development endpoint `kite-mushily-bling.ngrok-free.dev` is hosted on a remote developer machine that may go offline or sleep.
  - CineScript AI automatically catches offline errors and produces high-resolution stylized visuals matching your selected style and aspect ratio so the entire pipeline continues to work seamlessly.
  - You can update the Image API URL at any time in the Settings dialog and click **"Regenerate Image"** on any scene.

- **Audio Generation**:
  - Edge Neural TTS requires outgoing internet access to Azure Edge Speech. If running in an offline sandbox, durations automatically fall back to user-configured timing.

- **FFmpeg Output**:
  - Rendered MP4 files are saved in `project-temp/:projectId/output/final-video.mp4` and streamed via `/api/project/:projectId/download`.
