import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { fileURLToPath } from 'url';
import { projectManager } from './server/services/projectManager.js';
import {
  analyzeScriptWithGemini,
  syncContinuityPromptsWithGemini,
  testGeminiConnection,
  GEMINI_MODELS
} from './server/services/geminiService.js';
import {
  generateSceneImage,
  checkFlowApiStatus,
  runFlowImageJob,
  runFlowBulkImageJobs,
  buildConsistentFlowPrompt,
  saveRawImageAsPng,
  normalizeImageBaseUrl
} from './server/services/imageService.js';
import {
  generateSpeechAudio,
  SUPPORTED_VOICES,
  generateVoicePreview,
  testGroqTts
} from './server/services/audioService.js';
import { calculateTimeline } from './server/services/timelineService.js';
import { renderProjectToMp4 } from './server/services/renderService.js';
import {
  listMusicPresets,
  ensurePresetAudioFile,
  assignPresetMusicToProject,
  saveUploadedMusicToProject
} from './server/services/musicService.js';
import { GenerationMode, Scene } from './server/types.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// Runtime Environment requires dev server to run on port 3000 (nginx listens on 8080)
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

// List supported voices and Gemini models
app.get('/api/voices', (req, res) => {
  res.json({ voices: SUPPORTED_VOICES, geminiModels: GEMINI_MODELS });
});

// Website Server Hardware Info (CPU model, logical cores, RAM capacity) for Export Diagnostics
app.get('/api/system/info', (_req, res) => {
  const cpus = os.cpus();
  const totalRamBytes = os.totalmem();
  const freeRamBytes = os.freemem();
  res.json({
    cpuModel: cpus?.[0]?.model?.trim() || 'Server CPU',
    cpuCores: cpus?.length || 2,
    totalRamGb: Number((totalRamBytes / (1024 * 1024 * 1024)).toFixed(1)),
    freeRamGb: Number((freeRamBytes / (1024 * 1024 * 1024)).toFixed(1)),
    platform: os.platform(),
    arch: os.arch(),
    encoder: 'FFmpeg libx264 + AAC'
  });
});

// Stream sample voice preview audio (GET fallback & POST with optional groqApiKey)
app.get('/api/voices/preview', async (req, res) => {
  const voiceId = (req.query.voiceId as string) || 'troy';
  try {
    const buffer = await generateVoicePreview(voiceId);
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (err: any) {
    console.error('[API GET /api/voices/preview] Error:', err);
    res.status(500).json({ error: err.message || 'Failed to generate voice preview' });
  }
});

app.post('/api/voices/preview', async (req, res) => {
  const { voiceId = 'troy', groqApiKey } = req.body || {};
  try {
    const buffer = await generateVoicePreview(voiceId, groqApiKey);
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (err: any) {
    console.error('[API POST /api/voices/preview] Error:', err);
    res.status(500).json({ error: err.message || 'Failed to generate voice preview' });
  }
});

// Test Gemini API Key and Model validity (used exclusively for Script Analysis & Splitting)
app.post('/api/test/gemini', async (req, res) => {
  const { apiKey, model = 'gemini-3.1-flash-lite' } = req.body || {};
  const result = await testGeminiConnection({ apiKey, model });
  return res.status(200).json({
    ...result,
    message: result.ok
      ? result.usedFallback
        ? `Ready via auto-fallback: ${result.model} (${result.requestedModel} had 503 spike)`
        : `Gemini (${result.model}) connected!`
      : undefined
  });
});

// Test Groq API Key strictly for Voice Generation (Orpheus TTS)
app.post('/api/test/groq', async (req, res) => {
  const { apiKey, voiceId = 'troy' } = req.body || {};
  const result = await testGroqTts({ apiKey, voiceId });
  return res.status(200).json({
    ...result,
    message: result.ok
      ? `Groq Voice (${result.voice}) active! Generated ${result.durationSec}s audio.`
      : undefined
  });
});

// Test Image Generation Endpoint URL (Flow Simple API: GET /docs + POST /image + POST /bulk)
app.post('/api/test/image-endpoint', async (req, res) => {
  const { url: rawUrl, imageModel, mode = 'generate' } = req.body;
  const baseUrl = normalizeImageBaseUrl(rawUrl);

  if (!baseUrl) {
    return res.status(200).json({ ok: false, error: 'Endpoint Base URL cannot be empty' });
  }

  // Step A: Verify <baseUrl>/docs is reachable
  const statusCheck = await checkFlowApiStatus(baseUrl);

  if (mode === 'status') {
    return res.json({
      ok: statusCheck.ok,
      status: statusCheck.httpStatus,
      baseUrl: statusCheck.baseUrl,
      latencyMs: statusCheck.latencyMs,
      statusData: statusCheck.data,
      error: statusCheck.error,
      message: statusCheck.ok
        ? `Flow Image Server online at ${statusCheck.baseUrl} (/image & /bulk ready, ${statusCheck.latencyMs}ms)`
        : statusCheck.error
    });
  }

  if (!statusCheck.ok) {
    return res.json({
      ok: false,
      status: statusCheck.httpStatus,
      baseUrl: statusCheck.baseUrl,
      latencyMs: statusCheck.latencyMs,
      error: statusCheck.error
    });
  }

  // Step B: Run live POST /image generation test
  try {
    const result = await runFlowImageJob({
      prompt: 'a stickman waving hello, minimal doodle style',
      aspectRatio: '1:1',
      imageModel: imageModel || 'beluga',
      captcha: 'broker',
      customApiUrl: baseUrl,
      maxTotalWaitMs: 180000
    });

    const base64Preview = `data:${result.contentType};base64,${result.buffer.toString('base64')}`;
    const sizeKb = Math.round(result.buffer.byteLength / 1024);

    return res.json({
      ok: true,
      status: 200,
      baseUrl: result.baseUrl,
      jobId: result.jobId,
      model: result.model,
      contentType: result.contentType,
      latencyMs: result.latencyMs,
      imageSizeKb: sizeKb,
      previewUrl: base64Preview,
      statusData: statusCheck.data,
      message: `Flow POST /image Verified (${result.model})! Generated ${sizeKb} KB in ${(result.latencyMs / 1000).toFixed(1)}s.`
    });
  } catch (err: any) {
    return res.json({
      ok: false,
      baseUrl: statusCheck.baseUrl,
      statusData: statusCheck.data,
      latencyMs: statusCheck.latencyMs,
      error: err.message || 'Flow POST /image failed'
    });
  }
});

// Test TTS Engine validity (tests active TTS pipeline: Groq Orpheus if key is valid, Edge Neural fallback otherwise)
app.post('/api/test/tts', async (req, res) => {
  const { voiceId = 'troy', groqApiKey } = req.body || {};
  const startTime = Date.now();
  try {
    const tmpDir = path.join('/tmp', 'tts_test');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
    const fileName = `test_ping_${Date.now()}.mp3`;
    const { audioPath, durationSec, provider, fallbackNote } = await generateSpeechAudio(
      'Hello! Voice synthesis is ready.',
      voiceId,
      tmpDir,
      fileName,
      groqApiKey
    );
    try { fs.unlinkSync(audioPath); } catch {}
    const latencyMs = Date.now() - startTime;
    return res.json({
      ok: true,
      voiceId,
      provider,
      fallbackNote,
      durationSec,
      latencyMs,
      message: `TTS Engine (${provider === 'groq' ? 'Groq Orpheus' : 'Edge Neural'}) working! Generated in ${latencyMs}ms.`
    });
  } catch (err: any) {
    const latencyMs = Date.now() - startTime;
    return res.json({
      ok: false,
      latencyMs,
      error: `TTS error: ${err.message || 'Unable to generate speech audio'}`
    });
  }
});

// Step 1 & 5: Analyze and split script using Gemini API (preserving 100% verbatim text)
app.post('/api/script/analyze', async (req, res) => {
  try {
    const {
      script,
      style = 'stickman',
      aspectRatio = '16:9',
      voiceId = 'troy',
      geminiApiKey,
      geminiModel = 'gemini-3.1-flash-lite',
      splitGranularity = 'very-small',
      groqApiKey,
      imageApiUrl,
      imageModel,
      motionSpeed = 'slow',
      subtitleStyle = 'classic-pill',
      showCaptions = true,
      autoMotion = true
    } = req.body;

    if (!script || !script.trim()) {
      return res.status(400).json({ error: 'Script text is required' });
    }

    // Create a new project instance
    const project = projectManager.createProject(script, {
      style,
      aspectRatio,
      voiceId,
      geminiApiKey,
      geminiModel,
      splitGranularity,
      groqApiKey,
      imageApiUrl,
      imageModel,
      motionSpeed,
      subtitleStyle,
      showCaptions,
      autoMotion
    });

    projectManager.updateProject(project.id, { isAnalyzing: true });

    try {
      const analysis = await analyzeScriptWithGemini({
        script,
        style,
        aspectRatio,
        geminiApiKey: geminiApiKey || project.settings.geminiApiKey,
        geminiModel: geminiModel || project.settings.geminiModel,
        splitGranularity: splitGranularity || project.settings.splitGranularity
      });

      const { scenes } = calculateTimeline(analysis.scenes, project.settings.fps);

      const updated = projectManager.updateProject(project.id, {
        isAnalyzing: false,
        continuityProfile: analysis.continuityProfile,
        scenes
      });

      res.json({
        projectId: updated.id,
        continuityProfile: updated.continuityProfile,
        scenes: updated.scenes,
        modelUsed: analysis.modelUsed,
        fallbackNote: analysis.fallbackNote,
        totalDurationSec: scenes.reduce((acc, s) => acc + s.effectiveDurationSec, 0)
      });
    } catch (innerErr: any) {
      projectManager.updateProject(project.id, { isAnalyzing: false });
      throw innerErr;
    }
  } catch (err: any) {
    console.error('[API /api/script/analyze] Error:', err);
    res.status(500).json({ error: err.message || 'Gemini script analysis failed' });
  }
});

// Step 8: Generate image for a single scene
app.post('/api/scenes/:sceneId/generate-image', async (req, res) => {
  const { sceneId } = req.params;
  const { projectId, prompt, customApiUrl, imageModel } = req.body;

  try {
    const project = projectManager.getProject(projectId);
    if (!project) {
      return res.status(404).json({ error: `Project ${projectId} not found` });
    }

    const scene = project.scenes.find(s => s.id === sceneId);
    if (!scene) {
      return res.status(404).json({ error: `Scene ${sceneId} not found` });
    }

    const sceneDir = projectManager.getSceneDir(projectId, sceneId);
    const finalPrompt = prompt || scene.imagePrompt;

    const result = await generateSceneImage({
      prompt: finalPrompt,
      aspectRatio: project.settings.aspectRatio,
      style: project.settings.style,
      sceneTitle: scene.title,
      sceneSequence: scene.sequence,
      continuityProfile: project.continuityProfile,
      characterDescriptions: scene.characterDescriptions,
      customApiUrl: customApiUrl || project.settings.imageApiUrl,
      imageModel: imageModel || project.settings.imageModel,
      targetDir: sceneDir,
      fileName: 'image.png'
    });

    const imageUrl = `/api/media/${projectId}/${sceneId}/image.png?t=${Date.now()}`;

    // Update scene in project
    const updatedScenes = project.scenes.map(s => {
      if (s.id === sceneId) {
        return {
          ...s,
          imagePrompt: finalPrompt,
          imagePath: result.imagePath,
          imageUrl,
          imageStatus: 'completed' as const
        };
      }
      return s;
    });

    projectManager.updateProject(projectId, { scenes: updatedScenes });

    res.json({
      sceneId,
      imagePath: result.imagePath,
      imageUrl,
      isFallback: result.isFallback,
      note: result.note
    });
  } catch (err: any) {
    console.error(`[API /api/scenes/${sceneId}/generate-image] Error:`, err);
    res.status(500).json({ error: err.message || 'Image generation failed' });
  }
});

// Step 9: Generate voice for a single scene (Groq Orpheus TTS primary, Edge Neural backup)
app.post('/api/scenes/:sceneId/generate-voice', async (req, res) => {
  const { sceneId } = req.params;
  const { projectId, narration, voiceId, groqApiKey } = req.body;

  try {
    const project = projectManager.getProject(projectId);
    if (!project) {
      return res.status(404).json({ error: `Project ${projectId} not found` });
    }

    const scene = project.scenes.find(s => s.id === sceneId);
    if (!scene) {
      return res.status(404).json({ error: `Scene ${sceneId} not found` });
    }

    const sceneDir = projectManager.getSceneDir(projectId, sceneId);
    const textToSpeak = narration || scene.narration;
    const voice = voiceId || project.settings.voiceId;
    const effectiveGroqKey = groqApiKey !== undefined ? groqApiKey : project.settings.groqApiKey;

    const result = await generateSpeechAudio(textToSpeak, voice, sceneDir, 'voice.mp3', effectiveGroqKey);
    const audioUrl = `/api/media/${projectId}/${sceneId}/voice.mp3?t=${Date.now()}`;

    // Update scene timing and paths
    const updatedScenes = project.scenes.map(s => {
      if (s.id === sceneId) {
        return {
          ...s,
          narration: textToSpeak,
          audioPath: result.audioPath,
          audioUrl,
          audioDurationSec: result.durationSec,
          effectiveDurationSec: result.durationSec,
          voiceStatus: 'completed' as const,
          errorMessage: undefined
        };
      }
      return s;
    });

    // Recalculate timeline with new audio duration
    const { scenes } = calculateTimeline(updatedScenes, project.settings.fps);
    projectManager.updateProject(projectId, { scenes });

    const updatedScene = scenes.find(s => s.id === sceneId);

    res.json({
      sceneId,
      audioPath: result.audioPath,
      audioUrl,
      durationSec: result.durationSec,
      provider: result.provider,
      fallbackNote: result.fallbackNote,
      scene: updatedScene
    });
  } catch (err: any) {
    console.error(`[API /api/scenes/${sceneId}/generate-voice] Error:`, err);
    try {
      const proj = projectManager.getProject(projectId);
      if (proj) {
        const failedScenes = proj.scenes.map(s =>
          s.id === sceneId ? { ...s, voiceStatus: 'failed' as const, errorMessage: err.message } : s
        );
        projectManager.updateProject(projectId, { scenes: failedScenes });
      }
    } catch {}
    res.status(500).json({ error: err.message || 'Voice generation failed' });
  }
});

// Step 7: Batch generation (both, image-only, voice-only)
app.post('/api/project/generate', async (req, res) => {
  const { projectId, mode = 'both', imageApiUrl, imageModel, groqApiKey, voiceId } = req.body;

  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).json({ error: `Project ${projectId} not found` });
  }

  if (project.scenes.length === 0) {
    return res.status(400).json({ error: 'No scenes to generate' });
  }

  const updatedSettings = { ...project.settings };
  if (imageApiUrl !== undefined) updatedSettings.imageApiUrl = imageApiUrl;
  if (imageModel !== undefined) updatedSettings.imageModel = imageModel;
  if (groqApiKey !== undefined) updatedSettings.groqApiKey = groqApiKey;
  if (voiceId !== undefined) updatedSettings.voiceId = voiceId;

  // Set project generating state
  projectManager.updateProject(projectId, {
    settings: updatedSettings,
    isGenerating: true,
    generationProgress: {
      totalScenes: project.scenes.length,
      completedScenes: 0,
      currentSceneIndex: 0,
      currentAction: 'Starting batch generation...',
      percentage: 0
    }
  });

  // Launch background sequential generation without blocking response
  runBatchGeneration(projectId, mode as GenerationMode).catch(err => {
    console.error(`[batch] Unhandled error in runBatchGeneration(${projectId}):`, err);
    try {
      projectManager.updateProject(projectId, {
        isGenerating: false,
        generationProgress: {
          totalScenes: project.scenes.length,
          completedScenes: 0,
          currentSceneIndex: 0,
          currentAction: err?.message || 'Generation failed',
          percentage: 0
        }
      });
    } catch {}
  });

  res.json({
    message: 'Generation started',
    projectId,
    mode,
    totalScenes: project.scenes.length
  });
});

async function runBatchGeneration(projectId: string, mode: GenerationMode) {
  const project = projectManager.getProject(projectId);
  if (!project) return;

  const total = project.scenes.length;
  try {
    const needImages = mode === 'both' || mode === 'image-only';
    const needVoices = mode === 'both' || mode === 'voice-only';

    const scenesNeedingImages = needImages
      ? project.scenes.filter(s => s.imageStatus !== 'completed' || !s.imagePath || !fs.existsSync(s.imagePath))
      : [];

    // Submit POST /bulk in the background while voiceovers synthesize concurrently
    let bulkPromise: ReturnType<typeof runFlowBulkImageJobs> | null = null;
    if (scenesNeedingImages.length >= 2) {
      const bulkPrompts = scenesNeedingImages.map(scene =>
        buildConsistentFlowPrompt({
          prompt: scene.imagePrompt,
          aspectRatio: project.settings.aspectRatio,
          style: project.settings.style,
          continuityProfile: project.continuityProfile,
          characterDescriptions: scene.characterDescriptions
        })
      );

      bulkPromise = runFlowBulkImageJobs({
        prompts: bulkPrompts,
        aspectRatio: project.settings.aspectRatio,
        imageModel: project.settings.imageModel || 'beluga',
        captcha: 'broker',
        concurrency: 2,
        customApiUrl: project.settings.imageApiUrl,
        onProgress: info => {
          if (!needVoices) {
            const pct = Math.min(95, Math.round((info.completed / Math.max(1, info.total)) * 95));
            projectManager.updateProject(projectId, {
              generationProgress: {
                totalScenes: total,
                completedScenes: info.completed,
                currentSceneIndex: info.completed,
                currentAction: `Flow /bulk images: ${info.completed}/${info.total} finished (${info.succeeded} ok)...`,
                percentage: pct
              }
            });
          }
        }
      });
    }

    // 1. Generate Voiceovers if requested
    if (needVoices) {
      for (let i = 0; i < total; i++) {
        const currentProj = projectManager.getProject(projectId);
        if (!currentProj) break;

        const scene = currentProj.scenes[i];
        const sceneDir = projectManager.getSceneDir(projectId, scene.id);
        const needsVoice =
          mode === 'voice-only' ||
          scene.voiceStatus !== 'completed' ||
          !scene.audioPath ||
          !fs.existsSync(scene.audioPath);

        projectManager.updateProject(projectId, {
          generationProgress: {
            totalScenes: total,
            completedScenes: i,
            currentSceneIndex: i + 1,
            currentAction: `Generating voiceover for Scene ${scene.sequence}: ${scene.title}`,
            percentage: Math.floor((i / total) * (needImages ? 50 : 95))
          }
        });

        if (needsVoice) {
          try {
            const { audioPath, durationSec } = await generateSpeechAudio(
              scene.narration,
              currentProj.settings.voiceId,
              sceneDir,
              'voice.mp3',
              currentProj.settings.groqApiKey
            );

            scene.audioPath = audioPath;
            scene.audioUrl = `/api/media/${projectId}/${scene.id}/voice.mp3?t=${Date.now()}`;
            scene.audioDurationSec = durationSec;
            scene.effectiveDurationSec = durationSec;
            scene.voiceStatus = 'completed';
            scene.errorMessage = undefined;
          } catch (e: any) {
            console.error(`[batch] Voice error scene ${scene.id}:`, e);
            scene.voiceStatus = 'failed';
            scene.errorMessage = e.message;
          }

          const { scenes } = calculateTimeline(currentProj.scenes, currentProj.settings.fps);
          projectManager.updateProject(projectId, { scenes });
        }
      }
    }

    // 2. Finalize Images (either from POST /bulk results or single POST /image + stylized fallback)
    if (scenesNeedingImages.length === 1) {
      const singleScene = scenesNeedingImages[0];
      const currentProj = projectManager.getProject(projectId);
      if (currentProj) {
        const target = currentProj.scenes.find(s => s.id === singleScene.id);
        if (target) {
          projectManager.updateProject(projectId, {
            generationProgress: {
              totalScenes: total,
              completedScenes: total - 1,
              currentSceneIndex: target.sequence,
              currentAction: `Generating image via POST /image for Scene ${target.sequence}...`,
              percentage: 70
            }
          });
          try {
            const imgRes = await generateSceneImage({
              prompt: target.imagePrompt,
              aspectRatio: currentProj.settings.aspectRatio,
              style: currentProj.settings.style,
              sceneTitle: target.title,
              sceneSequence: target.sequence,
              continuityProfile: currentProj.continuityProfile,
              characterDescriptions: target.characterDescriptions,
              customApiUrl: currentProj.settings.imageApiUrl,
              imageModel: currentProj.settings.imageModel,
              targetDir: projectManager.getSceneDir(projectId, target.id),
              fileName: 'image.png'
            });
            target.imagePath = imgRes.imagePath;
            target.imageUrl = `/api/media/${projectId}/${target.id}/image.png?t=${Date.now()}`;
            target.imageStatus = 'completed';
            const { scenes } = calculateTimeline(currentProj.scenes, currentProj.settings.fps);
            projectManager.updateProject(projectId, { scenes });
          } catch (e: any) {
            target.imageStatus = 'failed';
            target.errorMessage = e.message;
          }
        }
      }
    } else if (scenesNeedingImages.length >= 2 && bulkPromise) {
      let bulkResults: Array<{ ok: boolean; buffer?: Buffer; contentType?: string; error?: string }> = [];
      try {
        const bulkRes = await bulkPromise;
        bulkResults = bulkRes.results;
      } catch (bulkErr: any) {
        console.warn(`[batch] Flow /bulk failed (${bulkErr.message}); falling back scene-by-scene.`);
      }

      for (let idx = 0; idx < scenesNeedingImages.length; idx++) {
        const currentProj = projectManager.getProject(projectId);
        if (!currentProj) break;
        const target = currentProj.scenes.find(s => s.id === scenesNeedingImages[idx].id);
        if (!target) continue;

        const sceneDir = projectManager.getSceneDir(projectId, target.id);
        const finalImgPath = path.join(sceneDir, 'image.png');
        const item = bulkResults[idx];

        projectManager.updateProject(projectId, {
          generationProgress: {
            totalScenes: total,
            completedScenes: idx,
            currentSceneIndex: target.sequence,
            currentAction: `Saving Scene ${target.sequence} artwork (${idx + 1}/${scenesNeedingImages.length})...`,
            percentage: Math.min(98, 55 + Math.round(((idx + 1) / scenesNeedingImages.length) * 42))
          }
        });

        if (item?.ok && item.buffer) {
          try {
            await saveRawImageAsPng(item.buffer, item.contentType || 'image/jpeg', finalImgPath);
            target.imagePath = finalImgPath;
            target.imageUrl = `/api/media/${projectId}/${target.id}/image.png?t=${Date.now()}`;
            target.imageStatus = 'completed';
            const { scenes } = calculateTimeline(currentProj.scenes, currentProj.settings.fps);
            projectManager.updateProject(projectId, { scenes });
            continue;
          } catch (saveErr) {
            console.warn(`[batch] Error saving bulk image for ${target.id}:`, saveErr);
          }
        }

        // Per-scene single retry or local stylized visual fallback
        try {
          const imgRes = await generateSceneImage({
            prompt: target.imagePrompt,
            aspectRatio: currentProj.settings.aspectRatio,
            style: currentProj.settings.style,
            sceneTitle: target.title,
            sceneSequence: target.sequence,
            continuityProfile: currentProj.continuityProfile,
            characterDescriptions: target.characterDescriptions,
            customApiUrl: currentProj.settings.imageApiUrl,
            imageModel: currentProj.settings.imageModel,
            targetDir: sceneDir,
            fileName: 'image.png'
          });
          target.imagePath = imgRes.imagePath;
          target.imageUrl = `/api/media/${projectId}/${target.id}/image.png?t=${Date.now()}`;
          target.imageStatus = 'completed';
        } catch (e: any) {
          target.imageStatus = 'failed';
          target.errorMessage = e.message;
        }

        const { scenes } = calculateTimeline(currentProj.scenes, currentProj.settings.fps);
        projectManager.updateProject(projectId, { scenes });
      }
    }

    // Mark generation complete
    projectManager.updateProject(projectId, {
      isGenerating: false,
      generationProgress: {
        totalScenes: total,
        completedScenes: total,
        currentSceneIndex: total,
        currentAction: 'Generation complete',
        percentage: 100
      }
    });
  } catch (batchErr: any) {
    console.error(`[batch] Batch generation failed for ${projectId}:`, batchErr);
    try {
      projectManager.updateProject(projectId, {
        isGenerating: false,
        generationProgress: {
          totalScenes: total,
          completedScenes: 0,
          currentSceneIndex: 0,
          currentAction: batchErr?.message || 'Batch generation failed',
          percentage: 0
        }
      });
    } catch {}
  }
}

// Get project status & generation progress
app.get('/api/project/:projectId/status', (req, res) => {
  const { projectId } = req.params;
  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).json({ error: `Project ${projectId} not found` });
  }

  res.json({
    projectId: project.id,
    isAnalyzing: project.isAnalyzing,
    isGenerating: project.isGenerating,
    generationProgress: project.generationProgress,
    renderStatus: project.renderStatus,
    updatedAt: project.updatedAt
  });
});

// Get all scenes and project metadata
app.get('/api/project/:projectId/scenes', (req, res) => {
  const { projectId } = req.params;
  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).json({ error: `Project ${projectId} not found` });
  }

  const { totalDurationSec, totalDurationFrames } = calculateTimeline(project.scenes, project.settings.fps);

  res.json({
    project: {
      id: project.id,
      script: project.script,
      settings: project.settings,
      continuityProfile: project.continuityProfile,
      musicTrack: project.musicTrack || null,
      scenes: project.scenes,
      totalDurationSec,
      totalDurationFrames,
      renderStatus: project.renderStatus
    }
  });
});

// Update scene metadata (reordering, text editing, continuity profile, duration adjustments)
app.post('/api/project/:projectId/scenes', (req, res) => {
  const { projectId } = req.params;
  const { scenes, settings, continuityProfile } = req.body;

  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).json({ error: `Project ${projectId} not found` });
  }

  const updates: any = {};
  if (Array.isArray(scenes)) {
    updates.scenes = scenes;
  }
  if (settings) {
    updates.settings = { ...project.settings, ...settings };
  }
  if (continuityProfile) {
    updates.continuityProfile = { ...(project.continuityProfile || {}), ...continuityProfile };
  }

  const updated = projectManager.updateProject(projectId, updates);
  const { totalDurationSec, totalDurationFrames } = calculateTimeline(updated.scenes, updated.settings.fps);
  res.json({
    project: {
      ...updated,
      totalDurationSec,
      totalDurationFrames
    }
  });
});

// Built-in background music library endpoints
app.get('/api/music/presets', (_req, res) => {
  res.json({ presets: listMusicPresets() });
});

app.get('/api/music/presets/:presetId/audio', async (req, res) => {
  const { presetId } = req.params;
  try {
    const { filePath } = await ensurePresetAudioFile(presetId);
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.sendFile(filePath);
  } catch (err: any) {
    res.status(404).json({ error: err.message || 'Preset track not found' });
  }
});

// Add or replace background music on project (preset or uploaded audio file)
app.post('/api/project/:projectId/music', async (req, res) => {
  const { projectId } = req.params;
  const { presetId, fileName, base64Data, overrides } = req.body || {};

  try {
    const project = projectManager.getProject(projectId);
    if (!project) {
      return res.status(404).json({ error: `Project ${projectId} not found` });
    }

    const musicDir = projectManager.getMusicDir(projectId);
    let track;

    if (presetId) {
      track = await assignPresetMusicToProject(projectId, musicDir, presetId, overrides);
    } else if (base64Data) {
      track = await saveUploadedMusicToProject(projectId, musicDir, {
        fileName: fileName || 'custom-music.mp3',
        base64Data,
        overrides
      });
    } else {
      return res.status(400).json({ error: 'Provide either presetId or uploaded audio base64Data' });
    }

    const updated = projectManager.updateProject(projectId, { musicTrack: track });
    const { totalDurationSec, totalDurationFrames } = calculateTimeline(updated.scenes, updated.settings.fps);
    res.json({
      musicTrack: track,
      project: {
        ...updated,
        totalDurationSec,
        totalDurationFrames
      }
    });
  } catch (err: any) {
    console.error(`[API /api/project/${projectId}/music] Error:`, err);
    res.status(500).json({ error: err.message || 'Failed to add background music' });
  }
});

// Raw binary audio upload endpoint for large MP3/WAV/M4A/OGG tracks
app.post(
  '/api/project/:projectId/music/upload',
  express.raw({ type: '*/*', limit: '100mb' }),
  async (req, res) => {
    const { projectId } = req.params;
    const rawFileName = String(req.headers['x-file-name'] || req.query.fileName || 'custom-music.mp3');
    const safeFileName = decodeURIComponent(rawFileName);

    try {
      const project = projectManager.getProject(projectId);
      if (!project) {
        return res.status(404).json({ error: `Project ${projectId} not found` });
      }
      if (!Buffer.isBuffer(req.body) || req.body.byteLength < 256) {
        return res.status(400).json({ error: 'Uploaded audio file is empty or unreadable.' });
      }

      const musicDir = projectManager.getMusicDir(projectId);
      const track = await saveUploadedMusicToProject(projectId, musicDir, {
        fileName: safeFileName,
        base64Data: req.body.toString('base64'),
        overrides: {
          narrationVolume: project.settings.narrationVolume ?? 1.0
        }
      });

      const updated = projectManager.updateProject(projectId, { musicTrack: track });
      const { totalDurationSec, totalDurationFrames } = calculateTimeline(updated.scenes, updated.settings.fps);
      res.json({
        musicTrack: track,
        project: {
          ...updated,
          totalDurationSec,
          totalDurationFrames
        }
      });
    } catch (err: any) {
      console.error(`[API /api/project/${projectId}/music/upload] Error:`, err);
      res.status(500).json({ error: err.message || 'Failed to process uploaded music file' });
    }
  }
);

// Update background music mix parameters (volume, narrationVolume, fade, loop, ducking, offset)
app.patch('/api/project/:projectId/music', (req, res) => {
  const { projectId } = req.params;
  const updates = req.body || {};

  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).json({ error: `Project ${projectId} not found` });
  }
  if (!project.musicTrack) {
    return res.status(404).json({ error: 'No background music track attached to this project' });
  }

  const nextTrack = {
    ...project.musicTrack,
    volume: typeof updates.volume === 'number' ? Math.max(0, Math.min(1, updates.volume)) : project.musicTrack.volume,
    narrationVolume:
      typeof updates.narrationVolume === 'number'
        ? Math.max(0, Math.min(1.5, updates.narrationVolume))
        : project.musicTrack.narrationVolume,
    fadeInSec: typeof updates.fadeInSec === 'number' ? Math.max(0, Math.min(10, updates.fadeInSec)) : project.musicTrack.fadeInSec,
    fadeOutSec: typeof updates.fadeOutSec === 'number' ? Math.max(0, Math.min(10, updates.fadeOutSec)) : project.musicTrack.fadeOutSec,
    loop: typeof updates.loop === 'boolean' ? updates.loop : project.musicTrack.loop,
    ducking: typeof updates.ducking === 'boolean' ? updates.ducking : project.musicTrack.ducking,
    startOffsetSec:
      typeof updates.startOffsetSec === 'number'
        ? Math.max(0, updates.startOffsetSec)
        : project.musicTrack.startOffsetSec
  };

  const updated = projectManager.updateProject(projectId, { musicTrack: nextTrack });
  res.json({ musicTrack: nextTrack, project: updated });
});

// Remove background music from project
app.delete('/api/project/:projectId/music', (req, res) => {
  const { projectId } = req.params;
  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).json({ error: `Project ${projectId} not found` });
  }

  const musicPath = path.join(projectManager.getMusicDir(projectId), 'background-music.mp3');
  if (fs.existsSync(musicPath)) {
    try { fs.unlinkSync(musicPath); } catch {}
  }

  const updated = projectManager.updateProject(projectId, { musicTrack: null });
  res.json({ project: updated });
});

// Serve project's active background music file
app.get('/api/project/:projectId/music/file', (req, res) => {
  const { projectId } = req.params;
  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).send('Project not found');
  }
  const musicPath = project.musicTrack?.filePath || path.join(projectManager.getMusicDir(projectId), 'background-music.mp3');
  if (!fs.existsSync(musicPath)) {
    return res.status(404).send('Background music file not found');
  }
  res.setHeader('Content-Type', 'audio/mpeg');
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'no-cache');
  res.sendFile(musicPath);
});

// Sync and unify all scene image prompts to the locked Master Continuity Bible & script
app.post('/api/project/:projectId/reprompt', async (req, res) => {
  const { projectId } = req.params;
  const { continuityProfile, geminiApiKey, geminiModel } = req.body || {};

  try {
    const project = projectManager.getProject(projectId);
    if (!project) {
      return res.status(404).json({ error: `Project ${projectId} not found` });
    }

    const activeProfile = continuityProfile
      ? { ...(project.continuityProfile || {}), ...continuityProfile }
      : project.continuityProfile;

    if (!activeProfile) {
      return res.status(400).json({ error: 'Project has no continuity profile yet' });
    }

    const updatedScenes = await syncContinuityPromptsWithGemini({
      script: project.script,
      continuityProfile: activeProfile,
      scenes: project.scenes,
      style: project.settings.style,
      aspectRatio: project.settings.aspectRatio,
      geminiApiKey: geminiApiKey || project.settings.geminiApiKey,
      geminiModel: geminiModel || project.settings.geminiModel
    });

    const updated = projectManager.updateProject(projectId, {
      continuityProfile: activeProfile,
      scenes: updatedScenes
    });

    res.json({ project: updated });
  } catch (err: any) {
    console.error(`[API /api/project/${projectId}/reprompt] Error:`, err);
    res.status(500).json({ error: err.message || 'Failed to sync continuity prompts' });
  }
});

// Step 8: Render MP4
app.post('/api/project/:projectId/render', async (req, res) => {
  const { projectId } = req.params;
  const {
    resolution,
    fps,
    showCaptions,
    subtitleStyle,
    autoMotion,
    motionSpeed,
    narrationVolume,
    musicTrack,
    lowRamMode
  } = req.body || {};

  try {
    const project = projectManager.getProject(projectId);
    if (!project) {
      return res.status(404).json({ error: `Project ${projectId} not found` });
    }

    // Sync latest editor settings & mix levels before rendering
    const updates: any = {
      settings: {
        ...project.settings,
        ...(typeof showCaptions === 'boolean' ? { showCaptions } : {}),
        ...(subtitleStyle ? { subtitleStyle } : {}),
        ...(typeof autoMotion === 'boolean' ? { autoMotion } : {}),
        ...(motionSpeed ? { motionSpeed } : {}),
        ...(typeof narrationVolume === 'number' ? { narrationVolume } : {})
      }
    };
    if (musicTrack && project.musicTrack) {
      updates.musicTrack = { ...project.musicTrack, ...musicTrack, filePath: project.musicTrack.filePath };
    }
    projectManager.updateProject(projectId, updates);

    // Start rendering asynchronously
    renderProjectToMp4(projectId, {
      resolution,
      fps,
      showCaptions,
      subtitleStyle,
      autoMotion,
      motionSpeed,
      narrationVolume,
      lowRamMode: Boolean(lowRamMode)
    }).catch(err => {
      console.error(`[render async error] ${projectId}:`, err);
    });

    res.json({
      message: 'Render initiated',
      projectId,
      renderStatus: project.renderStatus
    });
  } catch (err: any) {
    console.error(`[API /api/project/${projectId}/render] Error:`, err);
    res.status(500).json({ error: err.message || 'Render failed' });
  }
});

// Render status check
app.get('/api/project/:projectId/render-status', (req, res) => {
  const { projectId } = req.params;
  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).json({ error: `Project ${projectId} not found` });
  }

  res.json({
    renderStatus: project.renderStatus || {
      isRendering: false,
      progress: 0,
      currentStep: 'Not started'
    }
  });
});

// Download final MP4
app.get('/api/project/:projectId/download', (req, res) => {
  const { projectId } = req.params;
  const project = projectManager.getProject(projectId);
  if (!project) {
    return res.status(404).send('Project not found');
  }

  const outputDir = projectManager.getOutputDir(projectId);
  const mp4Path = path.join(outputDir, 'final-video.mp4');

  if (!fs.existsSync(mp4Path) || fs.statSync(mp4Path).size === 0) {
    return res.status(404).send('Video not yet rendered or file expired');
  }

  const isInline = req.query.inline === 'true' || req.query.preview === 'true';

  res.setHeader('Content-Type', 'video/mp4');
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader(
    'Content-Disposition',
    `${isInline ? 'inline' : 'attachment'}; filename="cinescript_${projectId}.mp4"`
  );
  res.sendFile(mp4Path);
});

// Serve scene media assets (images, audio)
app.get('/api/media/:projectId/:sceneId/:fileName', (req, res) => {
  const { projectId, sceneId, fileName } = req.params;
  const sceneDir = projectManager.getSceneDir(projectId, sceneId);
  const filePath = path.join(sceneDir, fileName);

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('Media file not found');
  }

  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'no-cache');

  if (fileName.endsWith('.mp3')) {
    res.setHeader('Content-Type', 'audio/mpeg');
  } else if (fileName.endsWith('.png')) {
    res.setHeader('Content-Type', 'image/png');
  } else if (fileName.endsWith('.svg')) {
    res.setHeader('Content-Type', 'image/svg+xml');
  }

  res.sendFile(filePath);
});

// Mount Vite or serve production build
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CineScript AI] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('[CineScript AI] Fatal server startup error:', err);
  process.exit(1);
});
